
face2face.directive('faxMask', function ($timeout) {

    function makeSsn (value) {
      var result = value;

      var ssn = value ? value.toString() : '';
      if (ssn.length > 1) {
        result = "+" + ssn.substr(0, 1) + '-';
        if (ssn.length > 4) {
          result += ssn.substr(1, 3) + '-';
          result += ssn.substr(4, 7);
        }
        else {
          result += ssn.substr(1);
        }
      } else if(ssn.length == 1){
      	result = "+" + ssn.substr(0);
      }

      return result;
    }

    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, element, attrs, ngModel) {
        ngModel.$formatters.push(function (value) {
          return makeSsn(value);
        });

        // clean output as digits
        ngModel.$parsers.push(function (value) {
          var cursorPosition = element[0].selectionStart;
          var oldLength = value.toString().length;
          var nonDigits = /[^0-9]/g;
          var intValue = value.replace(nonDigits, '');
          if (intValue.length > 11) {
            intValue = intValue.substr(0, 11);
          }
          var newValue = makeSsn(intValue);
          ngModel.$setViewValue(newValue);
          ngModel.$render();
          $timeout(function(){element[0].setSelectionRange(cursorPosition + newValue.length - oldLength, cursorPosition + newValue.length - oldLength)},1);
          return intValue;
        });
      }
    };

  });



face2face.directive('phoneMask', function ($timeout) {

    function makePhoneNo (value) {
     var result = value;

      var ssn = value ? value.toString() : '';
      if (ssn.length > 3) {
        result = ssn.substr(0, 3) + '-';
        if (ssn.length > 6) {
          result += ssn.substr(3, 3) + '-';
          result += ssn.substr(6, 4);
        }
        else {
          result += ssn.substr(3);
        }
      }

      return result;
    }

    return {
      restrict: 'A',
      require: 'ngModel',
      link: function (scope, element, attrs, ngModel) {
        ngModel.$formatters.push(function (value) {
          return makePhoneNo(value);
        });

        // clean output as digits
        ngModel.$parsers.push(function (value) {
          var cursorPosition = element[0].selectionStart;
          var oldLength = value.toString().length;
          var nonDigits = /[^0-9]/g;
          var intValue = value.replace(nonDigits, '');
          if (intValue.length > 10) {
            intValue = intValue.substr(0, 10);
          }
          var newValue = makePhoneNo(intValue);
          ngModel.$setViewValue(newValue);
          ngModel.$render();
          $timeout(function(){element[0].setSelectionRange(cursorPosition + newValue.length - oldLength, cursorPosition + newValue.length - oldLength)},100);
          return intValue;
        });
      }
    };
  });
