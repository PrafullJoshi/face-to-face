face2face.directive("limitTo", [
  function () {
    return {

      // numeric and alphanumeric both validations 

      restrict: "A",
      link: function (scope, elem, attrs) {
        var limit = parseInt(attrs.limitTo);

        angular.element(elem).on("keydown", function (e) {

          if (this.value.trim().length >= limit) {
                   /* if(e.keyCode == 65 && e.keyCode == 17){
                      alert("in")
                    }
                   
                   else*/ if (!(e.keyCode == 13) && !(e.ctrlKey && e.keyCode == 67) && !(e.ctrlKey && e.keyCode == 88) && !(e.ctrlKey && e.keyCode == 65) && e.keyCode !== 8 && e.keyCode !== 37 && e.keyCode !== 39 && e.keyCode !== 46 && e.keyCode !== 9 && e.keyCode !== 17 && (e.keyCode >= 96 || e.keyCode <= 105)) {

              e.preventDefault();
            }

          }

        });
      }
    }
  }]);

face2face.directive("maxMin", ['Scopes',
  function (Scopes) {
    return {
      // numeric and alphanumeric both validations
      restrict: "A",
      link: function (scope, elem, attrs, ctrl) {
        //console.log(attrs);
        var prevKey = '';
        var maxlimit = parseInt(attrs.maxl);
        var minlimit = parseInt(attrs.minl);
        var space = attrs.space;
        if (maxlimit != 50) {
          if (!space) { // done by Sonam 
            angular.element(elem).on("keydown", function (e) {
              if (!(typeof e.key == 'String' || typeof e.key == 'string')) {
                if (e.keyCode == 32) {
                  e.preventDefault();
                }
              }
            });
          }
        }

        angular.element(elem).on("blur keydown", function (e) {

          var obj = { 'formName': attrs.name, 'msgId': attrs.messageid };
          var temobj;
          if (this.value.trim().length != 0) {
            if (this.value.trim().length > maxlimit || this.value.trim().length < minlimit) {
              document.getElementById(attrs.messageid).innerHTML = attrs.msg;
              if (!Scopes.get('formInfoValidation')) {
                Scopes.store('formInfoValidation', [obj]);
              } else {
                temobj = Scopes.get('formInfoValidation');
                if (e.target.name != prevKey) {
                  prevKey = e.target.name;
                  temobj.push(obj);
                  // alert(JSON.stringify(temobj) +"   tt");

                  Scopes.store('formInfoValidation', temobj);
                }
              }
              //scope.invalid=true;
            } else {
              document.getElementById(attrs.messageid).innerHTML = '';
              temobj = Scopes.get('formInfoValidation');
              if (e.target.name != prevKey) {
                prevKey = e.target.name;
                //temobj.splice(temobj.indexOf(obj),1);
                Scopes.store('formInfoValidation', temobj);
              }
            }
          } else {
            // alert(prevKey + "11")
            document.getElementById(attrs.messageid).innerHTML = '';
            temobj = Scopes.get('formInfoValidation');
            // alert(JSON.stringify(temobj))
            // alert(e.target.name != prevKey)
            if (e.target.name != prevKey) {
              // alert(prevKey + "66")
              if (!Scopes.get('formInfoValidation'))
                prevKey = e.target.name;
              // temobj.splice(temobj.indexOf(obj),1);
              Scopes.store('formInfoValidation', temobj);
            }

          }

        });
      }
    }
  }]);


face2face.directive('minLen', [function () {
  return {
    restrict: "A",
    scope: {
      flag: "=",
      errMsg: "="
    },
    link: function (scope, elem, attrs) {
      angular.element(elem).on("keydown", function (e) {
        if (this.value.trim().length < attrs.minLen) {
          scope.flag = false;
          scope.errMsg = "";

        }
      });

    }
  }
}]);
face2face.directive("alphanumericOnly", [function () {
  // numeric and alphanumeric both validations

  return {
    restrict: "A",
    require: 'ngModel',
    link: function (scope, element, attr, ngModelCtrl) {
      function fromUser(text) {
        var pattern = /[^0-9]/g;
        if (attr.alphanumericOnly === 'alphanumeric') {
          pattern = /[^0-9a-zA-Z]/g;
        }
        else if (attr.alphanumericOnly === 'alpha') {
          pattern = /[^a-zA-Z ]*$/;
        }
        else if (attr.alphanumericOnly === 'alphawithdot') {
          pattern = /[^a-zA-Z .]*$/;
        }
        else if (attr.alphanumericOnly === 'deano') {
          pattern = /^[A-Za-z]{2}[0-9]{7}$/;
          // pattern = [^A-Z]{2}[0-9]{7};
        } else if (attr.alphanumericOnly === 'numberwithdot') {
          pattern = /[^0-9.]*$/;
        }
        else if (attr.alphanumericOnly === 'height') {
          pattern = /[^0-9"']*$/;
        }
        else {
          pattern = /[^0-9]/g;
          //pattern = /(^0$)|[^0-9]/;
        }
        if (text) {
          var transformedInput = text.replace(pattern, '');

          if (transformedInput !== text) {
            ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
          }
          return transformedInput;
        }
        return undefined;
      }
      ngModelCtrl.$parsers.push(fromUser);
    }
  }
}
]);


face2face.directive('compile', ['$compile',
  function ($compile) {
    return function (scope, element, attrs) {
      scope.$watch(
        function (scope) {
          return scope.$eval(attrs.compile); // watch the 'compile' expression for changes
        },
        function (value) {
          element.html(value); // assign it into the current DOM
          $compile(element.contents())(scope); // compile the new DOM and link it to the current scope.
        }
      );
    };

  }
]);



face2face.directive('validatePassword', function (validatePass, $timeout) {
  return {
    restrict: 'A',
    // require:'ngModel',
    scope: {
      validpass: '=',
      //   fagval:'='
    },
    link: function (scope, elem, attrs) {

      angular.element(elem).on("blur", function (e) {
        $timeout(function () {

          var res = validatePass.validate(scope.validpass.password, scope.validpass.confirm_password, scope.validpass.email, scope.validpass.username);

          // console.log("inside directive res: ",res)
          // scope.fagval.validateFlag = res.flag;


          if (res.confirm)
            scope.validpass.errPassMssg = res.mssg;
          if (res.flag === false)
            scope.validpass.errPassMsg = res.msg;


        }, 0);


        //return scope.pForm.validateFlag;

      });


    }
  }
});
face2face.directive('validateDate', function (validateDate, $timeout) {
  return {
    restrict: 'A',
    scope: {
      dateerrmsg: '=',
    },
    link: function (scope, elem, attrs) {

      angular.element(elem).on("blur change", function (e) {


        var that = this;
        var temobj = validateDate.validateDt(that.value, attrs.formelemname);

        $timeout(function () {

          scope.$apply(function () {

            if (!temobj.flag) {

              scope.dateerrmsg = temobj.msg;
            } else {
              scope.dateerrmsg = temobj.msg;
            }

          });
        }, 10);



      });


    }
  }

});

face2face.directive('isRequired', function (Scopes, requiredFactory, $timeout) {
  return {
    restrict: 'A',
    require: '^form',

    link: function (scope, elem, attrs, ctrl) {
      var obj = [];
      var temobj = [];
      var count = 0;
      var messageElem;
      $timeout(function () {
        messageElem = angular.element(document.querySelector('#' + (attrs.messageid)));
        obj = { 'formName': attrs.formelemname, 'msgId': attrs.messageid };
        if (!Scopes.get('formInfo')) {
          Scopes.store('formInfo', [obj]);

        } else {
          temobj = Scopes.get('formInfo');
          temobj.push(obj);
          Scopes.store('formInfo', temobj);
        }
      }, 100);


      //console.log(Scopes.get('formInfo'))
      elem.on("blur", function (e) {
        /*if(attrs.formelemname.indexOf('DOB')<0)*/
        requiredFactory.showMsg(scope, ctrl[attrs.formelemname], messageElem, count);

        /*  });
         elem.on("change",function(e){
           if(attrs.formelemname.indexOf('DOB')>0)
           requiredFactory.showMsg(scope,ctrl[attrs.formelemname],messageElem,count);
           */
      });

    }
  }
});


face2face.directive('validateEmail', function (Scopes) {
  var EMAIL_REGEXP = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

  return {
    require: 'ngModel',
    restrict: '',
    link: function (scope, elm, attrs, ctrl) {

      // only apply the validator if ngModel is present and Angular has added the email validator
      angular.element(elm).on("blur change", function (e) {
        var obj = { 'formName': attrs.name, 'msgId': attrs.messageid };
        if (this.value && EMAIL_REGEXP.test(this.value)) {
          document.getElementById(attrs.messageid).innerHTML = '';
          temobj = Scopes.get('formInfoValidation');
          if (temobj)
            temobj.splice(temobj.indexOf(obj), 1);
          Scopes.store('formInfoValidation', temobj);
        } else {
          document.getElementById(attrs.messageid).innerHTML = attrs.msg;
          if (!Scopes.get('formInfoValidation')) {
            Scopes.store('formInfoValidation', [obj]);
          } else {
            temobj = Scopes.get('formInfoValidation');
            temobj.push(obj);
            Scopes.store('formInfoValidation', temobj);
          }
        }
      });
    }
  };
});
face2face.directive('notonlyZero', function (Scopes) {
  return {
    require: 'ngModel',
    restrict: '',
    link: function (scope, elm, attrs, ctrl) {

      // only apply the validator if ngModel is present and Angular has added the email validator
      angular.element(elm).on("blur", function (e) {
        var obj = { 'formName': attrs.name, 'msgId': attrs.messageid };
        if (this.value && this.value != 0) {
          document.getElementById(attrs.messageid).innerHTML = '';
          temobj = Scopes.get('formInfoValidation');
          if (temobj)
            temobj.splice(temobj.indexOf(obj), 1);
          Scopes.store('formInfoValidation', temobj);
        } else {
          document.getElementById(attrs.messageid).innerHTML = '<span>' + attrs.msg + '</span>';
          if (!Scopes.get('formInfoValidation')) {
            Scopes.store('formInfoValidation', [obj]);
          } else {
            temobj = Scopes.get('formInfoValidation');
            temobj.push(obj);
            Scopes.store('formInfoValidation', temobj);
          }
        }
      });
    }
  };
});

face2face.directive('responsiveTab', function (Scopes, $compile) {
  return {
    // require: 'ngModel',
    restrict: '',
    link: function (scope, elm, attrs, ctrl) {

      elm.on("click", function (e) {
        elm.toggleClass('open');

      });

    }
  };
});

face2face.directive('select', function ($timeout) {
  return {
    restrict: 'E',
    link: function (_, element) {
      if (ionic.Platform.isIOS()) {
        element.bind('touchstart', function (e) {
          $timeout(function () {
            if (window.cordova && window.cordova.plugins.Keyboard) {
              cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
            }
          })
        });
        element.bind('blur', function (e) {
          $timeout(function () {
            if (window.cordova && window.cordova.plugins.Keyboard) {
              cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            }
          });
        });
      }
    }
  }
})

face2face.directive('accessibleForm', function () {
  return {
    restrict: 'A',
    link: function (scope, elem, attrs) {
      //Finds y value of given object
      function findPos(obj) {
        var curtop = 0;
        if (obj.offsetParent) {
          do {
            curtop += obj.offsetTop;
          } while (obj = obj.offsetParent);
          return [curtop];
        }
      }
      // set up event handler on the form element
      scope.$on(attrs.accessibleForm, function () {

        // find the first invalid element
        var firstInvalid;
        var errorElemArr = [];
        var errorElemArray = elem[0].getElementsByClassName('error-message');
        if (scope.formName) {
          errorElemArr = scope.formName.getElementsByClassName('error-message');
        }
        var slice = Array.prototype.slice;
        var len = errorElemArr.length;
        if (len == 0) {
          errorElemArr = errorElemArray;
        } else {
          errorElemArr = slice.call(errorElemArr);
          errorElemArray = slice.call(errorElemArray);
          errorElemArr = errorElemArr.concat(errorElemArray);
        }
        for (var i = 0; i < errorElemArr.length; i++) {
          if (!!errorElemArr[i].firstElementChild && !!errorElemArr[i].firstElementChild.firstElementChild && errorElemArr[i].firstElementChild.firstElementChild.innerText) {
            // if(!!errorElemArr[i].previousElementSibling.previousElementSibling && errorElemArr[i].previousElementSibling.previousElementSibling.classList[0] == "moment-picker"){
            //   firstInvalid = errorElemArr[i].previousElementSibling.previousElementSibling.getElementsByTagName('input')[0];
            // }
            // else if(!!errorElemArr[i].parentElement && errorElemArr[i].parentElement.classList[0] == "state-input"){
            //   firstInvalid = errorElemArr[i].parentElement.getElementsByTagName('input')[0];
            // }
            // else if(!!errorElemArr[i].previousElementSibling.previousElementSibling && errorElemArr[i].previousElementSibling.previousElementSibling.classList[0] == "add-degree-field"){
            //   firstInvalid = errorElemArr[i].previousElementSibling.previousElementSibling.getElementsByTagName('input')[0];
            // }
            // else if(!!errorElemArr[i].previousElementSibling.previousElementSibling && errorElemArr[i].previousElementSibling.previousElementSibling.classList[0] == "commonError"){
            //   firstInvalid = errorElemArr[i].previousElementSibling.previousElementSibling.firstElementChild.firstElementChild.nextElementSibling;
            // }
            // else{

            firstInvalid = errorElemArr[i].parentElement.getElementsByTagName('input')[0];
            if (!firstInvalid) {
              firstInvalid = errorElemArr[i].parentElement.getElementsByTagName('select')[0];
            }
            // }
          }
          else if (errorElemArr[i].firstElementChild && (errorElemArr[i].firstElementChild.innerText || (!!errorElemArr[i].firstElementChild.nextElementSibling && errorElemArr[i].firstElementChild.nextElementSibling.innerText))) {
            if (!!errorElemArr[i].previousElementSibling.previousElementSibling && errorElemArr[i].previousElementSibling.previousElementSibling.classList[0] == "moment-picker") {
              firstInvalid = errorElemArr[i].previousElementSibling.previousElementSibling.getElementsByTagName('input')[0];
            }
            else if (errorElemArr[i].previousElementSibling.classList[0] == "add-degree-field") {
              firstInvalid = errorElemArr[i].previousElementSibling.getElementsByTagName('input')[0];
            }
            else if (errorElemArr[i].parentElement.classList[0] == "state-input") {
              firstInvalid = errorElemArr[i].parentElement.getElementsByTagName('input')[0];
            }
            else if (errorElemArr[i].previousElementSibling.classList[0] == "mandatory") {
              firstInvalid = errorElemArr[i].previousElementSibling.previousElementSibling;
            }
            else if (errorElemArr[i].previousElementSibling.localName == 'input') {
              firstInvalid = errorElemArr[i].previousElementSibling;
            } else if (errorElemArr[i].previousElementSibling.localName != 'input') {
              firstInvalid = errorElemArr[i].previousElementSibling.getElementsByTagName('input')[0];
            }
          }
          //console.log(firstInvalid)

          if (firstInvalid) {
            window.scroll(0, firstInvalid[0].scrollTop);
            //firstInvalid.scrollIntoView();
            return;
          }
        }

        // if we find one, set focus
      });
    }
  };
});

face2face.directive('submitOn', function () {
  return {
    link: function (scope, elm, attrs) {
      scope.$on(attrs.submitOn, function () {
        //We can't trigger submit immediately, or we get $digest already in progress error :-[ (because ng-submit does an $apply of its own)
        setTimeout(function () {
          alert(attrs.submitOn);
          alert(JSON.stringify(elm))
          debugger
          console.log(elm)
          elm.trigger('submit');
        });
      });
    }
  };
})
