 face2face.directive("signupTemplate", [
  function() {
    return {
           restrict: "E",
           templateUrl:'templates/signupTemplateAppointment.html'
        }
}]);

face2face.directive("appointmentCommonDropdown", [
  function() {
    return {
           restrict: "E",
            transclude:true,
           templateUrl:'templates/appointmentCommonTemplate.html'
        }
}]);

face2face.directive("providerSpeciality", [
  function() {
    return {
           restrict: "E",
           templateUrl:'modules/consumer/mutiProviderConsumer/templates/mutiProviderSpeciality.html'
        }
}]);
face2face.directive("multiProviderSelection", [
  function() {
    return {
           restrict: "E",
           templateUrl:'modules/consumer/mutiProviderConsumer/templates/multiProviderSelection.html'
        }
}]);

face2face.directive("multiProviderSelected", [
  function() {
    return {
           restrict: "E",
           templateUrl:'modules/consumer/mutiProviderConsumer/templates/multiProviderSelected.html'
        }
}]);