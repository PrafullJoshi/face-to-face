face2face.directive('uploadFile',function($parse){
  
	  return{
	  	restirct:'A',
	  	require : '^form',
	  	link:function(scope, elem, attrs,ctrl){
	  		var model = $parse(attrs.uploadFile);
	  		var modelSetter = model.assign;	  		           
	  		          angular.element(elem).on('change click', function(){
	  		          	if(elem[0].files[0]){
	  		          	scope.uploadDocFile(elem[0].files[0],attrs.filetype,ctrl,attrs.modelobj);
	  		               scope.$apply(function(){
	  		               	   /*console.log(attrs.uploadFile);
	  		               	   console.log('******');*/
	  		                   modelSetter(scope,elem[0].files[0]);
	  		                   
	  		                   attrs.fileName=elem[0].files[0].name;
	  		                   
	  		                   if(scope.noteDocData){
	  		                   	scope.noteDocData.docFileName = attrs.fileName;
	  		                   }		                  
    		                   else if(attrs.modelobj){
    		                   //	scope.formObj[attrs.modelobj] = attrs.fileName;
    		                   	scope.fObj[attrs.modelobj] = attrs.fileName;
	  		                   }
	  		                   else if(attrs.docoberr){
	  		                   	scope.uploadDoc[attrs.docoberr] = attrs.fileName;
	  		                   }
   
	  		               });
	  		          		
	  		          	}

	  		           });
	  	}

    }
 
});
face2face.directive("fileModel", ["$parse",function ($parse) {
    return {
        restrict: "A",
        link: function (scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            element.bind("change", function () {
                scope.$apply(function () {
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}])


// face2face.directive("ngFileSelect",function(){

//   return {
//     link: function($scope,el){
      
//       el.bind("change", function(e){
//       	console.log("dfsfSFDZSFSFSDFSDFSF: ",e);
//         $scope.file = (e.srcElement || e.target).files[0];
//         $scope.getFile=function(){

//         $scope.progress = 0;
//         fileReader.readAsDataUrl($scope.file, $scope)
//                       .then(function(result) {
//                           $scope.imageSrc = result;
//                       });
    
//         }
//       })
      
//     }
    
//   }
  
  
// });

face2face.directive('bindClick', function () {
    return {
      restrict: 'A',
      link: function(scope, element) {

        element.bind('click', function(e) {
        	scope.updateHelpparameters();
            //angular.element(e.target).trigger('click');
        });
      }
    };
});
