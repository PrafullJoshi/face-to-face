  face2face.filter('url',function($sce){
    return function(input){
        return $sce.trustAsResourceUrl(input);
    }
  });


  face2face.filter('ellipsis', function () {
    return function (text, length) {
        if (text.length > length) {
            return text.substr(0, length) + "...";
        }
        return text;
    }
});