// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
var face2face = angular.module('face2face', ['ionic', 'angularPayments', 'ui.rCalendar', 'ionic-ratings', 'ng-walkthrough'], function () {


  })
  .run(function ($ionicPlatform, $rootScope, Scopes, $state, $timeout, commonGetterService, logOut, loadingFactory) {

    $ionicPlatform.ready(function () {
      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs)
      if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
        cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
        cordova.plugins.Keyboard.disableScroll(true);

      }
      if (window.StatusBar) {
        // org.apache.cordova.statusbar required
        StatusBar.styleDefault();
      }
      IonicDeeplink.route({
        '/signin': {
          target: 'signin',
          parent: 'pre-signin'
        },
        '/inbox': {
          target: 'mainView.inbox',
        },
        '/proVirtualHealth': {
          target: 'mainView.proVirtualHealth',
        },
        '/conVirtualHealth': {
          target: 'mainView.conVirtualHealth',
        },
        '/communityListing': {
          target: 'mainView.communityListing',
        }
      }, function (match) {
        loadingFactory.show();
        $timeout(function () {
          if (match.$route.parent) {
            $state.go(match.$route.parent, match.$args);
          }
          $timeout(function () {
            loadingFactory.hide();
            var currentTime = new Date();
            var duration = currentTime - (new Date(localStorage.activityTime));
            duration = Math.round(((duration % 86400000) % 3600000) / 60000);
            localStorage.activityTime = currentTime;
            Scopes.delete('Inactivitycheck');
            $state.go(match.$route.target, match.$args);
          }, 800);
        }, 100);
      }, function (nomatch) {
        console.warn('No match', nomatch);
      })
      // notifictions callbacks
      window.FirebasePlugin.onNotificationOpen(commonGetterService.notificationReceivedCallBack, function (error) {
        alert(error);
      });

      window.FirebasePlugin.hasPermission(function (data) {
        if (!data.isEnabled) {
          window.FirebasePlugin.grantPermission();
        }
      });
      window.FirebasePlugin.onTokenRefresh(function (token) {
        // save this server-side and use it to push notifications to this device
        commonGetterService.updateNotificationToken(token);
      }, function (error) {
        //console.error(error);
      });


    });

    $ionicPlatform.onHardwareBackButton(function () {
      //$rootScope.$broadcast('backButtonEvent');
      if ($state.current.name == 'mainView.conDashboard' || $state.current.name == 'mainView.proDashboard') {
        ionic.Platform.exitApp();
      }
    });
    $rootScope.$on('$stateChangeSuccess', function (ev, to, toParams, from, fromParams) {
      $rootScope.previousScreen = from;
      if (!Scopes.get('appointmentData')) {
        Scopes.delete('formInfo');
      }
      Scopes.delete('formInfoValidation');
    })
    $rootScope.cusBack = false;
    window.addEventListener("click", function () {

      var currentTime = new Date();
      var duration = currentTime - (new Date(localStorage.activityTime));
      duration = Math.round(((duration % 86400000) % 3600000) / 60000);
      localStorage.activityTime = currentTime;
      if (!Scopes.get('Inactivitycheck')) {
        if (duration > 30) {
          logOut.logOut();
          localStorage.clear();
        }
      }
    });

  })

  .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider, $httpProvider) {
    $ionicConfigProvider.navBar.alignTitle('center');
    $ionicConfigProvider.backButton.previousTitleText(false).text('').icon("fa fa-angle-left");
    $httpProvider.defaults.useXDomain = true;
    //$httpProvider.interceptors.push('requestRecoverer'); 
    $ionicConfigProvider.views.swipeBackEnabled(false);
    //delete $httpProvider.defaults.headers.common['X-Requested-With'];
    //$ionicConfigProvider.backButton.text('').icon('ion-ios7-arrow-left');
    //$ionicConfigProvider.backButton.text('').icon("fa fa-angle-left");
    // Ionic uses AngularUI Router which uses the concept of states
    // Learn more here: https://github.com/angular-ui/ui-router
    // Set up the various states which the app can be in.
    // Each state's controller can be found in controllers.js
    $stateProvider

      // setup an abstract state for the tabs directive
      /* .state('tab', {
        url: '/tab',
        abstract: true,
        templateUrl: "template/left.html",
        controller:function ($scope, $ionicSideMenuDelegate) {
      $scope.toggleLeft = function() {
        $ionicSideMenuDelegate.toggleLeft();
      };
      $scope.template = 'template/1stmenu.html';
      $scope.menuChange = function(template){
        $scope.template = template;
      }
      }


      })*/

      // Each tab has its own nav history stack:
      .state('pre-signin', {
        url: '/pre-signin',
        templateUrl: "templates/pre-signin.html"
        // templateUrl: '',
        //controller: 'DashCtrl'
      })


      .state('signin', {
        url: '/signin',
        templateUrl: "modules/main/login/template/patient-sign-in.html",
        controller: 'loginCtrl'
        //templateUrl: '',
      })
      .state('signup', {
        url: '/signup',
        templateUrl: "modules/main/presignupPage/template/signup-option.html",
        controller: 'presignupctrl'
        //templateUrl: 'template/signup-option.html',
      })

      .state('forgotPassword', {
        url: '/forgotPassword',
        templateUrl: "modules/main/forgotPassword/templates/patient-forgot-password.html",
        //controller:''
        //templateUrl: 'template/signup-option.html',
      })
      .state('mainView', {
        url: '/mainView',
        // abstract:true,
        templateUrl: 'modules/main/mainView/template/mainView.html',
        // controller: 'mainView'
      })
      .state('mainView.conDashboard', {
        url: '/condashboard',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/dashboard/template/condashboard.html',
            controller: 'conDashboard'

          }
        }
      })
      .state('mainView.proDashboard', {
        url: '/prodashboard',
        views: {
          'menuContent': {
            templateUrl: 'modules/provider/dashboard/template/prodashboard.html',
            controller: 'conDashboard'

          }
        }
      })
      .state('mainView.inbox', {
        url: '/inbox',
        views: {
          'menuContent': {
            templateUrl: 'templates/inbox.html',
            controller: 'inboxCtrl'

          }
        }


      })
      .state('mainView.inboxDetail', {
        url: '/inboxDetail/:id',
        views: {
          'menuContent': {
            templateUrl: 'templates/inbox-full-view.html',
            controller: 'inboxDetailsCtrl'
          }
        }

      })
      .state('mainView.consumerProfile', {
        url: '/consumerProfile',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/consumerProfile/template/consumerProfile.html',
            controller: 'consumerProfile'
          }
        }

      })
      .state('mainView.changePass', {
        url: '/changePass',
        views: {
          'menuContent': {
            templateUrl: 'templates/changePassword.html',
            controller: 'changePass'
          }
        }

      })

      .state('mainView.proVirtualHealth', {
        url: '/proVirtualHealth?id',
        views: {
          'menuContent': {
            templateUrl: 'modules/provider/virtualHealth/template/virtualHealth.html',
            controller: 'virtualHealthCtrl'
          }
        }

      })
      .state('mainView.manageBilling', {
        url: '/manageBilling?id',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/billing/template/billing-manage.html',
            controller: 'consumerBilling'

          }
        }
      })
      .state('mainView.dashboardCon', {
        views: {
          'menuContent': {
            url: '/dashboardConsumer',
            templateUrl: "templates/dashBoardTemp.html",
            //controller:''
            //templateUrl: 'template/signup-option.html',
          }
        }
      })
      .state('mainView.contactUs', {
        url: '/contactUs',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/contactUs/template/contactUs.html',
            controller: 'contactUs'
          }
        }
      })
      .state('mainView.communityListing', {
        url: '/communityListing',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/community/template/community.html',
            controller: 'communityCtrl'
          }
        }
      })
      .state('mainView.communityForums', {
        url: '/communityForums/',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/community/template/forums.html',
            controller: 'communityForumsCtrl'
          }
        }
      })
      .state('mainView.communityWebinars', {
        url: '/communityWebinars',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/community/template/webinars.html',
            controller: 'webinarListingCtrl'
          }
        }
      })
      .state('mainView.communityWebinarsDtls', {
        url: '/communityWebinarsDtls/:webinarurl/:webinartopic/:webinarpresenter/:id/:webinarType',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/community/template/webinarDetails.html',
            controller: 'webinarDtlsCtrl'
          }
        }
      })
      .state('mainView.communityForumsDetails', {
        url: '/communityForumsDetails/:sId',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/community/template/forums-single.html',
            controller: 'communityForumsDetailsCtrl'
          }
        }
      })
      .state('mainView.communityForumsPosts', {
        url: '/communityForumsPosts/:id',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/community/template/forum-post.html',
            controller: 'communityForumsPostCtrl'
          }
        }
      })
      .state('mainView.proEditProfile', {
        url: '/proEditProfile',
        views: {
          'menuContent': {
            templateUrl: 'modules/provider/providerEdit/template/provider-edit-profile.html',
            controller: 'proEditProfile'
          }
        }
      })
      .state('mainView.conCalendar', {
        cache: false,
        url: '/conCalendar/:type',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/calendar/template/calendar.html',
            controller: 'conCalendarCtrl'
          }
        }
      })
      .state('mainView.scheduledAppoinment', {
        url: '/scheduledAppoinment/:type/:location',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/scheduleAppointment/template/appoinment.html',
            controller: 'conScheduledCtrl'
          }
        }
      })
      .state('mainView.onDemand', {
        url: '/conOnDemand',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/scheduleAppointment/template/onDemand.html',
            controller: 'conOnDemandCtrl'
          }
        }
      })
      .state('mainView.pickTimeAppointment', {
        url: '/pickTimeAppointment/:type',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/scheduleAppointment/template/pickTimeAppointment.html',
            controller: 'conScheduledPickTimeCtrl'
          }
        }
      })

      .state('mainView.providerListing', {
        url: '/providerListing/:type',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/scheduleAppointment/template/ProviderListing.html',
            controller: 'providerListingCtrl'
          }
        }
      })
      .state('mainView.thankYou', {
        url: '/thankYou',
        views: {
          'menuContent': {
            templateUrl: 'templates/thankYou.html',
          }
        }
      })
      .state('mainView.providerListingMulti', {
        url: '/providerListingMulti/:type',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/scheduleAppointment/template/providerlistingforMultiprovider.html',
            controller: 'providerListingMultiCtrl'
          }
        }
      })

      .state('mainView.addPatient_2', {
        url: '/addPatientForm2',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/addPatient/templates/add-patient.html',
            controller: 'addPatient'
          }
        }
      })
      .state('mainView.addPatient_1', {
        url: '/addPatientForm1',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/addPatient/templates/add-patient-1.html',
            controller: 'addPatient'
          }
        }
      })
      .state('mainView.addPatient_3', {
        url: '/addPatientForm3',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/addPatient/templates/add-patient-2.html',
            controller: 'addPatient'
          }
        }
      })
      .state('mainView.addPatient_4', {
        url: '/addPatientForm1',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/addPatient/templates/add-patient-3.html',
            controller: 'addPatient'
          }
        },
        cache: true
      })
      .state('mainView.conVirtualHealth', {
        url: '/conVirtualHealth?id',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/virtualHealth/template/virtualHealth.html',
            controller: 'virtualHealthCtrl'
          }
        }

      })

      .state('mainView.conVirtualHealth.Conscheduled', {
        views: {
          'virtualHealthTab': {
            url: '/conscheduled',
            templateUrl: "modules/consumer/virtualHealth/template/conscheduled.html",
            //controller:''
            //templateUrl: 'template/signup-option.html',
          }
        }
      })
      .state('mainView.conVirtualHealth.Conrequested', {
        views: {
          'virtualHealthTab': {
            url: '/conrequested',
            templateUrl: "modules/consumer/virtualHealth/template/conrequested.html",

            //controller:''
            //templateUrl: 'template/signup-option.html',
          }
        }
      })
      .state('mainView.providerConsultRoom', {
        url: '/providerConsultRoom/:type',
        views: {
          'menuContent': {
            templateUrl: 'modules/provider/consultWaitingRoom/template/providerconsultRoom.html',
            controller: 'videoConsultingRoomCtrl'
          }
        },
        cache: false

      })
      .state('mainView.consumerConsultRoom', {
        url: '/consumerConsultRoom/:type',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/consultWaitingRoom/template/consumerWaiting.html',
            controller: 'consultationWaitingRoomCtrl'
          }
        },
        cache: false

      })
      .state('mainView.eLearning', {
        url: '/eLearning',
        views: {
          'menuContent': {
            templateUrl: 'modules/consumer/e-learning/template/e-learning.html',
            controller: 'eLearningCtrl'
          }
        }

      })
      .state('mainView.setting', {
        url: '/setting',
        views: {
          'menuContent': {
            templateUrl: 'modules/main/appSetting/template/app-setting.html',
            controller: 'appSettingCtrl'
          }
        }

      })
      .state('mainView.providerBilling', {
        url: '/providerBilling',
        views: {
          'menuContent': {
            templateUrl: 'modules/provider/billing/template/billing.html',
            controller: 'providerBillingCtrl'

          }
        }
      })

      .state('mainView.providerPatientList', {
        url: '/providerPatientList',
        views: {
          'menuContent': {
            templateUrl: 'modules/provider/patient/template/patientList.html',
            controller: 'providerPatientCtrl'

          }
        }
      })

    // if none of the above states are matched, use this as the fallback
    //$urlRouterProvider.otherwise('/pre-signin');
    $urlRouterProvider.otherwise(function ($injector, $location) {
      if (!localStorage.userData) {
        return '/pre-signin';
      } else {
        var userData = JSON.parse(localStorage.userData);
        if (userData.userTypeId == 2) {
          return '/mainView/condashboard';
        } else {
          return '/mainView/prodashboard';
        }
      }
    });

  });
