
face2face.controller("changePass",function($scope,$injector,$state,globalConstants,serverRequestFactory,$window,validatePass,$rootScope,requiredFactory,toastMsg,loadingFactory) {

  $scope.data = {};
  $scope.showMsg = false;
  $scope.passData = {
        email:  JSON.parse($window.localStorage['userData']).email,
        username: JSON.parse($window.localStorage['userData']).username,
       
     };
  

  $scope.data.signin = function(form) {
    var promise;
    $scope.passData.validateFlag = true;
    document.getElementById("con-password").innerHTML ='';
      if(requiredFactory.validateBeforeSubmit(form,$scope)){
      var token = JSON.parse($window.localStorage['userData']).token;
      if( $scope.data.validateAftersub()){
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.changePass,'POST',{"old_password":$scope.passData.old_password,"password":$scope.passData.password,"confirm_password":$scope.passData.confirm_password},token);  // the change password api 
        promise.then(function(res){         
          if(res.data.status == true ){
            $scope.passData = {};
            toastMsg.show("Password Changed Succesfully");
            loadingFactory.hide();
          }else if(res.data.status == false){
            loadingFactory.hide();
              if((res.data.message).hasOwnProperty('old_password')){
                toastMsg.show("New password can not be same as old password");
              }else{
                toastMsg.show("Either the old password is incorrect or the user is unauthorised");
              } 
         }
        
        },function(err){

        });
      }else{
          document.getElementById("con-password").innerHTML = globalConstants.errorMessages.confirmPassword;
      }
     
    }
   
  };
  $scope.data.validateAftersub = function(){
    var res = validatePass.validate($scope.passData.password,$scope.passData.confirm_password,$scope.passData.email,$scope.passData.username)

    $scope.passData.validateFlag = res.flag;
    /*if(res.confirm)
      $scope.passData.errPassMssg = res.msg;
    else
      $scope.passData.errPassMsg = res.msg;*/

    return $scope.passData.validateFlag;
  }
  // $scope.back=function(){
  //   $state.go($rootScope.previousState);
  // }


});

