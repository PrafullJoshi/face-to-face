face2face.controller("commonCtrl", function ($scope, $rootScope, $window, $state, serverRequestFactory, globalConstants, loadingFactory, $ionicHistory, $ionicListDelegate, commonGetterService, showModalService) {

  $scope.count = 0; // count of unread inbox msg

  $scope.toggleLeftSideMenu = function () {
    $ionicListDelegate.closeOptionButtons();
  }
  $rootScope.showMenu = true;
  $scope.menuChange = function (temp) {
    if ($window.localStorage['userData']) {
      userData = JSON.parse($window.localStorage['userData']);
    }
    if (userData.userTypeId == 2) {
      if (temp == "modules/main/mainView/template/submenu.html") {
        $rootScope.mTemplate = "modules/main/mainView/template/submenu.html";
      } else {
        $rootScope.mTemplate = "modules/main/mainView/template/menu.html";
      }

    } else {
      if (temp == "modules/main/mainView/template/submenu.html") {
        $rootScope.mTemplate = "modules/main/mainView/template/submenu.html";
      } else {
        $rootScope.mTemplate = "modules/main/mainView/template/menuProvider.html";
      }

    }


  }
  var inAppBrowserRef;
  $scope.changeTab = function (val) {
    if ($window.localStorage['userData']) {
      var userData = JSON.parse($window.localStorage['userData']);
    }
    $rootScope.menuSelected = val;
    if (val == 'emr') {
      commonGetterService.openEmr();
    }
  }

  $scope.navigate = function (val) {
    if ($window.localStorage['userData']) {
      userData = JSON.parse($window.localStorage['userData']);
    }
    switch (val) {
      case 'virtualHealth':
        if (userData.userTypeId == 1) {
          $state.go("mainView.proVirtualHealth");
        } else {
          $state.go("mainView.conVirtualHealth");
        }
        break;
      case 'profile':
        if (userData.userTypeId == 2) {
          $state.go("mainView.consumerProfile");
        } else {
          $state.go("mainView.dashboardCon");
        }
        break;
      case 'privacy':
        window.open(globalConstants.gHost + '/#/main/privacyTerms', '_blank', 'location=yes');
        break;
      case 'aboutUs':
        window.open(globalConstants.gHost + '/#/main/aboutus', '_blank', 'location=yes');
        break;

    }

  }

  $scope.logout = function () {
    if ($window.localStorage['userData']) {
      var userData = JSON.parse($window.localStorage['userData']);
    }
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.logout, 'GET', '', userData.token);
    promise.then(function (res) {
      if (res.data.status == true) {
        $window.localStorage.clear();
        $ionicHistory.clearCache()
        loadingFactory.hide();
        $state.go('signin');

      } else if (res.status == false) {
        loadingFactory.hide();
      }


    }, function (err) {
      loadingFactory.hide();
    })

  }

  $scope.checkforOnDemand = function (type) {
    if (type == 'check') {
      commonGetterService.checkOndemandAvailability($scope);
    } else if (type == 'yes') {
      $state.go('mainView.scheduledAppoinment', {
        type: 'S',
        location: 'VH'
      })
      showModalService.hide(true);
    } else {
      showModalService.hide(true);
    }
  }





})
