face2face.controller("inboxCtrl",function($scope,globalConstants,serverRequestFactory,$state,inboxService,Scopes,loadingFactory,$ionicListDelegate,$rootScope,$ionicNavBarDelegate,$ionicHistory) {
 /** To get the token from localstorage **/
  loadingFactory.show();
   if(localStorage.userData){
     var userData = JSON.parse(localStorage.userData);
     var token = userData.token;
     if(userData.userTypeId == 1){
       $scope.providermail = true;
     }
     else{
       $scope.providermail = false;
     }
   }
    $scope.inboxData = [];
    $scope.data = {};
    $scope.value = 10;
    $scope.callfrom = '';
    $scope.currentPage = 0;
    
    $scope.getMails=function(from,pageno,type){

    if(type=="trashUndo"){
      var l = $scope.deletedMail.length;
    }
    $scope.deletedMail = [];
    $scope.callfrom = from;
    if(pageno)
      $scope.currentPage = pageno;
    //alert($scope.currentPage);
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.inboxDetail+($scope.currentPage), 'POST', 
      {
          "status": from,
          "limit":$scope.value

      }, token);
                     
    promise.then(function(res) {
    loadingFactory.hide();
      if (res.data.status==true && res.data.data.inbox.length>0) {
        if($scope.currentPage >1){
          $scope.inboxData=$scope.inboxData.concat(res.data.data.inbox);
          $scope.$broadcast('scroll.infiniteScrollComplete');
        }else{
          
          $scope.inboxData = res.data.data.inbox;

        }
        $scope.nomsg = false;
        if(res.data.data.page.count <= $scope.inboxData.length){
            $scope.loadmore = false;
        }else{
            $scope.loadmore = true;
        }
        $scope.$parent.count = res.data.data.count;
        $scope.pageData = res.data.data.page;
        //$scope.currentPage = $scope.pageData.page;  
        if($scope.pageData.page == 1){
          $scope.first = 1;
          $scope.last = $scope.pageData.current;
        }
        else if($scope.pageData.page > 1 && $scope.pageData.page != $scope.pageData.pageCount){
          $scope.first = ($scope.pageData.perPage * ($scope.pageData.page - 1))  + 1;
          $scope.last = $scope.pageData.perPage * $scope.pageData.page; 
        }
        else if($scope.pageData.page > 1 && $scope.pageData.page == $scope.pageData.pageCount){
          $scope.first = ($scope.pageData.perPage * ($scope.pageData.page - 1))  + 1;
          $scope.last = $scope.pageData.count;  
        }
      } else if(res.data.status==true && res.data.data.inbox.length == 0){
        $scope.$parent.count = res.data.data.count;
        $scope.nomsg = true;
      }else {
          $scope.nomsg = true;
      }
    }, function(err) {
    });

  }
  $scope.getMails('',1);
  $scope.loadMore = function(){
    $scope.currentPage++;
    $scope.getMails('',$scope.currentPage);
    // alert("loadmore");

  }

  $scope.deleteMail = function(record,index){
    if(record.id){
      $scope.deletedMail.push(record.id);
      inboxService.deleteMail($scope,'',token,'',index);
    }
    
  }

  $scope.markStar = function(id,index,e){
    e.stopPropagation(); // to prevent perent calling 
    inboxService.markStar(id,index,$scope,token)
  }

  $scope.readMsg = function(id,index,isRead){
    $scope.currentIndex = index;
    $state.go("mainView.inboxDetail",{id:id});
    // var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.readMessage+id, 'GET', {}, token);
    //   promise.then(function(res) {
    //     if (res.data.status==true && res.data.data != "None") {
          if(isRead == 'N'){
            $scope.$parent.count = $scope.$parent.count - 1;
          }
    //       Scopes.store('inboxData',res.data.data[0]);
    //       $state.go("mainView.inboxDetail",{id:res.data.data[0]});
    //     } else {
    //     }
    //   }, function(err) {
    //   });
  }
  $scope.$on('$ionicView.enter', function(){
    $ionicHistory.clearCache();
    if(angular.isDefined($scope.currentIndex) && ($scope.currentIndex == 0||$scope.currentIndex!='')){
      if(Scopes.get('delete')){
        $scope.inboxData.splice($scope.currentIndex,1);
        $scope.currentIndex = '';
      }else{
        $scope.inboxData[$scope.currentIndex] = Scopes.get('inboxData');
      }
    }
     $ionicListDelegate.closeOptionButtons();
     $rootScope.menuSelected = "Inbox";
  })
  
  $scope.$on('$ionicView.leave', function(){
    $ionicListDelegate.closeOptionButtons();
  })
  
  $scope.$on('$ionicView.beforeEnter', function (e, data) {
   
    if($rootScope.previousScreen.name == 'mainView.conDashboard' || $rootScope.previousScreen.name == 'mainView.proDashboard' ){
      enableBack = true;
    }else{
      enableBack = false;
    }
    $ionicNavBarDelegate.showBackButton(enableBack);
    data.enableBack = enableBack;
    $rootScope.showMenu = !enableBack;
  });

})
