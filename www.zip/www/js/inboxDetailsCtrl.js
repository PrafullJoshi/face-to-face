face2face.controller("inboxDetailsCtrl",function($scope, globalConstants,serverRequestFactory, $rootScope, $state, $timeout,inboxService,Scopes,$ionicNavBarDelegate,loadingFactory,$stateParams) {
 /** To get the token from localstorage **/
  //var token  = "818e3562-2975-4e72-998c-c5b5f29cade7";    
 //var token  = "acdc587e-c105-4d89-889e-d68bd491497e";
 //var token = "01f0ce6e-18a7-4ab2-91ba-3087c214e01c"; // rimpi
 $rootScope.menuSelected = "Inbox";
 $ionicNavBarDelegate.showBackButton(true);
 $scope.deletedMail =[];            
  if(localStorage.userData){
    var userData = JSON.parse(localStorage.userData);
    var token = userData.token;
  }
  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.readMessage+$stateParams.id, 'GET', {}, token);
      promise.then(function(res) {
        if (res.data.status==true && res.data.data != "None") {
          // if(isRead == 'N'){
          //   $scope.$parent.count = $scope.$parent.count - 1;
          // }
          $scope.inboxData = res.data.data[0];
          loadingFactory.hide();
        } else {
          loadingFactory.hide();
        }
      }, function(err) {
    });
  $scope.deleteMail = function(id){
    if(id){
      $scope.deletedMail.push(id);
    }
    inboxService.deleteMail($scope,'',token,'details');
  }

  $scope.markStar = function(id,index){
    inboxService.markStar(id,index,$scope,token)
  }
  $scope.goBack = function(){
    Scopes.store('inboxData',$scope.inboxData);
    $state.go('mainView.inbox');
  }


  $scope.$on('$ionicView.beforeEnter', function (e, data) {
    $ionicNavBarDelegate.showBackButton(false);
    data.enableBack = false;
    $rootScope.showMenu = false;
  });

});
