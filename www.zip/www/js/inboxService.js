/*
* @Service  to get Patients list for consumer and providers
* @Author
*/
face2face.service('inboxService',function(serverRequestFactory,globalConstants,$ionicListDelegate,$state,loadingFactory,Scopes){
   //console.log(face2face);
    /*
    * Function to delete mails 
    @parameters #slientCall - to show loader or not 
    */
    this.deleteMail = function(scope,slientCall,token,from,index){
      if(scope.callfrom == 'Deleted' && scope.deletedMail.length !=0){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.deleteTrashMail, 'PUT', 
        {
            "deleted_ids": scope.deletedMail
        }, token);
      promise.then(function(res) {
        if (res.data.status==true && res.data.data == "None") {
          loadingFactory.hide();
          if(scope.deletedMail.length == scope.pageData.current && scope.pageData.page == scope.pageData.pageCount){
            scope.currentPage = scope.currentPage - 1;
          }
          scope.getMails(scope.callfrom,scope.currentPage);

        } else {
         loadingFactory.hide();
        }
      }, function(err) {
        loadingFactory.hide();
      });
    } else{
      if(scope.deletedMail.length !=0){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.deleteMails, 'PUT', 
          {
              "deleted_ids": scope.deletedMail
          }, token);
        promise.then(function(res) {
          if (res.data.status==true && res.data.data == "None") {
            if(from == "details"){
              Scopes.store('delete',true);
              loadingFactory.hide();
              $state.go("mainView.inbox");
            }else{
              $ionicListDelegate.closeOptionButtons();
              // if(scope.deletedMail.length == scope.pageData.current && scope.pageData.page == scope.pageData.pageCount){
              //   scope.currentPage = scope.currentPage - 1;
              // }
              // console.log(scope.value);
              // scope.value = scope.currentPage * 10;
              // console.log(scope.value);
              scope.inboxData.splice(index,1);
              //scope.getMails(scope.callfrom,scope.currentPage);
              loadingFactory.hide();
            }

          } else {
            loadingFactory.hide();
          }
        }, function(err) {
          loadingFactory.hide();
        });
      }
      
    }
  }
  this.markStar = function(id,index,scope,token){
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.markStar+id, 'GET', {}, token);
      promise.then(function(res) {
        if (res.data.status==true && res.data.data != "None") {
          if(angular.isDefined(index)){
            // $scope.inboxData.splice(index,0);
            scope.inboxData[index].star = res.data.data[0].star;
          }else{
            scope.inboxData.star = res.data.data[0].star;

            // $scope.inboxData.splice($scope.currentIndex,0);
            //scope.inboxData[scope.currentIndex].star = res.data.data[0].star;
          }
          loadingFactory.hide();
        } else {
        loadingFactory.hide();
        }
      }, function(err) {
      loadingFactory.hide();
      });
  }



})
