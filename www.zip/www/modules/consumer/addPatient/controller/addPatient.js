/**
@controller for addPatient

**/
face2face.controller('addPatient',function($scope,globalConstants,serverRequestFactory,requiredFactory,otherValidationCheck,commonGetterService,toastMsg,loadingFactory,$state,validateDate,$rootScope,$ionicNavBarDelegate,$ionicHistory,Scopes,$timeout,$window,$ionicScrollDelegate,$location,$ionicSlideBoxDelegate,showModalService){


$scope.daterrMsgp3 = '';
$scope.daterrMsgp2 = '';
$scope.daterrMsg = '';
$scope.fatherDaterrMsg = '';
$scope.policyErrMsg = '';
$scope.declation = '';
$scope.chckdeclaration = '';
$scope.childLivesWithList = globalConstants.childLivesWithList;
$scope.infoBy = globalConstants.infoBy;
$scope.genderList = globalConstants.genderList;
$scope.patientInformationOfDropDown = globalConstants.patientInformationOfDropDown;

var screenNumber =[1,2,3];
var patientId = ''
var token = commonGetterService.getToken();
commonGetterService.getStates($scope);


 if($rootScope.previousScreen.name == ""||$rootScope.previousScreen.name == "mainView.addPatient_1" || $rootScope.previousScreen.name == "mainView.addPatient_2" ||$rootScope.previousScreen.name == "mainView.addPatient_3"){
   
 }
 else{

 }


 if($state.current.name == "mainView.addPatient_1"){    // keeps the fields prefilled when user clicks previous button 

    if(localStorage.patientData != undefined && localStorage.patientData != ''){
      $scope.addPat=JSON.parse(localStorage.patientData);
    }else{
     $scope.addPat = {
         patient_parent:{
          martial_status:"",
          primary_relation:""
        },
        patient_authorization_form: {},
        patient_insurances:{
         "0" : {},
         "1" : {}
        }
       }

       showInformation();

    }

} else{
  //alert(localStorage.patientData)
    if(localStorage.patientData != undefined && localStorage.patientData != '' ){
      $scope.addPat=JSON.parse(localStorage.patientData);
    }
    if($state.current.name == "mainView.addPatient_4"){
      $scope.services = globalConstants.careTeamServices
      $scope.patient_careteams = [{service:'',name:'',address:'',email:'',phone:'',current_dates:''}];
      if(angular.isDefined($scope.addPat.patient_careteams) && $scope.addPat.patient_careteams.length >0){
        $scope.patient_careteams = $scope.addPat.patient_careteams;
      }
   }
}
$scope.addPatientpg = {
  
  goToPage2:function(form){  // check if mandatory fields are not empty at page 1
       $scope.relErr = false;
       var primarValid = {}
       angular.copy(validateDate.validateDt($scope.addPat.patient_parent.primary_dob,'motherDOB'),primarValid); 
       var secondaryValid = {}
       angular.copy(validateDate.validateDt($scope.addPat.patient_parent.secondary_dob,'fatherDOB'),secondaryValid)
       var othervalidStep1 = otherValidationCheck.validateBeforeSubmit();
       if(requiredFactory.validateBeforeSubmit(form,$scope) && othervalidStep1 && $scope.addPat.patient_parent.primary_relation){
         // to validate DOB

          if(primarValid.flag && secondaryValid.flag){
           
            $scope.addPat.patient_parent.martial_status = ($scope.addPat.patient_parent.martial_status) ? $scope.addPat.patient_parent.martial_status : '';
            $scope.addPat.patient_parent.primary_relation = ($scope.addPat.patient_parent.primary_relation) ? $scope.addPat.patient_parent.primary_relation : '';
            $scope.addPat.patient_parent.secondary_relation = ($scope.addPat.patient_parent.secondary_relation) ? $scope.addPat.patient_parent.secondary_relation : '';
            $scope.addPat.patient_parent.primary_cell_no = ($scope.addPat.patient_parent.primary_cell_no) ? $scope.addPat.patient_parent.primary_cell_no : '';
            $scope.addPat.patient_parent.primary_home_phone_no = ($scope.addPat.patient_parent.primary_home_phone_no) ? $scope.addPat.patient_parent.primary_home_phone_no : '';
            $scope.addPat.patient_parent.primary_employer = ($scope.addPat.patient_parent.primary_employer) ? $scope.addPat.patient_parent.primary_employer : '';
            $scope.addPat.patient_parent.primary_work_phone_no = ($scope.addPat.patient_parent.primary_work_phone_no) ? $scope.addPat.patient_parent.primary_work_phone_no : '';
            $scope.addPat.patient_parent.secondary_fname = ($scope.addPat.patient_parent.secondary_fname) ? $scope.addPat.patient_parent.secondary_fname : '';
            $scope.addPat.patient_parent.secondary_lname = ($scope.addPat.patient_parent.secondary_lname) ? $scope.addPat.patient_parent.secondary_lname : '';
            $scope.addPat.patient_parent.secondary_dob = ($scope.addPat.patient_parent.secondary_dob) ? $scope.addPat.patient_parent.secondary_dob : '';
            $scope.addPat.patient_parent.secondary_ssn_no = ($scope.addPat.patient_parent.secondary_ssn_no) ? $scope.addPat.patient_parent.secondary_ssn_no : '';
            $scope.addPat.patient_parent.secondary_address = ($scope.addPat.patient_parent.secondary_address) ? $scope.addPat.patient_parent.secondary_address : '';
            $scope.addPat.patient_parent.secondary_work_phone_no = ($scope.addPat.patient_parent.secondary_work_phone_no) ? $scope.addPat.patient_parent.secondary_work_phone_no : '';
            $scope.addPat.patient_parent.secondary_employer = ($scope.addPat.patient_parent.secondary_employer) ? $scope.addPat.patient_parent.secondary_employer : '';
            $scope.addPat.patient_parent.secondary_cell_no = ($scope.addPat.patient_parent.secondary_cell_no) ? $scope.addPat.patient_parent.secondary_cell_no : '';
            $scope.addPat.patient_parent.secondary_home_phone_no = ($scope.addPat.patient_parent.secondary_home_phone_no) ? $scope.addPat.patient_parent.secondary_home_phone_no : '';
            $scope.addPat.patient_parent.secondary_city = ($scope.addPat.patient_parent.secondary_city) ? $scope.addPat.patient_parent.secondary_city : '';
            $scope.addPat.patient_parent.secondary_zipCode = ($scope.addPat.patient_parent.secondary_zipcode) ? $scope.addPat.patient_parent.secondary_zipcode : '';
            $scope.addPat.patient_parent.secondary_state_id = ($scope.addPat.patient_parent.secondary_state_id) ? $scope.addPat.patient_parent.secondary_state_id : '';
            localStorage.patientData = JSON.stringify($scope.addPat); 
            $state.go("mainView.addPatient_3");
            window.scrollTo(0,0);

          }
          else{
             if(primarValid)
             $scope.daterrMsg = primarValid.msg;
             if(secondaryValid)
             $scope.fatherDaterrMsg = secondaryValid.msg;
            
          }

       
       }
       else{
        if(!$scope.addPat.patient_parent.primary_relation){
         $scope.relErr = true;
        }
       }
    
  },

  goToPage3:function(form){
   $scope.addPat.patient_authorization_form.patient_first_name = $scope.addPat.fname ;
   $scope.addPat.patient_authorization_form.patient_last_name = $scope.addPat.lname ;
   $scope.addPat.patient_authorization_form.patient_dob = $scope.addPat.dob;
  
    if(requiredFactory.validateBeforeSubmit(form,$scope) && otherValidationCheck.validateBeforeSubmit() && $scope.checkDeclaration()){ // check if mandatory fields are not empty at page 2
      var childValid = {flag: true};
      if($scope.addPat.information_of == $scope.patientInformationOfDropDown[1]){
        angular.copy(validateDate.validateDt($scope.addPat.dob,'childDOB'),childValid); 
      }

        if(childValid.flag){
          if($scope.checkPolicy()){
            $scope.addPat.patient_insurances[0].type = 'P';
            $scope.addPat.patient_insurances[1].type = 'S';
            $scope.addPat.child_lives_with = ($scope.addPat.child_lives_with)?$scope.addPat.child_lives_with :'';
            $scope.addPat.primary_care_physician = ($scope.addPat.primary_care_physician)?$scope.addPat.primary_care_physician :'';
            //$scope.addPat.release_info_authrization = ($scope.addPat.release_info_authrization)? $scope.addPat.release_info_authrization :'';
            $scope.addPat.patient_parent.emergency_contact_fname = ($scope.addPat.patient_parent.emergency_contact_fname) ? $scope.addPat.patient_parent.emergency_contact_fname : '';
            $scope.addPat.patient_parent.emergency_contact_lname = ($scope.addPat.patient_parent.emergency_contact_lname) ? $scope.addPat.patient_parent.emergency_contact_lname : '';
            $scope.addPat.patient_parent.emergency_contact_address = ($scope.addPat.patient_parent.emergency_contact_address) ? $scope.addPat.patient_parent.emergency_contact_address : '';
           
            $scope.addPat.patient_parent.emergency_contact_home_no = ($scope.addPat.patient_parent.emergency_contact_home_no) ? $scope.addPat.patient_parent.emergency_contact_home_no : '';
            $scope.addPat.patient_parent.emergency_contact_cell_no = ($scope.addPat.patient_parent.emergency_contact_cell_no) ? $scope.addPat.patient_parent.emergency_contact_cell_no : '';
            $scope.addPat.patient_insurances[0].company_name = ($scope.addPat.patient_insurances[0].company_name) ? $scope.addPat.patient_insurances[0].company_name : '';
            $scope.addPat.patient_insurances[0].holder_name = ($scope.addPat.patient_insurances[0].holder_name) ? $scope.addPat.patient_insurances[0].holder_name : '';
            $scope.addPat.patient_insurances[0].policy_number = ($scope.addPat.patient_insurances[0].policy_number) ? $scope.addPat.patient_insurances[0].policy_number : '';
            $scope.addPat.patient_insurances[1].company_name = ($scope.addPat.patient_insurances[1].company_name) ? $scope.addPat.patient_insurances[1].company_name : '';
            $scope.addPat.patient_insurances[1].holder_name = ($scope.addPat.patient_insurances[1].holder_name) ? $scope.addPat.patient_insurances[1].holder_name : '';
            $scope.addPat.patient_insurances[1].policy_number = ($scope.addPat.patient_insurances[1].policy_number) ? $scope.addPat.patient_insurances[1].policy_number : '';                
                            
            localStorage.patientData = JSON.stringify($scope.addPat);
            window.scrollTo(0,0);
            if($scope.addPat.information_of == $scope.patientInformationOfDropDown[0]) {
              $state.go("mainView.addPatient_3");
            }else{
              $state.go("mainView.addPatient_2");
            }
           
            
          }
          else{
            $scope.policyErrMsg = "Policy numbers can't be same";
          }
   
             
          }
          else{
             if(childValid)
             $scope.daterrMsgp2 = childValid.msg;
            
          }
        }
  
   

  },
  goToPage4:function(form){
    var othervalid = otherValidationCheck.validateBeforeSubmit();
      if(requiredFactory.validateBeforeSubmit(form,$scope) && othervalid){   // check if mandatory fields are not empty at page 3
          if($scope.checkReason()){
            if(validateDate.validateDt($scope.addPat.patient_authorization_form.patient_dob,'').flag){
              $scope.addPat.patient_authorization_form.name_of_person = ($scope.addPat.patient_authorization_form.name_of_person) ? $scope.addPat.patient_authorization_form.name_of_person : '';
              $scope.addPat.patient_authorization_form.relationship_to_patient = ($scope.addPat.patient_authorization_form.relationship_to_patient) ? $scope.addPat.patient_authorization_form.relationship_to_patient : '';  
              $scope.addPat.patient_authorization_form.reason_for_disclosure = ($scope.addPat.patient_authorization_form.reason_for_disclosure) ? $scope.addPat.patient_authorization_form.reason_for_disclosure : '';  
              localStorage.patientData = JSON.stringify($scope.addPat);
              //localStorage.patientId = 155
              $state.go('mainView.addPatient_4');
              

            }
          }
        }
      },
     addPatient:function(form){
        if(!localStorage.patientId){
          $scope.addPat.status = "Inactive";
          $scope.addPat.patient_authorization_form.terms_and_conditions = 0;
          $scope.addPat.patient_careteams = [];
          angular.forEach($scope.patient_careteams,function(value,key){
            if((value.name || value.address || value.email || value.phone || value.start_date || value.end_date)){
              $scope.addPat.patient_careteams.push(value);
            }
          })
          localStorage.patientData = JSON.stringify($scope.addPat);
          var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.conAddPatient,'POST',JSON.parse(localStorage.patientData),token);  
          promise.then(function(res){
            if(res.data.status == true ){
              localStorage.patientId = res.data.data.id;
              goToIntakeForms(res.data.data.id);              
              loadingFactory.hide();                           
            }else if(res.data.status == false){
              if((res.data.message).hasOwnProperty('dob')){
                toastMsg.show("Date of birth can not be greater than 18 years.");
              }else if((res.data.message).hasOwnProperty('patient_parent')){
                if((res.data.message.patient_parent).hasOwnProperty("primary_dob")){
                  toastMsg.show("Mother's DOB is invalid.");
                }
              }else if((res.data.message).hasOwnProperty('patient_parent')){
                if((res.data.message.patient_parent).hasOwnProperty("secondary_dob")){
                  toastMsg.show("Father's DOB is invalid.");
                }
              }
              loadingFactory.hide(); 
            }else if(res.data.Response.status == 'Failed'){
              toastMsg.show("Please check if all the three forms are filled");
              loadingFactory.hide(); 
            }
          });
        }else{
          goToIntakeForms(localStorage.patientId);
          loadingFactory.hide();
        }
      },
    }

$scope.checkPolicy = function(){
 $scope.policyErrMsg = '';
  if($scope.addPat.patient_insurances){
           if($scope.addPat.patient_insurances[0].policy_number || $scope.addPat.patient_insurances[1].policy_number){
             $scope.pno1 = $scope.addPat.patient_insurances[0].policy_number;
             $scope.pno2 = $scope.addPat.patient_insurances[1].policy_number;
           }
          if(($scope.pno1 || $scope.pno1) && $scope.pno1 ==  $scope.pno2){
            $scope.policyErrMsg = "Policy numbers can't be same";
            return false;
           }
           else{
            return true;
           }
          
    }
    return true;
}

$scope.checkReason = function(){

  if($scope.addPat.patient_authorization_form.name_of_person || $scope.addPat.patient_authorization_form.relationship_to_patient){

    if($scope.addPat.patient_authorization_form.reason_for_disclosure){
      return true;
    }
    else{
      $scope.reason = "Please mention the reason of disclosure";
      return false;
    }
  }else{
    $scope.reason = '';
    return true;
  }

}

$scope.checkDeclaration = function(){
  if($scope.addPat.patient_insurances[0].company_name || $scope.addPat.patient_insurances[0].policy_number || $scope.addPat.patient_insurances[0].holder_name || $scope.addPat.patient_insurances[1].holder_name || $scope.addPat.patient_insurances[1].policy_number || $scope.addPat.patient_insurances[1].company_name){
    if($scope.addPat.release_info_authrization){
      $scope.chckdeclaration = '';
      return true;
    }
    else{
      $scope.chckdeclaration = 'Please check this';
      return false;
    }

  }else{
    return true;
  }
   
}

$scope.showDate = function(type,index){

 var max =  ionic.Platform.isIOS() ? new Date() : (new Date()).valueOf();
 var min =  ionic.Platform.isIOS() ? new Date() : (new Date()).valueOf();
 //alert(type)
  var dateTemp;
 if(type == 'childDOB'){
  dateTemp = ($scope.addPat.dob)?$scope.addPat.dob : (new Date()).valueOf();
  validateDate.showDatePicker_($scope,'childDOB','',max,dateTemp);
 }
 else if(type == 'motherDOB'){
  dateTemp = ($scope.addPat.patient_parent.primary_dob)?$scope.addPat.patient_parent.primary_dob : (new Date()).valueOf();
  validateDate.showDatePicker_($scope,'motherDOB','',max,dateTemp);
 }
 else if(type == 'fatherDOB'){
  dateTemp = ($scope.addPat.patient_parent.secondary_dob)?$scope.addPat.patient_parent.secondary_dob : (new Date()).valueOf();
  validateDate.showDatePicker_($scope,'fatherDOB','',max,dateTemp);
 }else if(type == 'careTeamStart'){
    //min =  ionic.Platform.isIOS() ? new Date($scope.addPat.dob) : (new Date($scope.addPat.dob)).valueOf();
  dateTemp = ($scope.patient_careteams[index].start_date)?$scope.patient_careteams[index].start_date : (new Date()).valueOf();
  validateDate.showDatePicker_($scope,'careTeamStart','','',dateTemp,index);
 }else if(type == 'careTeamEnd'){
  dateTemp = ($scope.patient_careteams[index].end_date)?$scope.patient_careteams[index].end_date : (new Date()).valueOf();
  validateDate.showDatePicker_($scope,'careTeamEnd','','',dateTemp,index);
 }

}

$scope.previous = function(){
  var temArr = ($state.current.name).split('_');
  var count = $scope.addPat.information_of === $scope.patientInformationOfDropDown[0] && parseInt(temArr[1]) == screenNumber[2]? screenNumber[1] : screenNumber[0];
  var prevState =  temArr[0]+'_'+(parseInt(temArr[1]) - count);
  if($state.current.name == 'mainView.addPatient_4'){
    $scope.addPat.patient_careteams = [];
    angular.forEach($scope.patient_careteams,function(value,key){
      if((value.name || value.address || value.email || value.phone || value.start_date || value.end_date)){
        $scope.addPat.patient_careteams.push(value);
      }
    })
  }
  if($window.localStorage['patientData'] !== 'undefined')
    $window.localStorage['patientData'] = JSON.stringify($scope.addPat);
  $state.go(prevState);


}
$scope.$on("$ionicView.beforeEnter", function(event, data){
  $ionicNavBarDelegate.showBackButton(true);
});

  $scope.addMore = function(type,index){
     switch(type){
       case 'add':
        $scope.patient_careteams.push({service:'',name:'',address:'',email:'',phone:'',current_date:''});
       break;
       case 'remove':
        $scope.patient_careteams.splice(index,1);
         if(index >0){
            $ionicSlideBoxDelegate.slide(index-1);
         }
       break;
     }

    $ionicSlideBoxDelegate.update();

  }

  $scope.slide = function(index){
    $ionicSlideBoxDelegate.slide(index);
  }

    var inAppBrowserRef;
    var saveUrl;
    function goToIntakeForms(id){
        //inAppBrowserRef = cordova.InAppBrowser.open('http://f2f-staging.kiwireader.com/#/main/csignUp', '_blank', 'location=yes');
        inAppBrowserRef= window.open(globalConstants.gHost+'/patientmain/intakeforms/'+ id +'?src='+'mobile'+'&token='+token +'&emrtoken='+ JSON.parse(localStorage.userData).emrToken,'_blank','location=no,clearcache=yes,clearsessioncache=yes,hidden=yes');
        //inAppBrowserRef.addEventListener('loadstop', loadStopCallBack);
        inAppBrowserRef.addEventListener('loadstart', loadStopCallBack);

        //add the listener to detect when the page loads after inappbrowser is called into view
        inAppBrowserRef.addEventListener('loadstop', loadStopCallBack);
    }



    var loadStopCallBack = function(event){
      if(event.type == 'loadstart'){
        loadingFactory.show();
      }else{
        inAppBrowserRef.show();
        loadingFactory.hide();
      }
       
      //$('#loader').show();
      $timeout(function(){
         if(event.url.indexOf('errPage')>=0){
            inAppBrowserRef.close();
            toastMsg.show('Patient added successfully');
            localStorage.patientData = '';
            $scope.addPat={};
            $ionicHistory.clearHistory();
            $ionicHistory.clearCache();
            if(Scopes.get('saveState')){
              $timeout(function(){$state.go("mainView.scheduledAppoinment",{type:Scopes.get('saveState')},{ reload: true })},0);
              Scopes.delete('saveState');
            }else{
              $state.go("mainView.conDashboard");
            }
         }else if(event.url.indexOf('conEditPatient_4') >= 0){
            inAppBrowserRef.close();
         }
       },500);
      //loadingFactory.hide(); 
      }

      $scope.currentIndex = 0
      $scope.slideHasChanged = function(index){
        $scope.currentIndex = index;
      }

  $scope.checkTohide = function(){
    if($scope.currentIndex > 0){
        return false
    }else{
        return true;
    }

  }

  function showInformation(){
    showModalService.show($scope,'modules/consumer/addPatient/templates/add-patient-info.html')
  }

  $scope.hideModal = function(){
    showModalService.hide(true);
  }

  $scope.getState = function(msgId,zip,primaryOrSec) {
    document.getElementById(msgId).innerHTML = "";
    if(angular.isDefined(zip) && zip!='' && zip.length ==5){
        if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.close();
        }
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStateByZipcode+zip, 'GET', {},commonGetterService.getToken());
        promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                loadingFactory.hide();
                $scope.addPat.patient_parent[primaryOrSec] = res.data.data.id.toString();
            } else {
                document.getElementById(msgId).innerHTML = res.data.message;
                loadingFactory.hide();
            }
        }, function(err) {
                loadingFactory.hide();
        });
    }else{
        if(angular.isDefined(zip) && zip.length>=1 && zip.length <5){
            document.getElementById(msgId).innerHTML = "Zip Code should be 5 digits";
        }
    }

  }
  $scope.resetAddress = function() {
    $scope.addPat.patient_parent.primary_address = '';
    $scope.addPat.patient_parent.primary_city = '';
    $scope.addPat.patient_parent.primary_zipcode = '';
    $scope.addPat.patient_parent.primary_state_id = '';
 
  }



});