face2face.controller('consumerBilling',function($window,$scope,globalConstants,serverRequestFactory,requiredFactory,otherValidationCheck,$state,loadingFactory,toastMsg,commonGetterService,$timeout,showModalService,Scopes){
$scope.list = {};
$scope.showBtn = false;
$scope.cardInfo = {};
$scope.typeofAction = '';
var token = commonGetterService.getToken();
$scope.months = [1,2,3,4,5,6,7,8,9,10,11,12];
$scope.years = addYears();
commonGetterService.getStates($scope);
$window.Stripe.setPublishableKey(globalConstants.stripeKey);
/*
** get cards if  **
*/
	$scope.getCards = function(){
	  $scope.noCards = '';
	  $scope.listofcards = [];
	  var promiseforCards = serverRequestFactory.serverComm(globalConstants.serviceUrl.stripCardList,'POST',{},token);  // get the consumer detail list
	  promiseforCards.then(function(res){
	  var res = res.data;
	  if(res.status == true && res.data != "None"){
	    var result = res.data;

	    for(var i = 0;i<result.length;i++){
	        $scope.listofcards.push({cardNo : 'XXXXXXXXXXXX'+result[i].last4,name : result[i].name,stripID : result[i].id , selectedid : res.stripe_card_id,date:'Expires : '+result[i].exp_month+'/'+result[i].exp_year});
	        if(res.stripe_card_id == result[i].id){
	          $scope.list.selectedCard = $scope.listofcards[i];
	        }
	    }
	    $timeout(function(){
	    	 $scope.showBtn = true;
	    	},1000);

	    loadingFactory.hide();

	   }
	   else if(res.data == "None"){
	   	$scope.showBtn = true;
	    //$scope.noCards = "No card added. Please add a card to continue";
	    loadingFactory.hide();
	   }

	  },function(err){
	    //$scope.noSamePlans = 'Oops! some error occured. Please try again later';

	  })
	}

	// to update stripe data
	$scope.stripeCallback = function (code, result) {

	  $scope.wrongCardInfo = "";
	   $scope.message = "";
	    if (result.error) {

	        if(result.error.hasOwnProperty('message')){

	           toastMsg.show(result.error.message);
	           $scope.showMsg = true;
	        }
	        else{
	         obj = {
	                   name:$scope.cardInfo.name,
	                   address_city:$scope.cardInfo.city,
	                   address_line1:$scope.cardInfo.address1 ,
	                   address_line2:($scope.cardInfo.address2) ? $scope.cardInfo.address2 : ' ',
	                   address_state:$scope.cardInfo.state ,
	                   address_zip:$scope.cardInfo.zip_code ,
	                   cvc:$scope.cardInfo.cvc ,
	                   exp_month:$scope.cardInfo.exp_month ,
	                   exp_year:$scope.cardInfo.exp_year ,
	                   number:$scope.cardInfo.number

	          }


	          if(code == 408){
	            var othervF1 = otherValidationCheck.validateBeforeSubmit();
	           // if(requiredFactory.validateBeforeSubmit($scope.conFormProf,$scope) && othervF1){

	              var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',obj,token);  // get the consumer detail list
	              promise.then(function(res){
	              var res = res.data;
	              if(res.status == true){
	                   $scope.cardInfo.cvc = '';


	                   toastMsg.show("Card has been added successfully");
	                   loadingFactory.hide();
	                 // $('#myModalCH').modal('show');
	                //  $("#consumeradd-card").modal('hide');
	                   $scope.getCards();
	                   showModalService.hide(true);
	                   $scope.cardInfo = {};
	                   Scopes.delete('formInfo');
	                   Scopes.delete('formInfoValidation')
                       $scope.typeofAction = 'Add';
	               }
	              else if(res.status == "error"){
	                 toastMsg.show(res.message);
	                 loadingFactory.hide();
	               }


	              },function(err){

	              })


	            }
	        }

	    } else {
	          var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',result,token);  // get the consumer detail list
	          promise.then(function(res){
	          var res = res.data;
	          if(res.status == true){
	              $scope.cardInfo.cvc = '';

	              toastMsg.show("Card has been added successfully");
	              loadingFactory.hide();
	              // $('#myModalCH').modal('show');
	             //  $("#consumeradd-card").modal('hide');
	               $scope.getCards();
	               showModalService.hide(true);
	               $scope.cardInfo = {};
	               Scopes.delete('formInfo');
	               Scopes.delete('formInfoValidation');
                   $scope.typeofAction = 'Add';
	           }
	         else if(res.status == "error"){

	            toastMsg.show(res.message);
	            loadingFactory.hide();
	           }


	          },function(err){

	          })


	        //}

	      }

	 };

	$scope.addEditCard = function(selectedid,stripID,type){
		$scope.cardInfo = {};
		showModalService.show($scope,'modules/consumer/billing/template/add-card.html')
		//alert(type)
		if(type == 'Add'){
            $scope.typeofAction = 'Add';
		}
		else if(type == 'Edit'){
			$scope.getCardToUpdate(stripID);
			$scope.typeofAction = 'Edit';
		}

	}

   $scope.getCardToUpdate = function(stripID){
   	 $scope.list.stripID = stripID;
    // if($scope.list.selectedCard){
      // $scope.list.selectedCard = JSON.parse($scope.list.selectedCard);
       var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateCard + stripID ,'GET',{},token);  // get the consumer detail list
                  promise.then(function(res){
                  var res = res.data;
                  if(res.status == "success"){
                             $scope.cardInfo.name = res.response.name;
                             $scope.cardInfo.city = res.response.address_city;
                             $scope.cardInfo.address1 = res.response.address_line1;
                             $scope.cardInfo.address2 = res.response.address_line2;
                             $scope.cardInfo.state = res.response.address_state;
                             $scope.cardInfo.zip_code = res.response.address_zip;
                             $scope.cardInfo.exp_month = JSON.stringify(res.response.exp_month);
                             $scope.cardInfo.exp_year = JSON.stringify(res.response.exp_year);
                             $scope.cardInfo.number = "XXXXXXXXXXXX" + res.response.last4;
                             $scope.cardInfo.cvc = res.response.cvc_check;

                    loadingFactory.hide();
                   }
                   else if(res.status == "error"){
                 /*   $scope.showMsg = true;
                    $scope.cardErr = res.message;
                    window.scrollTo(0,0);*/
                    loadingFactory.hide();
                   }


                  },function(err){

                  })
                  // $("#consumerupdate-card").modal('show');
    // }




 }

 $scope.updateCard = function(form){

   var obj = {

     name : $scope.cardInfo.name,
     address_city : $scope.cardInfo.city,
    // address_country : '',
     address_line1 : $scope.cardInfo.address1,
     address_line2 : ($scope.cardInfo.address2) ? $scope.cardInfo.address2 : ' ',
     address_state : $scope.cardInfo.state,
     address_zip : $scope.cardInfo.zip_code,
     exp_month : $scope.cardInfo.exp_month,
     exp_year : $scope.cardInfo.exp_year,
     card_id : $scope.list.stripID
   }

   if(requiredFactory.validateBeforeSubmit(form,$scope) && otherValidationCheck.validateBeforeSubmit()){
     var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.submitUpdatedCard ,'POST',obj,token);  // get the consumer detail list
                promise.then(function(res){
                var res = res.data;
                if(res.status == "success"){
                   toastMsg.show("Card has been updated successfully");
                  // $('#myModalCH').modal('show');
                   loadingFactory.hide();
                   showModalService.hide(true);
                   $scope.typeofAction = '';
                  // $("#consumerupdate-card").modal('hide');
                  if($state.params.id){
                  	updateCardForFailedPayment($scope.list.stripID);
                  }

                 }
                 else if(res.status == "error"){
                  $scope.showMsg = true;
                /*  $scope.cardErr = res.message;
                  window.scrollTo(0,0);*/
                  toastMsg.show(res.message);
                  loadingFactory.hide();

                 }

                 },function(err){

                });
                Scopes.delete('formInfo');
                Scopes.delete('formInfoValidation');
   }
 }

 $scope.closeModal = function(){
   showModalService.hide(true);
   $scope.cardInfo = {};
   Scopes.delete('formInfo');
   Scopes.delete('formInfoValidation')
 }

 /**
 ** Delete **
 **/

 $scope.deleteCard = function(stripID){

 	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.deleteCard + stripID,'GET',{},token);
 	promise.then(function(res) {

 	    if (res.data.status == true) {
 	        $scope.getCards();
 	        loadingFactory.hide();
            toastMsg.show("Card has been deleted successfully");
 	    } else {
 	        loadingFactory.hide();
 	    }
 	}, function(err) {
 		    
 	        loadingFactory.hide();
 	});
 }


 function addYears(){

    var dd = new Date();
    dd = dd.getFullYear();
    var oldYr = dd;
    var yr = [];
    /*for(o = 30;o > 1 ;o--){
        yr.push(--oldYr);
    } */
    yr.push(dd);
    for(o = 1;o <30 ;o++){
        yr.push(++dd);
    }

    return yr.sort();
 }

 $scope.getCards();

 /**** Notifiction handling when payment fails ***/

 if($state.params.id){
 	$scope.addEditCard('',$state.params.id,'Edit');
 }

 function updateCardForFailedPayment(stripID){
 	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateCardForFailedPayment + stripID,'GET',{},token);
 	promise.then(function(res) {
 	    if (res.data.status == true) {
 	        $scope.getCards();
 	        loadingFactory.hide();
            //toastMsg.show("Card has been updated successfully");
 	    } else {
 	        loadingFactory.hide();
 	    }
 	}, function(err) { 		    
 	        loadingFactory.hide();
 	});
 }

});
