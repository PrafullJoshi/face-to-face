face2face.controller('conCalendarCtrl',function($scope,globalConstants,serverRequestFactory,$window,$injector,requiredFactory,Scopes,otherValidationCheck,$state,loadingFactory,toastMsg,consentService,showModalService,commonGetterService,$filter,getPatientsService,$stateParams,validateDate,coupanCodePaymentService,$timeout,$ionicNavBarDelegate,$rootScope,$ionicHistory,convertDate){
   'use strict';
    $window.Stripe.setPublishableKey(globalConstants.stripeKey); // stripe key for payment
    $scope.calendar = {
      mode:'week',
    };
    $scope.oModal ={};
    $scope.title = "Create Appointment";
    $scope.terms_of_use ='';
    $scope.patientDetails ={};
    var multiProviderData;
    var token = commonGetterService.getToken();
    //$scope.age ='';
    $scope.templateUrl = 'modules/consumer/scheduleAppointment/template/appointmentDetails.html';
    $scope.appointmentData = Scopes.get('appointmentData');
    $scope.appointmentData.consultation_dob = $filter('date')(new Date(), 'MM/dd/yyyy');
    //$scope.templateUrl = 'modules/consumer/scheduleAppointment/template/appointmentDetails.html';  
    // $scope.calendar.currentDate = new Date($scope.appointmentData.consultation_start_date);
    $scope.displayDate = {
        date :$filter('date')(new Date($scope.appointmentData.consultation_start_date), 'EEEE, MMM d, y'),
        time :'From ' + $filter('date')(new Date($scope.appointmentData.consultation_start_date + ' ' + $scope.appointmentData.consultation_start_time),'h:mm a')+' to ' + $filter('date')(new Date($scope.appointmentData.consultation_start_date + ' ' + $scope.appointmentData.consultation_end_time),'h:mm a')
    }
    loadingFactory.hide();
    $scope.providerListingTemplate = "modules/consumer/calendar/template/singleProvider.html";

    /*
    * Title switch function @ start
    */
    switch($stateParams.type){
        case 'S':
            $scope.viewTitleCon = 'Schedule';
            getProviderDetails(globalConstants.serviceUrl.getProviderDetailsById);            
        break;
        case 'M':
            $scope.viewTitleCon = 'Multi-Provider';
            multiProviderData = Scopes.get("multiproviderCalandarData");
            $scope.providerListingTemplate = "modules/consumer/calendar/template/multiProviderlisting.html";
            $scope.providerListingOnPayment = "modules/consumer/calendar/template/multiProviderlisting.html";
            getProviderDetails(globalConstants.serviceUrl.getProviderDetailsMulti);
        break;
        case 'C':
            $scope.viewTitleCon = 'Concierge';
            getProviderDetails(globalConstants.serviceUrl.getProviderDetailsById);
        break;
    }

    getPatientsService.getPatientDetails($scope,$scope.appointmentData.patient_id,'',token);
    // get consent to show in popup
    consentService.getConsent($scope,globalConstants.serviceUrl.patientConsentPage);

    function getProviderDetails(url){
        var promise = serverRequestFactory.serverComm(url,'POST',{
            "provider_id"               : $scope.appointmentData.provider_id,
            "consultation_start_time"   : $scope.appointmentData.consultation_start_time,
            "consultation_end_time"     : $scope.appointmentData.consultation_end_time,
            "consultation_start_date"   : $scope.appointmentData.consultation_start_date,
            "insurance_plan_id"         : $scope.appointmentData.insurance_plan_id,
            "concierge_service"         : $scope.appointmentData.concierge_service,
            "patient_id"                : $scope.appointmentData.patient_id
            },token);  
        promise.then(function(res){
            if(res.data.status == true && res.data.data != "None"){
                $scope.providersDetails = res.data.data;
                $scope.appointmentData.consultation_total_charge = $scope.providersDetails.total_amount;
                loadingFactory.hide();
                $scope.oModal = Scopes.get('oModal');
            }else if(res.status == false){
                loadingFactory.hide();
            }
        },function(err){
            loadingFactory.hide();
        })
    }

    // var loadEvents = function () {
    //     $scope.calendar.eventSource = createRandomEvents();
    // };



    function onViewTitleChanged(title) {
        title = title.split(" ");
        $scope.viewTitle = title;
    };

    // function createRandomEvents() {
    //     var events =[];
    //     events.push({
    //         title:$scope.appointmentData.patientName,
    //         startTime: new Date($scope.appointmentData.consultation_start_date + ' ' + $scope.appointmentData.consultation_start_time),
    //         endTime: new Date($scope.appointmentData.consultation_start_date + ' ' + $scope.appointmentData.consultation_end_time)

    //     })
    //     return events;
    // }

    // loadEvents();

    function showDate(){
        var max =  ionic.Platform.isIOS() ? new Date() : (new Date()).valueOf();
        validateDate.showDatePicker($scope,'consent','',max);
    }

    function hideModal(from){
        if(from == 'back'){
            switch($scope.templateUrl){
                case "modules/consumer/scheduleAppointment/template/consentSign.html" :
                    $scope.templateUrl = 'modules/consumer/scheduleAppointment/template/appointmentDetails.html';
                break;
                case 'modules/consumer/scheduleAppointment/template/appointmentDetails.html':
                    $scope.oModal.hide();
                    $scope.oModal.remove();
                break;
                case "modules/consumer/scheduleAppointment/template/payment.html":
                    $scope.templateUrl = "modules/consumer/scheduleAppointment/template/consentSign.html";
                break;
            }
        }else{
            $scope.oModal.hide();
            $scope.oModal.remove();
        }

    }

    function next(type){
        switch(type){
            case 'consent':
                $scope.templateUrl = "modules/consumer/scheduleAppointment/template/consentSign.html";
            break;
        }
        
    }

    function consentSubmit(form){
        if(requiredFactory.validateBeforeSubmit(form,$scope)){
            $scope.templateUrl = "modules/consumer/scheduleAppointment/template/payment.html";
            getCards();
        }
    }

    function checkCouponCode(){
       var data = {
        "coupon_code"  : $scope.appointmentData.coupon_code,
        "consult_type" : $scope.appointmentData.consult_medium == "Concierge" ?'concierge' : 'schedule',
        "speciality"   : $scope.appointmentData.speciality_id ,
        "amount"       : $scope.providersDetails.total_amount
      }

      coupanCodePaymentService.checkCoupanCode(data,$scope,token,'coupon_codeError');
    }

    function getCards(){
        $scope.noCards = '';
        $scope.listofcards = [];
        var promiseforCards = serverRequestFactory.serverComm(globalConstants.serviceUrl.stripCardList,'POST',{},token);  // get the consumer detail list
        promiseforCards.then(function(res){
        var res = res.data;
        if(res.status == true && res.data != "None"){
            var result = res.data;
            if(result.length ==0){
                $scope.noCards = "Y";
            }
            for(var i = 0;i<result.length;i++){
                $scope.listofcards.push({cardNo : 'XXXXXXXXXXXX'+result[i].last4,name : result[i].name,stripID : result[i].id , selectedid : res.stripe_card_id,date:'Expires : '+result[i].exp_month+'/'+result[i].exp_year});
            if(res.stripe_card_id == result[i].id){
              $scope.list.selectedCard = $scope.listofcards[i];
              $scope.appointmentData.stripe_card_id = result[i].id;
            }
        }
        loadingFactory.hide();

       }
       else if(res.data == "None"){
        $scope.noCards = "Y";
        loadingFactory.hide();
       }

      },function(err){
        $scope.noCards = "Y";
        loadingFactory.hide();
      })
    }


    function updateCardIdOnchange(id){
        if(id){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateDefaultCard + id ,'GET',{},token,'',true);  // get the consumer detail list  
            promise.then(function(res){
                var res = res.data;
                if(res.status == true){
                    loadingFactory.hide();
                    $scope.appointmentData.stripe_card_id = id;             
                }
                else if(res.status == false){
                    loadingFactory.hide();
                }
            },function(err){ 
                loadingFactory.hide();
           })
        }
    }
    
    function submitSchedule(form){
        document.getElementById('policyErr').innerHTML ='';
        if(requiredFactory.validateBeforeSubmit(form,$scope) && $scope.noCards == '' && $scope.appointmentData.terms_of_use && validateDate.validateDt($scope.appointmentData.consultation_dob,'consultDOB')){            
            if($scope.appointmentData.consult_medium != 'Multi-Provider'){
                submitSingleSchedule();
            }else{
                submitMultiProvider();
            }  
        }else{
            if($scope.noCards != ''){
                toastMsg.show('Please select any card for payment,Or add new card');
            }else if(!$scope.appointmentData.terms_of_use){
                document.getElementById('policyErr').innerHTML = 'Please accept Terms & conditions'
            }

        }
    }

    function submitSingleSchedule(){
        if($scope.appointmentData.inquiry_type){
            $scope.appointmentData.inquiry_type_id =JSON.parse($scope.appointmentData.inquiry_type).id;
        }else{
            $scope.appointmentData.inquiry_type_id ="";
        }
        delete $scope.appointmentData.inquiry_type;
        delete $scope.appointmentData.inquiry;
        delete $scope.appointmentData.stateName;
        delete $scope.appointmentData.patientName;
        delete $scope.appointmentData.patient_screening_detail;
        $scope.appointmentData.consult_type = "Scheduled";
        $scope.appointmentData.speciality_unit_charge = $scope.providersDetails.total_amount;
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.scheduledAppointment,'POST',$scope.appointmentData,token);  // get the consumer detail list  
        promise.then(function(res){
            hideModal();
            if(res.data.status == true){
                Scopes.delete('appointmentData');
                Scopes.delete('addressOnCon');
                loadingFactory.hide();
                if(Scopes.get('emr_history_category_id')){
                    commonGetterService.shareMedicalRecord({consultation_id:[res.data.data.consultation_id],patient_id:$scope.appointmentData.patient_id,provider_id:[$scope.providersDetails.id]},token);
                }
                $state.go("mainView.thankYou").then(function(){
                    $ionicHistory.clearHistory();
                    $ionicHistory.clearCache();
                    $ionicNavBarDelegate.showBackButton(false);
                    $rootScope.showMenu = true;
                });
            }else if(res.status == false){
                toastMsg.show(res.data.message);
                loadingFactory.hide();
            }
        },function(err){ 
            loadingFactory.hide();
        })
    }

    function submitMultiProvider(){        
        var finalScheduledDetail;
        if($scope.appointmentData.inquiry_type){
            $scope.appointmentData.inquiry_type_id =JSON.parse($scope.appointmentData.inquiry_type).id;
        }else{
            $scope.appointmentData.inquiry_type_id ="";
        }
        // if($scope.appointmentData.inquiry){
        //     $scope.appointmentData.inquiry_id =JSON.parse($scope.appointmentData.inquiry).id;
        // }else{
        //     $scope.appointmentData.inquiry_id ="";
        // }
        var provider_id = $scope.appointmentData.provider_id
        delete $scope.appointmentData.inquiry;
        delete $scope.appointmentData.inquiry_type;
        delete $scope.appointmentData.state_id;
        delete $scope.appointmentData.provider_id;
        delete $scope.appointmentData.concierge_service;
        delete $scope.appointmentData.patientName;
        var finalObject={};
        angular.forEach(multiProviderData, function(value, key) {
            multiProviderData[key].speciality_unit_charge = $scope.providersDetails.list[value.provider_id].provider_profile.speciality.scheduled_price;
            multiProviderData[key].consultation_total_charge = $scope.providersDetails.list[value.provider_id].total_amount;
            multiProviderData[key].consult_type = "Scheduled";
            angular.merge(multiProviderData[key],$scope.appointmentData);
            finalObject[key] = multiProviderData[key];
        });
        finalObject['provider_total_charge'] = $scope.providersDetails.total_amount;
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.scheduleMultiProviderAppointment,'POST',finalObject,token);  
        promise.then(function(res){
            hideModal();
            if(res.data.status == true){
                Scopes.delete('appointmentData');
                Scopes.delete('addressOnCon');
                loadingFactory.hide();
                if(Scopes.get('emr_history_category_id')){
                    commonGetterService.shareMedicalRecord({consultation_id:res.data.data.consultation_id,patient_id:$scope.appointmentData.patient_id,provider_id:provider_id},token);
                }
                $state.go("mainView.thankYou").then(function(){
                    $ionicHistory.clearHistory();
                    $ionicHistory.clearCache();
                    $ionicNavBarDelegate.showBackButton(false);
                    $rootScope.showMenu = true;
                });
            }else if(res.status == false){
                toastMsg.show(res.data.message);
                loadingFactory.hide();
            }

      },function(err){ 
        loadingFactory.hide();
      })
    }

    /** Start to add card function & variables **/

    $scope.list = {};
    $scope.showBtn = false;
    $scope.cardInfo = {};
    $scope.typeofAction = '';
    $scope.months = [1,2,3,4,5,6,7,8,9,10,11,12];
    $scope.years = addYears();
    commonGetterService.getStates($scope);

    function addCard (selectedid,stripID){
        $scope.cardInfo = {};
        showModalService.show($scope,'modules/consumer/billing/template/add-card.html')
        $scope.typeofAction = 'Add';

    }
        // to update stripe data
    $scope.stripeCallback = function (code, result){
        $scope.wrongCardInfo = "";
        $scope.message = "";
        if (result.error) {

            if(result.error.hasOwnProperty('message')){

               toastMsg.show(result.error.message);
               $scope.showMsg = true;
            }
            else{
             var obj = {
                       name:$scope.cardInfo.name,
                       address_city:$scope.cardInfo.city,
                       address_line1:$scope.cardInfo.address1 ,
                       address_line2:($scope.cardInfo.address2) ? $scope.cardInfo.address2 : ' ',
                       address_state:$scope.cardInfo.state ,
                       address_zip:$scope.cardInfo.zip_code ,
                       cvc:$scope.cardInfo.cvc ,
                       exp_month:$scope.cardInfo.exp_month ,
                       exp_year:$scope.cardInfo.exp_year ,
                       number:$scope.cardInfo.number

              }


              if(code == 408){
                var othervF1 = otherValidationCheck.validateBeforeSubmit();
                  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',obj,token);  // get the consumer detail list
                  promise.then(function(res){
                  var res = res.data;
                  if(res.status == true){
                       $scope.cardInfo.cvc = '';
                       toastMsg.show("Card has been added successfully");
                       loadingFactory.hide();
                       getCards();
                       showModalService.hide(true);
                       $scope.cardInfo = {};
                       Scopes.delete('formInfo');
                       $scope.typeofAction = 'Add';
                   }
                  else if(res.status == "error"){
                     toastMsg.show(res.message);
                     loadingFactory.hide();
                   }


                  },function(err){
                    loadingFactory.hide();
                  })


                }
            }



        } else {
            //$scope.consData.stripe = result;
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',result,token);  // get the consumer detail list
            promise.then(function(res){
                var res = res.data;
                if(res.status == true){
                    $scope.cardInfo.cvc = '';
                    toastMsg.show("Card has been added successfully");
                    loadingFactory.hide();
                    getCards();
                    showModalService.hide(true);
                    $scope.cardInfo = {};
                    Scopes.delete('formInfo');
                    $scope.typeofAction = 'Add';
                    loadingFactory.hide();
                }else if(res.status == "error"){
                    toastMsg.show(res.message);
                    loadingFactory.hide();
               }
            },function(err){
                loadingFactory.hide();
            })

        }

     };


    //close add card function
    $scope.closeModal = function(){
        showModalService.hide(true);
        $scope.cardInfo = {};
        Scopes.delete('formInfo');
    }

    function addYears(){
        var dd = new Date();
        dd = dd.getFullYear();
        var oldYr = dd;
        var yr = [];
        yr.push(dd);
        for(var o = 1;o <30 ;o++){
            yr.push(++dd);
        }
        return yr.sort();
    }


    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall = function(functionName,params){
        switch(functionName){
            case 'onEventSelected':
                onEventSelected(params);
                break;
            case 'onViewTitleChanged':
                onViewTitleChanged(params);
                break;
            case 'hideModal':
                hideModal(params);
                break;
            case 'showDate':
                showDate();
                break;
            case 'next':
                next(params);
                break;
            case 'consentSubmit':
                consentSubmit(params);
                break;
            case 'getCards':
                getCards();
                break;
            case 'checkCouponCode':
                checkCouponCode();
                break;
            case 'updateCardIdOnchange':
                updateCardIdOnchange(params);
                break;
            case 'addCard':
                addCard(params);
            break;
            case 'submitSchedule':
                submitSchedule(params);
                break;

        }
    }
    $scope.toAge =function(dob){
        return convertDate.toAge(dob)
    }

    $scope.$on('$ionicView.beforeEnter', function (e, data){
        $ionicNavBarDelegate.showBackButton(true);
        data.enableBack = true;
        $rootScope.showMenu = false;
    });


});
