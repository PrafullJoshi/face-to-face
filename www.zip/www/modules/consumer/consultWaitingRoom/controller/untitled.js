
face2face.controller("consultationWaitingRoomCtrl",function($scope, $window,serverRequestFactory,globalConstants,$stateParams,$rootScope,$state,$timeout,requiredFactory,$stateParams,Scopes,$ionicNavBarDelegate,validateDate,showModalService,commonGetterService,consultRoomService,toastMsg,convertDate,$filter,loadingFactory,coupanCodePaymentService,showPopup,$ionicHistory) {
  
    $scope.provider = false;
    $scope.consultData = Scopes.get('consultData');
    if($stateParams.type == 'Multi-Provider' || $stateParams.type == 'Video'){
      window.open($scope.consultData.join_url, '_system');
      cordova.plugins.backgroundMode.enable();
    }
    else if($stateParams.type == 'onDemand'){
      window.open($scope.consultData.zoom_url, '_system');
      cordova.plugins.backgroundMode.enable();
    }else{
      startCheckingForExtendOrEnd();
    }


    var token = commonGetterService.getToken();
    $scope.alreadyEnded = false;
    $scope.appointmentData={total_amount :0};

    cordova.plugins.backgroundMode.on('enable', function(){
      startCheckingForExtendOrEnd();
    });

    var interval;
    function startCheckingForExtendOrEnd(){
      interval = setInterval(function(){
        getEndConStatus();
        endMeeting(' ');       
      },12000); // for extend
    }

    function getEndConStatus(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getEndStatus + $scope.consultData.id , 'GET',{}, token,'','silent'); // get stattus of meeting 
      promise.then(function(res) {
        if (res.data.status == true) {
          if(res.data.data == "Completed"){
            showModal('rateProviders');
            $scope.alreadyEnded = true;
          }else{
            requestFromProvider();
          }
        }
      })
    }

    // function to check if provider requested to extend meeting or not (if not check 3 min is left to end meeting then show popoup for extend)
    function requestFromProvider(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.checkExtendFromProvider+$scope.consultData.id,'GET',{},token,'',true);
      promise.then(function(res) {
        if (res.data.status == true) {
          $scope.appointmentData.extendTime = res.data.data.extend_time_by_provider.toString();
          checkToshowExtendMeetingPopup(res.data.message);       
        }else if (res.data.status == false) {
          if(res.data.data.RequestStatus == '' && res.data.data.status == true){
            checkToshowExtendMeetingPopup("Extend Meeting");
          }
        }
        loadingFactory.hide();   
      })
    }

    function checkToshowExtendMeetingPopup(title){
      if(cordova.plugins.backgroundMode.isActive()){
        cordova.plugins.notification.local.schedule({
          id: 1,
          title: 'Extend Meeting',
          text: title,
          at :new Date()
        })
      }
      if(!cordova.plugins.backgroundMode.isActive()){
        showPopup.show(title,'<p>Do you want to extend the meeting?</p>', $scope,'','Extend');
      }
       
    }
    // callback on click of local notifiction
    cordova.plugins.notification.local.on("click", function(notification) {
      showPopup.show(notification.text,'<p>Do you want to extend the meeting?</p>', $scope,'','Extend');
    });

    //callback on cleck ok to extend 
    $scope.confirmStatus =function(status,type){
      if(type != 'cancel'){
        openExtend();
      }else{
        cancelRequestForExtend();
      }
    }

    function cancelReq(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.cancelReq+$scope.consultData.id,'GET',{},token,'',true);  
      promise.then(function(res){
        if(res.data.status == true){
          //$rootScope.reqCanceled =  false;
        }
      })
    }
    var interval2;
    function acceptRequestByCons(status){
      serverRequestFactory.serverComm(globalConstants.serviceUrl.acceptReqByCons+$scope.consultData.id+'/'+status,'GET',{},token,'',true);
      if(status == 'Accepted'){
        if($scope.consultData.consult_medium == 'Multi-Provider'){
          interval2 = setInterval(function(){
            ifAllProvidersAccepted();
          },12000)           
        }
      }
    }

    function consumeReqToExtend (){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.consumerExtendReq+$scope.zoomAndProviderDetail.consult_id,'GET',{},token,'',true);
    }
    function openExtend(from){
      if($scope.consultData.consult_medium == 'Multi-Provider'){
        $scope.extendEnable = false;
      }else{
        $scope.extendEnable = true;
      }

      $scope.appointmentData.coupon_code = '';
      coupanCodePaymentService.getCards($scope,token);
      $scope.extendTimeArray = [10,20,30];
      if(from == 'manual'){
        $scope.appointmentData.extendTime = "10";
        consumeReqToExtend();
      }
      $scope.oModal ={};
      getPrice();            
      showModalService.show($scope,'modules/consumer/consultWaitingRoom/template/extendMeeting.html','extend');
      acceptRequestByCons('Accepted');
    }

    function cancelRequestForExtend(status){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.cancelRequestForExtend + $scope.consultData.id, 'GET', {}, token,'','silent'); // get the consumer detail list  
      promise.then(function(res) {     
        if (res.data.status == false) {
          toastMsg.show(res.data.message);
        }
      })
      acceptRequestByCons('Declined');
    }

    /**
    * function to show modal of Schedule a follow up
    */
    function showModal(type){
      switch(type){
        case 'Extend':
          if(!$scope.alreadyEnded){
            coupanCodePaymentService.getCards($scope,token);
            $scope.extendTimeArray = [10,20,30];
            $scope.appointmentData.extendTime = "10";
            $scope.oModal ={};
            getPrice();
            $scope.extendEnable = true;            
            showModalService.show($scope,'modules/consumer/consultWaitingRoom/template/extendMeeting.html','extend');
          }
        break;
        case 'S-Follow-Up':
            $scope.consultation_end_date = {
              displayDate: convertDate.toMMddYYYYInString(new Date()),
              displayTime: convertDate.toAmPM(new Date()),
              date:new Date()
            };
            $scope.consultation_start_date = {
              displayDate: convertDate.toMMddYYYYInString(new Date()),
              displayTime: convertDate.toAmPM(new Date()),
              date:new Date()
            };
          showModalService.show($scope,'templates/scheduleAFollowUp.html'); 
        break;

        case 'rateProviders':
          clearInterval(interval);
          getProvidersListToBeRated();
          showModalService.show($scope,'modules/consumer/consultWaitingRoom/template/rateProviders.html');  
          break;
      }
     
    }

    /* 
    *function to hide modal 
    */
    function hideModal (name){
      if(name){
        $scope.oModal.hide();
        $scope.oModal.remove();
      }else{
        showModalService.hide(true);
      }

    }


    /**
    * function to show date time picker
    */
    function showDateTimePicker(type){
      validateDate.showDatePickerforCosult($scope,type);
    }

    /*
    * function for scheduling a follow up 
    */
    function submitScheduleFollowUp(){ // form and data
      if(validateTime()){
        var data={};
        data.consult_id = $scope.consultData.id;
        data.consultation_start_time =   $filter('date')($scope.consultation_start_date.date, 'HH:mm:00');
        data.consultation_end_time = $filter('date')($scope.consultation_end_date.date, 'HH:mm:00');
        data.consultation_start_date = $filter('date')($scope.consultation_start_date.date, 'MM/dd/yyyy');
        consultRoomService.scheduleFollowUp(data,token);
      }
    }

    function validateTime(){
      if($scope.consultation_start_date.date < $scope.consultation_end_date.date && $scope.consultation_start_date.date >= new Date()){
        return true;
      }else{
        if($scope.consultation_start_date.date <= new Date()){
          toastMsg.show('You can not choose time less than or equal to current time');
        }else{
          toastMsg.show('You can not choose start time greater than or equal to end time');
        }
        return false;
      }
    }

    /*
    * function to end meeting
    */
    function endMeeting(type){
      var slient =false;
      if(type == ' '){
        slient = true; // not to show loader
      }
      if(!$scope.alreadyEnded){
        consultRoomService.endConference(type,$scope,$scope.consultData.id,token,'consumer',slient);
      }
    }
    /*
    *function to get price to extend the meeting
    */

    function getPrice(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getPriceForExtendMeeting+$scope.consultData.id+'/'+$scope.appointmentData.extendTime,'GET',{},token);
      promise.then(function(res) {
        if (res.data.status == true) {
          loadingFactory.hide();
          $scope.appointmentData.total_amount = res.data.data.specialityPrice;
        } else if (res.data.status == false) {
          loadingFactory.hide();
        }
      }, function(err) {
        loadingFactory.hide();
      })
    }

    /*
    * function to check coupan code 
    */

    function checkCouponCode(){
      if($scope.appointmentData.coupon_code){
         var data = {
          "coupon_code"  : $scope.appointmentData.coupon_code,
          "consult_type" : $scope.consultData.consult_medium == "Concierge" ?'concierge' : ($scope.consultData.consult_medium  == 'Multi-Provider' ?'multi-provider' :'schedule'),
          "speciality"   : $scope.consultData.speciality_id ,
          "amount"       : $scope.appointmentData.total_amount
        }
        coupanCodePaymentService.checkCoupanCode(data,$scope,token,'coupon_codeError');
      }
    }
    /*
    * function to add card model
    */

    function addCard(){
      $scope.cardInfo = {};
      $scope.months = [1,2,3,4,5,6,7,8,9,10,11,12];
      $scope.years = addYears();
      commonGetterService.getStates($scope);
      showModalService.show($scope,'modules/consumer/billing/template/add-card.html');
      $scope.typeofAction = 'Add';
    }

    /*
    * add card
    */
    function addYears(){
        var dd = new Date();
        dd = dd.getFullYear();
        var oldYr = dd;
        var yr = [];
        yr.push(dd);
        for(var o = 1;o <30 ;o++){
            yr.push(++dd);
        }
        return yr.sort();
    }

    function submitExtendMeeting(){
      if($scope.appointmentData.extendTime && !$scope.noCards && $scope.extendEnable){
      var promiseExtend = serverRequestFactory.serverComm(globalConstants.serviceUrl.extendMeeting,'POST',{"meeting_id":$scope.consultData.meeting_id,"consultation_id":$scope.consultData.id,"extended_time":$scope.appointmentData.extendTime,"coupon_code": $scope.appointmentData.couponCode},token);
          promiseExtend.then(function(res) {
            if (res.data.status == true) {
              if(document.getElementById('timeErr')){
                document.getElementById('timeErr').innerHTML ='';
              }
              toastMsg.show("This meeting has been extended for " + $scope.appointmentData.extendTime+ " minutes");
              loadingFactory.hide();
              hideModal('extend');
            } else if (res.data.status == false) {
              toastMsg.show(res.data.message);
              loadingFactory.hide();
            }
          }, function(err) {
            loadingFactory.hide();
          })
      }else{
        if(!$scope.appointmentData.extendTime){
          document.getElementById('timeErr').innerHTML ='This field is required';
        }else if($scope.noCards){
          toastMsg.show('Please select any card for payment,Or add new card');
        }
      }

    }

    /******** save a new card  *********/
    $scope.stripeCallback = function(code,result){
      coupanCodePaymentService.submitStrip(code, result,$scope,token);
    }
    $scope.closeModal =function(){
      hideModal();
    }


    /**
    * Rate the provider
    */
    $scope.rate =[];
    $scope.ratingsObject = {
        iconOn: 'ion-ios-star',    //Optional
        iconOff: 'ion-ios-star-outline',   //Optional
        iconOnColor: 'rgb(200, 200, 100)',  //Optional
        iconOffColor:  'rgb(200, 100, 100)',    //Optional
        rating:  5, //Optional
        minRating:1,    //Optional
        callback: function(rating, index) {    //Mandatory
          ratingsCallback(rating, index);
        }
    };

  
      var ratingsCallback = function(rating, index) {
        $scope.rate[index]['rating'] = rating;        
      };

      /**
      *. get list of providers to be rated
      */
      function getProvidersListToBeRated(){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getProviderList + $scope.consultData.id, 'GET', {}, token);
        promise.then(function(res) {        
          if (res.data.status == true && res.data.data != "None") {
            $scope.ProvidersListToBeRated = res.data.data;
            for(var i=0;i< $scope.ProvidersListToBeRated.length ;i++){
              $scope.rate[i] = new Object ();
              $scope.rate[i]['rating'] = 5;
              $scope.rate[i]['provider_id'] = $scope.ProvidersListToBeRated[i].id;
              $scope.rate[i]['favorite'] = 'N';
            }
            loadingFactory.hide();
          } else {
            $scope.ProvidersListToBeRated =[];
            loadingFactory.hide();
         }
        }, function(err) {
          loadingFactory.hide();
        });
      }

    /**
    * service call to rate the provider 

    */

    var rateProvider = function(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addRating, 'POST', $scope.rate,token);
      promise.then(function(res) {        
         if (res.data.status == true) {             
             loadingFactory.hide();
             hideModal();
             $scope.rate = [];
             $scope.alreadyEnded = true;
             showModal('S-Follow-Up');
          }else {
            loadingFactory.hide();
          }
      }, function(err) {
        loadingFactory.hide();
      });
    }

    var goToDashBoard = function(){
      hideModal();
      $state.go('mainView.conVirtualHealth').then(function(){
        $ionicHistory.removeBackView();
      });
    }
    function ifAllProvidersAccepted(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.MultiproviderAccepted+$scope.zoomAndProviderDetail.consult_id,'GET',{},token,'',true);  
      promise.then(function(res){
        if(res.data.status == true){
          clearInterval(interval2);
          $scope.extendEnable = true;
        }else if(res.data.status == false){
          if(res.data.data == 'Declined'){
            hideModal('extend');
          }
          clearInterval(interval2);
          $scope.extendEnable = false;
        }
      })
    }
    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall = function(functionName,params){
      switch(functionName){
        case 'showDateTimePicker':
            showDateTimePicker(params);
            break;
        case 'ScheduleFollowUp':
            submitScheduleFollowUp(params)
            break;
        case 'goBack':
            goBack();
            break;
        case 'hideModal':
          hideModal(params);
        break;
        case 'showModal':
          showModal(params);
        break;
        case 'endMeeting':
          endMeeting(params);
        break;
        case 'getPrice':
          getPrice();
          break;
        case 'checkCouponCode':
          checkCouponCode();
        break;
        case 'updateCardIdOnchange':
          coupanCodePaymentService.updateCardIdOnchange(params,$scope,token);
        break;
        case 'extendMeeting':
          submitExtendMeeting(params);
        break;
        case 'addCard':
          addCard();
        break;
        case 'rate':
          rateProvider();
        break;
        case 'goToDash':
          goToDashBoard();
        break;

      } 
    }


    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(true);
      data.enableBack = true;
      $rootScope.showMenu = false;
    });

    $scope.$on('$ionicView.beforeLeave',function(){
      cordova.plugins.backgroundMode.disable();
      if(interval){
        clearInterval(interval);
      }
    })

});
