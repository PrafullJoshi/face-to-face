face2face.controller('consumerProfile',function($scope,globalConstants,serverRequestFactory,$window,$injector,requiredFactory,Scopes,otherValidationCheck,$state,loadingFactory,toastMsg,$ionicNavBarDelegate,$rootScope){
$scope.list = {};
$scope.message = '';
$scope.consList={}
if(localStorage.userData){
  var userData = JSON.parse(localStorage.userData);
  var token = userData.token;
}
var init = function(){
  $scope.consData = {
    consumer_billing_details:{
        "0":{}
    },
    stripe:{}
  };

 // gets the dropdown list from the api
  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStateList,'GET','','','','silentcall');  
    promise.then(function(res){
      if(res.data.status == true && res.data.data != "None"){    
         $scope.consList.stateList =  res.data.data;
         console.log($scope.consList.stateList);
         //$('#loader').hide();
       }else if(res.status == false){
      
     }
    },function(err){
   })

  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getconsDetail,'GET','',token);  // to get the consumer detail list  
  promise.then(function(res){
     var res = res.data;
     if(res.status == true){   
      $scope.consData.community_username = (res.data.community_username) ? res.data.community_username : "";
      $scope.consData.fname = (res.data.fname) ? res.data.fname : "";
      $scope.consData.lname = (res.data.lname) ? res.data.lname : "";
      $scope.consData.email = (res.data.email) ? res.data.email : "";
      $scope.consData.title = (res.data.title) ? res.data.title : "";
      $scope.consData.mname = (res.data.mname) ? res.data.mname : "";
      $scope.consData.consumer_billing_details['0'].type = "P";
      $scope.consData.photo = res.data.photo;
    
      if(res.data.consumer_billing_details){
            if(res.data.consumer_billing_details['0']){
                $scope.consData.consumer_billing_details['0'].address1 = (angular.isDefined(res.data.consumer_billing_details[0].address1)) ? res.data.consumer_billing_details[0].address1 : "";
                $scope.consData.consumer_billing_details['0'].address2 = (angular.isDefined(res.data.consumer_billing_details[0].address2)) ? res.data.consumer_billing_details[0].address2 : "";
                $scope.consData.consumer_billing_details['0'].city = (angular.isDefined(res.data.consumer_billing_details[0].city)) ? res.data.consumer_billing_details[0].city : "";
                $scope.consData.consumer_billing_details['0'].state_id = (angular.isDefined(res.data.consumer_billing_details[0].state_id)) ? res.data.consumer_billing_details[0].state_id.toString() : "";
                $scope.consData.consumer_billing_details['0'].zip_code = (angular.isDefined(res.data.consumer_billing_details[0].zip_code)) ? res.data.consumer_billing_details[0].zip_code : "";
                $scope.consData.consumer_billing_details['0'].primary_phone = (angular.isDefined(res.data.consumer_billing_details[0].primary_phone)) ? res.data.consumer_billing_details[0].primary_phone : "";
                $scope.consData.consumer_billing_details['0'].secondary_phone = (angular.isDefined(res.data.consumer_billing_details[0].secondary_phone)) ? res.data.consumer_billing_details[0].secondary_phone : "";
                $scope.consData.consumer_billing_details['0'].work_phone = (angular.isDefined(res.data.consumer_billing_details[0].work_phone)) ? res.data.consumer_billing_details[0].work_phone : "";
                $scope.consData.consumer_billing_details['0'].fax = (angular.isDefined(res.data.consumer_billing_details[0].fax)) ? res.data.consumer_billing_details[0].fax : "";
                $scope.consData.consumer_billing_details['0'].id = (angular.isDefined(res.data.consumer_billing_details[0].id)) ? res.data.consumer_billing_details[0].id : "";
                 
             }

            loadingFactory.hide();
      
      }
  
     }
     else if(res.status == false){
      loadingFactory.hide();
   }

  

  },function(err){ 
    loadingFactory.hide();
  })
  
}
 
$scope.submitconsumerProfile = function(form){
  if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
    cordova.plugins.Keyboard.close();
  }
  if(requiredFactory.validateBeforeSubmit(form,$scope) && otherValidationCheck.validateBeforeSubmit()){
      var promisePPl = serverRequestFactory.serverComm(globalConstants.serviceUrl.consumerProfile,'POST',$scope.consData,token);  // get the consumer detail list  
      promisePPl.then(function(res){
        var res = res.data;
        if(res.status == true ){ 
          toastMsg.show("Your Profile has been edited successfully");
          loadingFactory.hide();  
                                            
         }
         else if(res.status == false){
          toastMsg.show('Oops! some error occured. Please try again later');
          loadingFactory.hide();
         }


        },function(err){ 
          loadingFactory.hide();
          
        })
    }
        

 }

init();  // initialize the controller ..

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(false);
      data.enableBack = false;
      $rootScope.showMenu = true;
    }); 

});
