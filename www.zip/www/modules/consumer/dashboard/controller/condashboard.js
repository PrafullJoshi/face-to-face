face2face.controller('conDashboard',function($scope,loadingFactory,serverRequestFactory,globalConstants,$window,getAppointments,$state,toastMsg,$rootScope,$ionicHistory,convertDate,$ionicNavBarDelegate,commonGetterService){
   
   $scope.searchRecord = "";
   
    //$scope.isActive1 = true;
    //$scope.isActive2 = true;
  /** To get the token from localstorage **/
  if(localStorage.userData){
      var userData = JSON.parse(localStorage.userData);
      token = userData.token;
      getInboxCount(token)
      usertype = userData.userTypeId;
      $scope.name = userData.fname +' '+ userData.lname;
      if(usertype == 2){
        $rootScope.mTemplate = "modules/main/mainView/template/menu.html";
        $rootScope.tabFlag = true;  
      }
      else{
        $rootScope.mTemplate = "modules/main/mainView/template/menuProvider.html";
        $rootScope.tabFlag = false;  
      }
  }   
  $scope.appList='';
  $scope.gotoVirtualH = function(){
    if(usertype == 2){
      $state.go('mainView.conVirtualHealth');
    }else {
      $state.go('mainView.proVirtualHealth');
    }
  }

  $scope.gotoCommunity = function(){
    $state.go('mainView.communityListing');
  } 

  $scope.gotoElearning = function(){
    //$state.go('mainView.inbox');
      $state.go("mainView.eLearning");
  }
  $scope.gotoInbox = function(){
    $state.go('mainView.inbox');
  }
  $scope.gotoEmr = function(){
    commonGetterService.openEmr();
  }
  /** get upcoming appointments ***/


  $scope.convertedDate = function(date){
    return convertDate.toMMddYYYYInString(date);
  }

  $scope.convertDate = function(time){
   if(ionic.Platform.isIOS()){
           time = time.replace(/-/g, "/");
           return convertDate.toAmPM(time)     
       }
       else{
          return convertDate.toAmPM(time)
   }
    
  }

  function changeAvailability(){
    var promise;
    promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getAppointments+'/scheduled','POST',{"search": $scope.searchRecord},token,'',true);
    promise.then(function(res) {
      
      if(res.data.status == true && res.data.data != 'None') {
        
        $scope.appList = res.data.data;

        $scope.appList.sort(function(a, b){
          return  new Date(b.start_time) - new Date(a.start_time);
        });
        //alert(JSON.stringify($scope.data))
        $scope.data = $scope.appList[0];
        loadingFactory.hide();
      } 
    }, function(err) {

     
    });
  }

    function getInboxCount(token){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.inboxDetail+1, 'POST', 
        {
            "status": '',
            "limit":10

        },token,'',true);                     
      promise.then(function(res) {
        loadingFactory.hide();
        if (res.data.status==true && res.data.data!= 'None' && res.data.data.inbox.length>0) {
          $scope.$parent.count = res.data.data.count;
        }else{
          if(usertype == 1)
            navigator.notification.alert(res.data.message, $scope.$parent.logout, 'Account Suspended', ['OK'])
        }
      });
    }


   changeAvailability();

   $scope.$on('$ionicView.beforeEnter', function (e, data) {
     $ionicNavBarDelegate.showBackButton(false);
     data.enableBack = false;
     $rootScope.showMenu = true;
     $rootScope.menuSelected ='';
   });

  $scope.nextWalkThrough = function(demoId){
    switch (demoId){
      case 1:
        $scope.isActive1 = true;
        $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text v-health"><h1>01</h1><h3>Virtual Health</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> NEXT</a></div>'
        break;
      case 2:
        $scope.isActive2 = true;
        $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text comunity"><h1>02</h1><h3>Community</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> NEXT</a></div>'
        break;
      case 3:
        $scope.isActive3 = true;
        $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text e-learning"><h1>03</h1><h3>E-Learning</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> NEXT</a></div>'
        break;
      case 4:
        $scope.isActive4 = true;
        $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text inbox"><h1>04</h1><h3>Inbox</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> NEXT</a></div>'
        break;
      case 5:
        $scope.isActive5 = true;
        if(usertype == 2){
          $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text hamburger-help"><h1>05</h1><h3>Main menu</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> DONE</a></div>'
        }else{
          $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text hamburger-help"><h1>04</h1><h3>Main menu</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i> DONE</a></div>'
        }
        
        break;
      case 6:
        $scope.isActive6 = true;
        $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text comunity"><h1>02</h1><h3>EMR</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i>NEXT</a></div>'
        break;
      case 7:
        $scope.isActive7 = true;
        $scope.content = '<a hre0f="javascript:void(0)" class="tutorial-close" ng-click="updateHelpparameters()" ><i class="fa fa-times" aria-hidden="true"></i> Close</a><div class="help-text inbox"><h1>03</h1><h3>Inbox</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</p><a href="javascript:void(0)" ng-click="nextButtonClick($event)" on-touch="nextButtonClick($event)" class="walkthrough-done-button help-btn-yellow"><i class="fa fa-chevron-circle-right" aria-hidden="true"></i>NEXT</a></div>'
        break;

    }
  };
    if(userData.helpHide == 'No'){
        $scope.nextWalkThrough(1);
    }
    $scope.updateHelpparameters = function(){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateHelp,"GET","",token,'',true);
        promise.then(function(response){
            if(response.data.status == true){
                userData.helpHide = "Yes";
                localStorage.userData = JSON.stringify(userData);
                loadingFactory.hide();
            }else{
                loadingFactory.hide();
            }

        })
    }
  //   document.getElementsByClassName("tutorial-close")[0].click(function(){
  // // Holds the product ID of the clicked element
  //   $scope.updateHelpparameters();
  // });
});

