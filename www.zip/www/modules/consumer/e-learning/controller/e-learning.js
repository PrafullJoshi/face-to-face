face2face.controller("eLearningCtrl",function($scope, $window,serverRequestFactory,globalConstants,$stateParams,$rootScope,$state,$timeout,requiredFactory,$stateParams,Scopes,$ionicNavBarDelegate,validateDate,showModalService,commonGetterService,consultRoomService,toastMsg,convertDate,$filter,loadingFactory,coupanCodePaymentService,showPopup,$ionicHistory) {
    var token = commonGetterService.getToken();
    $scope.purchasedCourses =[];
    var currentPage = 1;
    var limit = 10;
    var nextPage = currentPage;
    $scope.loadMore = true;
    /***
    * get purchased courses
    */

    var getCourses = function() {
      $scope.loadMore = false;
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.purchasedCourses+nextPage+'/'+limit, 'GET',{}, token); 
      promise.then(function(res) {
        if (res.data.status == true  && res.data.data != 'None' ) {
          $scope.purchasedCourses = $scope.purchasedCourses.concat(res.data.data.list);
          currentPage = parseInt(res.data.data.page.current);
          nextPage = currentPage + 1;
          var count = parseInt(res.data.data.page.count);
          if(count > currentPage * limit) {
            $scope.loadMore = true;
          }
        }
        loadingFactory.hide();
      },function(response){
        loadingFactory.hide();
      })
    }

    /*
    * This function to start course in web view 
    */
    $scope.startCourse = function(url){
      commonGetterService.openElearning(url);
    }

    $scope.loadMoreItems = function() {
      getCourses();
    }

    getCourses();
    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      if($rootScope.previousScreen.name == 'mainView.conDashboard' || $rootScope.previousScreen.name == 'mainView.proDashboard'){
        enableBack = true;
      }else{
        enableBack = false;
      }
      $ionicNavBarDelegate.showBackButton(enableBack);
      data.enableBack = enableBack;
      $rootScope.showMenu = !enableBack;
      $rootScope.menuSelected ='E-Learning';
    });

    $scope.$on('$ionicView.beforeLeave',function(){

    })

});
