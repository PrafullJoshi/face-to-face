face2face.controller('conOnDemandCtrl',function($scope,requiredFactory,serverRequestFactory,globalConstants,$timeout,getPatientsService,convertDate,$window,$state,otherValidationCheck,validateDate,$rootScope,$stateParams,commonGetterService,showModalService,loadingFactory,toastMsg,Scopes,$ionicHistory,consentService,$filter,coupanCodePaymentService,$ionicNavBarDelegate){        
    var token = commonGetterService.getToken();
    // get patient providertype & state
    getPatientsService.getPatientsforConsumer($scope,'',token);
    commonGetterService.getProviderType($scope,token);
    commonGetterService.getStates($scope);
    var getProviderStatus,chckNewProvider,providerAccepted;
    $scope.getProviderGroup = function(id,notreset){ 
        !notreset ? $scope.appointmentData.provider_group_id ='':angular.noop();     
        commonGetterService.getProviderGroup($scope,id);
    }
    $window.Stripe.setPublishableKey(globalConstants.stripeKey);
   // alert(globalConstants.stripeKey)
    $scope.appointmentData={
            "video_call":"",
            "phone_call":"",
            "multi_video_consult":"",
            "concierge_service" : "",
            "inquiry": "",
            "inquiry_type":"",
            "consult_medium" : "Video",
            "insurance_plan_id" : "",
            "state_id":'',
            "coupon_code" : ''
    };
    $scope.age ='';
    $scope.gender ='';
    $scope.inquiryType = '';
    $scope.askAnExpert = false;
    changeSelection();


    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall = function(functionName,params){
      switch(functionName){
        case 'getDetails':
            getDetails(params);
            break;
        case 'consentSubmit':
            commonGetterService.checkOndemandAvailability($scope,consentSubmit,params);
            //consentSubmit(params);
            break;
        case 'hideModal':
            hideModal();
            break;
        case 'addAddressSubmit':
            addAddressSubmit(params);
            break;
        case 'checkState':
            checkState(params);
            break;
        case 'changeSelection':
            changeSelection();
            break;
        case 'getInsurances':
            getInsurances(params);
            break;
        case 'continueSubmit':
            continueSubmit(params);
        break;
        case 'goBack':
            goBack();
        break;
        case 'changeAdd':
            changeAdd(params);
        break;
        case 'saveState':
            saveState();
        break;
        case 'addCard':
            addCard();
        break;
        case 'submitSchedule':
            submitSchedule(params);
        break;
        case 'checkCouponCode':
            checkCouponCode();
        break;    
        case 'newProviderRequest' :  
         newProviderRequest(params);
         break;
      }
    }
    function saveState(){
        Scopes.store('saveState',type);
        $state.go('mainView.addPatient_1');
    }

    function getInsurances(stateId){
        commonGetterService.getInsurancesPlanByStateId($scope,stateId,token);
    }
    function changeSelection(){
        $scope.disableCheck = true;
        document.getElementById('conciergeErr').innerHTML = '';
        $scope.templateUrl = '';
        if($scope.appointmentData.consult_medium == 'Phone'){       
            $scope.appointmentData.phone_call = 'Y';
            $scope.appointmentData.concierge_service = '';
            $scope.appointmentData.multi_video_consult = '';
            $scope.appointmentData.video_call = '';
            $scope.addClass = 'VMC';
            type = 'S';
        }else if($scope.appointmentData.consult_medium == 'Video'){
            $scope.appointmentData.video_call = 'Y';
            $scope.appointmentData.multi_video_consult = 'Y';
            $scope.appointmentData.concierge_service = '';
            $scope.appointmentData.phone_call = '';
            $scope.addClass = 'PC';
            type = 'S';
        }
    }
    /*
    * function to get enqiry type //new changes 
    */

    $scope.getProviderInquiry = function(id,newExist) {
        if(!$scope.askAnExpert){
            $scope.appointmentData.inquiry_type = "";
            $scope.typeList = [];
            //conSetAppointmentService.getInqType($scope, newExist,token);
            if(!id){
            id = '';
            }
            commonGetterService.getProviderInquiry($scope,id,newExist,'on-demand');
        }

    }
    /* 
    * get inquiry 
    */
    $scope.getInq = function(id,typ){
        $scope.appointmentData.inquiry = "";
        if(id){
            commonGetterService.getInq($scope,JSON.parse(id).id,token);
        } else{
            $scope.inqList = [];
        }    
    }

    /*
    * function to get details and address(only in case of Concierge) of patient
    */
    function getDetails(){
        $scope.askAnExpert = false;
        getPatientsService.showAskAnExpertPopup($scope,$scope.appointmentData.patient_id,token,true); // true for oN-Demand consult
        // getPatientsService.getPatientDetails($scope,$scope.appointmentData.patient_id,'',token); 
    }

    /*
    * search provider 
    */
   function continueSubmit(form){
    if(requiredFactory.validateBeforeSubmit(form,$scope) && otherValidationCheck.validateBeforeSubmit(form)){
            if($scope.appointmentData.inquiry_type){
              $scope.appointmentData.inquiry_type_id =JSON.parse($scope.appointmentData.inquiry_type).id;
              $scope.appointmentData.inquiry_id =JSON.parse($scope.appointmentData.inquiry_type).id;
            }
            var promiseRes = serverRequestFactory.serverComm(globalConstants.serviceUrl.searchProviderOnDemand, 'POST',$scope.appointmentData,token);
            promiseRes.then(function(res) {
                if (res.data.status == true) {
                    loadingFactory.hide();
                    Scopes.store('appointmentData',$scope.appointmentData);
                    $scope.title = "Create Appointment";
                    $scope.templateUrl = 'modules/consumer/scheduleAppointment/template/consentSign.html';
                    showModalService.show($scope,'modules/consumer/scheduleAppointment/template/detailsModalOnDemand.html','appointment');
                  
                    // get consent to show in popup
                    $timeout(function(){
                    consentService.getConsent($scope,globalConstants.serviceUrl.patientConsentPage);
                    $scope.appointmentData.consultation_dob = $filter('date')(new Date(), 'MM/dd/yyyy');
                    },100);
                                      
                }else {
                    toastMsg.show("No provider available");
                    loadingFactory.hide();
                }
                }, function(err) {
                    loadingFactory.hide();
                });
        
    }
   }

  /*
  *  submit consent  
  */

  function consentSubmit(form,type){
      if(requiredFactory.validateBeforeSubmit(form,$scope)){
          newProviderRequest($scope.appointmentData);
          //$scope.templateUrl = "modules/consumer/scheduleAppointment/template/waitingForConsult.html";
        //  getCards();
      }
      else if(type){
        $scope.closePopup();
        newProviderRequest($scope.appointmentData);
      }
  }
 
 /*
 *  waiting for the consult (45 mins api)
 */
 function newProviderRequest(data) {
     $scope.templateUrl = "modules/consumer/scheduleAppointment/template/waitingForConsult.html";
     var panOnDemandAppointment = serverRequestFactory.serverComm(globalConstants.serviceUrl.panOnDemandAppointment, 'POST', data, token);
     panOnDemandAppointment.then(function(res) {
         if (res.data.status == true) {
             if (res.data.data != "None") {
                 $scope.consumerData = res.data.data;
                 $scope.appointmentData.provider_ids = res.data.data.provider_ids;
                 loadingFactory.hide();
                    /* count++;
                     if (count == 1) {
                         count = 0;*/
                            chckNewProvider =  $timeout(function(){
                            $scope.appointmentData.consult_ids = res.data.data.consult_ids;
                            checkStatus(res.data.data.consult_ids);
                        },30000);
                       
                    /* }*/
                 
             }
         } else {
            loadingFactory.hide();
         }

     }, function(e) {
         loadingFactory.hide();
     })
 } 
/*
* request is taking too long (30 mins api)
*/

function checkStatus(consultIds,type,data) {
    $scope.count ++;
    $scope.templateUrl = "modules/consumer/scheduleAppointment/template/requestTakingLOnger.html";

    if (angular.isDefined(consultIds)) {
        var statusPromise = serverRequestFactory.serverComm("/consultations/getConsultStatus", 'POST', {
            "consult_ids": consultIds
        }, token, '', true);
        statusPromise.then(function(res) {
            if (res.data.status == true) {
                $timeout.cancel(chckNewProvider);
                $timeout.cancel(providerAccepted);
                if (res.data.data != "None") {
                    loadingFactory.hide();
                    $scope.onDemandAppointmentId = res.data.data.id;
                    $scope.relation = res.data.data.patient_authorization_form.relationship_to_patient;
                    $scope.providerDetail = res.data.data.provider;
                    $scope.consumerDetails = res.data.data.consumer;
                    /*$interval.cancel($rootScope.interval);
                    $interval.cancel($rootScope.newProReq);
                    $scope.declinedModal = false;
                    $scope.connectingModal = false;
                    $scope.insuranceAcceptedModal = true;
                    $scope.getCards();
                    $scope.getProDetailsOnInsurancepg();
                    $scope.addCardModal = false;
                    $scope.providerConnectModal = false;
                    $scope.waitingModal = false;
                    $scope.consentModal = false;
                    $scope.phoneConsultModal = false;*/
                    $scope.templateUrl = "modules/consumer/scheduleAppointment/template/payment.html";
                    coupanCodePaymentService.getCards($scope,token);
                    coupanCodePaymentService.providerDeatilsOnInsurance($scope,token);
                    /*if(type=="nolimit"){
                        $scope.continueWaiting($scope.onDemand,'nolimit')
                    }*/
                    $scope.getproviderStartStatus();
                }
            } else {
             loadingFactory.hide();
              providerAccepted = $timeout(function(){
              newProviderRequest($scope.appointmentData)
          },45000);
            }

        });
    } else {
        loadingFactory.hide();
    }
}

/*
* add card
*/
function addYears(){
    var dd = new Date();
    dd = dd.getFullYear();
    var oldYr = dd;
    var yr = [];
    yr.push(dd);
    for(var o = 1;o <30 ;o++){
        yr.push(++dd);
    }
    return yr.sort();
}
function checkCouponCode(){
    coupanCodePaymentService.checkCouponCode($scope,token);
}

function addCard(){
    $scope.cardInfo = {};
    $scope.months = [1,2,3,4,5,6,7,8,9,10,11,12];
    $scope.years = addYears();
    showModalService.show($scope,'modules/consumer/billing/template/add-card.html');
    $scope.typeofAction = 'Add';
}
/******** save a new card  *********/
$scope.stripeCallback = function(code,result){
    coupanCodePaymentService.submitStrip(code, result,$scope,token);
}

/******** submit insurance details ************/

function submitSchedule(form){
    coupanCodePaymentService.continueOndemand($scope,token,form);
}

function hideModal(){
    $scope.oModal.hide();
    $scope.oModal.remove();
    if($scope.templateUrl != 'modules/consumer/scheduleAppointment/template/consentSign.html'){
          close();
        }
  //  if()
}

    //close add card function
    $scope.closeModal = function(){
        showModalService.hide(true);
        $scope.cardInfo = {};
        Scopes.delete('formInfo');
    }

$scope.getproviderStartStatus = function(){
    
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.checkProviderStartNow + $scope.onDemandAppointmentId, 'GET', {}, token,'','silent'); // get the consumer detail list  
    promise.then(function(res) {
         //alert(JSON.stringify(res))
        if (res.data.status == true) {
                
                  $timeout.cancel(chckNewProvider);
                  $timeout.cancel(providerAccepted);
                  $timeout.cancel(getProviderStatus);
                  var inquiry_name = $scope.appointmentData.inquiry_type ? JSON.parse($scope.appointmentData.inquiry_type).name:'';
                  var zoomAndProviderDetail = {
                    'provider' :   $scope.providerDetail,
                    'join_url'       :   res.data.data.join_url,
                    'id'     :   $scope.onDemandAppointmentId,
                    'meeting_id'     :   res.data.data.meeting_id,
                    'meeting_duration' :  res.data.data.meeting_duration,
                    'consult_medium'   : $scope.appointmentData.consult_medium,
                    'patient_id'       : $scope.appointmentData.patient_id,
                    'inquiry_name'     : inquiry_name,
                    'patient'          : {fname:$scope.patientDetails.fname}    
                  };
             //localStorage.zoomAndProviderDetail = JSON.stringify(zoomAndProviderDetail);
             Scopes.store('consultData',zoomAndProviderDetail);
              hideModal();
              $scope.appointmentData={
                        "video_call":"",
                        "phone_call":"",
                        "multi_video_consult":"",
                        "concierge_service" : "",
                        "inquiry_type":"",
                        "consult_medium" : "Video",
                        "insurance_plan_id" : "",
                        "state_id":''
                };   
              loadingFactory.hide();
             if($scope.appointmentData.consult_medium == 'Phone'){
                $state.go("mainView.consumerConsultRoom",{type : 'Phone'});
             }else{
                
                $state.go("mainView.consumerConsultRoom",{type:'onDemand'});

             }

        } else{
            if(res.data.data.consultation_status == 'Incomplete'){
                $scope.appointmentData.consultation_name = '';
                $scope.appointmentData.consultation_lname = '';
                $scope.closePopup();
            }
          $timeout.cancel(chckNewProvider);
          $timeout.cancel(providerAccepted);
          loadingFactory.hide();
            getProviderStatus = $timeout(function(){
            $scope.getproviderStartStatus();
          },10000);
        }


    }, function(err) {
        loadingFactory.hide();
    });
}
$scope.gotoSchedule =function(){
   // alert("in")
    $scope.closePopup();
    $state.go('mainView.scheduledAppoinment');
}
$scope.closePopup = function(){
    close();
    hideModal();
}

function close(){
   $scope.appointmentData={
               "video_call":"",
               "phone_call":"",
               "multi_video_consult":"",
               "concierge_service" : "",
               "inquiry": "",
               "inquiry_type":"",
               "consult_medium" : "Video",
               "insurance_plan_id" : "",
               "state_id":''
       };
    $scope.age ='';
    $scope.gender ='';
   if(getProviderStatus){
       $timeout.cancel(getProviderStatus);
   }
   if(chckNewProvider){
       $timeout.cancel(chckNewProvider);
   }
   if(providerAccepted){
       $timeout.cancel(providerAccepted);
   } 
}

function goBack(){
    $ionicHistory.clearCache();

  
      close();
  
    if($rootScope.previousScreen == 'mainView.consumerConsultRoom'){
        $state.go('mainView.conVirtualHealth');
    }
    else{
        $ionicHistory.goBack();
    }
  
}
$scope.checkOther = function(inquiry){
  inquiry = JSON.parse(inquiry);
  if(inquiry.name=="Others"){
    $scope.otherInquiry = true;
  }else{
    $scope.otherInquiry = false;
  }
}

/**** for select medical records *****/
$scope.openModalformedicalRecord = function () {
    var data = {
                    /* for scheduled appoitment*/ 
                    //speciality_id:[$scope.appointmentData.speciality_id],
                    provider_type_id:[$scope.appointmentData.provider_type_id],
                    provider_group_id:$scope.appointmentData.provider_group_id,
                    consultation_type:"on-demand"
                }
    commonGetterService.getMedicalRecordCategory(data,token,$scope);

}
$scope.shareMedicalRecords = function(selectAll){
    commonGetterService.saveMedicalRecords($scope.medicalRecordCategory,selectAll);
}
$scope.selectAllRecords = function(selectAll){
    if(!selectAll){
        angular.forEach($scope.medicalRecordCategory,function(value,key){
            $scope.medicalRecordCategory[key].share = 'No';
        })
    }
}

$scope.hideModalShare = function(selectAll){
  showModalService.hide(true);
}
/**
 * function for receive confirmation on ask an expert
 */
$scope.confirmStatus = function(patientId,status) {
    if($scope.ageWarning){
        status ? $scope.appointmentData.provider_group_id = '' : $scope.getProviderInquiry($scope.appointmentData.provider_group_id ,$scope.inquiryType);
    }else{
        status ? $scope.appointmentData.patient_id = '' : getPatientsService.getPatientDetails($scope,$scope.appointmentData.patient_id,'',commonGetterService.getToken());
    }
        
}

/**
 * function to show popup on selection of provider group
 */

$scope.showAgeWarning = function(provider_group_id ,inquiry) {
    var status = $scope.providerGrpData[provider_group_id].age_group_status;
    $scope.titleSpeciality = $scope.providerGrpData[provider_group_id].name;
    $scope.ageWarning = true; 
    getPatientsService.showAgeWarning($scope,provider_group_id,inquiry,status);
}

$scope.$on('$destroy',function(){
    $timeout.cancel(getProviderStatus);
    $timeout.cancel(chckNewProvider);
    $timeout.cancel(providerAccepted);
});

$scope.$on('$ionicView.beforeEnter', function (e, data) {
    $ionicNavBarDelegate.showBackButton(false);
    data.enableBack = false;
    $rootScope.showMenu = true;
});  

});