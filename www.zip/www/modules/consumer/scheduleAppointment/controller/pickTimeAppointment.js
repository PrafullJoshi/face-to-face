face2face.controller('conScheduledPickTimeCtrl',function($scope,requiredFactory,serverRequestFactory,globalConstants,$timeout,getPatientsService,convertDate,$window,$state,otherValidationCheck,validateDate,$rootScope,$stateParams,commonGetterService,$ionicNavBarDelegate,loadingFactory,toastMsg,Scopes,$filter,$ionicHistory,showModalService,$compile,$parse){        
    
    /*
    * Title switch function @ start
    */
    switch($stateParams.type){
        case 'S':
            $scope.viewTitle = 'Schedule';
        break;
        case 'M':
            $scope.viewTitle = 'Multi-Provider';
            $scope.templateUrl = 'modules/consumer/scheduleAppointment/template/multiProviderselection.html';
            commonGetterService.getProviderType($scope,commonGetterService.getToken());
        break;
        case 'C':
            $scope.viewTitle = 'Concierge';
        break;
    }
    $scope.specialitiesMData = [];
    $scope.providerTypes =[];
    $scope.providerTypes.push({speciality_id:'',provider_type_id:'',name:''});// this is to show two provider speciality
    $scope.age ='';
    $scope.gender ='';
    $scope.displayInq ={
        type:'',
        inquiry:''
    }
    $scope.inquiryType = '';
    $scope.patientDetails ={};
    $scope.proSpecId = [];
    var inquiryArr = [] ,flag =0;
    $scope.consultation_end_date = {
        displayDate: convertDate.toMMddYYYYInString(new Date()),
        displayTime: convertDate.toAmPM(new Date()),
        date:new Date()
    };
    $scope.consultation_start_date = {
        displayDate: convertDate.toMMddYYYYInString(new Date()),
        displayTime: convertDate.toAmPM(new Date()),
        date:new Date()
    };
    if(Scopes.get('appointmentData')){
        $scope.appointmentData = Scopes.get('appointmentData');
        if($scope.appointmentData.inquiry_type){
            $scope.displayInq = {type:JSON.parse($scope.appointmentData.inquiry_type)};
        }
        getPatientsService.getPatientDetails($scope,$scope.appointmentData.patient_id,'',commonGetterService.getToken());
    }

    if($stateParams.type == 'C'){
        var address = Scopes.get('addressOnCon');
        if(address){
            angular.merge($scope.appointmentData,address);
        }
    }
    $scope.getSpecialities = function(id,index,type){
        if($scope.providerTypes[0].provider_type_id ) {
            var age = $scope.age.split(' ')[0];
            commonGetterService.getSpecialities($scope,id,commonGetterService.getToken(),index,type,true,age);
            $scope.providerTypes[index].speciality_id = '';
        }
    }

    function showDateTimePicker(type){
        validateDate.showDatePickerforCosult($scope,type);
    }

    function goToSearchProviders(state){
        if($scope.consultation_start_date.date < $scope.consultation_end_date.date && $scope.consultation_start_date.date >= new Date()){
            $scope.appointmentData.consultation_start_time =   $filter('date')($scope.consultation_start_date.date, 'HH:mm:00');
            $scope.appointmentData.consultation_end_time = $filter('date')($scope.consultation_end_date.date, 'HH:mm:00');
            $scope.appointmentData.consultation_start_date = $filter('date')($scope.consultation_start_date.date, 'MM/dd/yyyy');
            if($scope.appointmentData.inquiry_type ){
                $scope.appointmentData.inquiry_type_id =  JSON.parse($scope.appointmentData.inquiry_type).id ;
                $scope.appointmentData.inquiry_id = JSON.parse($scope.appointmentData.inquiry_type).id ;
            }
            $scope.appointmentData['patientName'] = $scope.patientDetails.fname;
            if($stateParams.type == 'M'){
                angular.forEach($scope.providerTypes,function(value,key){
                    if(value.provider_type_id == '' || value.speciality_id == '' ){
                        $scope.providerTypes.splice(key,1);
                        Scopes.store('providerTypes',$scope.providerTypes);
                    }
                })
            }
            Scopes.store('appointmentData',$scope.appointmentData);
            $state.go(state,{type:$stateParams.type});
        }else{
            if($scope.consultation_start_date.date <= new Date()){
                toastMsg.show('You can not choose time less than or equal to current time');
            }else{
                toastMsg.show('You can not choose start time greater than or equal to end time');
            }
            
        }
    }

    /*** MultiProvider Start here*/

    // add remove provider type and speciality
    function addRemoveProviderType(params){ //params :index,type
        switch(params.type){
            case 'add':
                var addData = {speciality_id:'',provider_type_id:'',name:''};
                $scope.providerTypes.push(addData);
                break;
            case 'remove':
                $scope.providerTypes.splice(params.index,1);
                $scope.specialitiesMData.splice(params.index,1);
                break;
        }
        
    }

    function goToSearchMultiProviders(form){
        if(requiredFactory.validateBeforeSubmit(form,$scope) && checkifTwoIsSelected()){
            Scopes.store('providerTypes',$scope.providerTypes);
            goToSearchProviders('mainView.providerListingMulti');
        }
    }
     
    $scope.takeSpecialityName = function(params){ // index,id
        $scope.providerTypes[params.index].name=$scope.specialitiesMData[params.index][params.id];
        $scope.proSpecId[params.index] = params.id;
        $scope.appointmentData.inquiry_type = "";  
        $scope.getProviderInquiry($scope.inquiryType)
    }

    function checkifTwoIsSelected(){
        var count = 0;
        angular.forEach($scope.providerTypes,function(value,key){
            if(value.provider_type_id != '' || value.speciality_id != '' ){
                count++
            }
        })
        if(count > 1){
            return true;
        }else{
            toastMsg.show("Please select at least two Provider Type and Speciality");
            return false;
        }
    }

    function goBack(){
        $ionicHistory.goBack(-2);
    }

    
    
    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall = function(functionName,params){
      switch(functionName){
        case 'showDateTimePicker':
            showDateTimePicker(params);
            break;
        case 'goToSearchProviders':
            if($stateParams.type == 'M'){
                goToSearchMultiProviders(params);
            }else{
                goToSearchProviders('mainView.providerListing');
            }
            break;
        case 'addRemoveProviderType':
            addRemoveProviderType(params);
            break;
        case 'takeSpecialityName':
            takeSpecialityName(params);
            break;
        case 'goBack':
            goBack();
            break;

      }
    }

   
   /* *****  screening forms  ****** */
   $scope.typeList = [];
   $scope.getProviderInquiry = function(newExist){ 
        var specID = $scope.proSpecId.join();   
        commonGetterService.getProviderInquiry($scope,specID,newExist,'');
    
   }
   $scope.getScreeningForms = function(inquiry_type){
    if($scope.patientDetails.fname+' '+$scope.patientDetails.lname == 'No Patient'){
            return;
    }
   inquiry_type =  JSON.parse(inquiry_type);
   if(inquiry_type.name !=='Others'){
    $scope.otherInquiry = false;
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getScreeningFormFromInquiry+inquiry_type.id,'GET',{},token);
    promise.then(function(res) {
        if (res.data.status == true && res.data.data !== "None") {
            var obj = JSON.parse(res.data.data[0].form.form_structure);
            commonGetterService.getExistingInquiryForms($scope,$scope.appointmentData.patient_id,inquiry_type.id,token);
            showModalService.show($scope,'modules/consumer/scheduleAppointment/template/screeningForm.html');
             $scope.appointmentData.patient_screening_detail = '';
             $scope.screeningFormName = "";
            $scope.headerText = res.data.data[0].form.form_name;
            $timeout(function(){
               $scope.createFormElements(obj[0],res.data.data[0].form_id);
            },100);     
            loadingFactory.hide();

        } else if (res.status == false || res.data.data == "None") {
            loadingFactory.hide();
        }

    }, function(err) {

    })   
   }else{
    $scope.otherInquiry = true;
   }

   }

   $scope.createFormElements = function(obj,formID){
     
       $scope.obj = obj;
       $scope.formObj = {};
       $scope.fileObject = {};
       $scope.fileObj = {};
       $scope.err = {};
       var str,model;
       var element = angular.element(document.getElementById('addscreen'))
       $scope.newlabel = '';
       element.html($scope.newlabel);
       $compile(element.contents())($scope);
       $scope.lbl = [];
       for(var i = 0;i<$scope.obj.length;i++){

           if(obj[i].ftype == 'ftext'){
               //$scope.formObj[obj[i].name]
               $scope.limit = (obj[i].maxlength)?obj[i].maxlength:128;
               
               if($scope.obj[i].required){
                 flag++;  
                 $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><input type="text" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}" limit-to="'+$scope.limit+'" msg="Please enter a valid {{obj['+i+'].title}}" name="'+$scope.obj[i].custom_name+'" is-required formelemname="'+$scope.obj[i].custom_name+'" messageid = "'+$scope.obj[i].custom_name+'" ng-model="formObj[obj['+i+'].custom_name]"/><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span></div></label>');
               }
               else{
                $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><input type="text" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}" limit-to="{{obj['+i+'].maxlength}}" msg="Please enter a valid {{obj['+i+'].title}}" limit-to="obj['+i+'].maxlength" name="obj['+i+'].custom_name" messageid = "'+$scope.obj[i].custom_name+'" ng-model="formObj[obj['+i+'].custom_name]"/><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span></div></label>');
               
               }
             /* $scope.formObj[$scope.obj[i].custom_name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
              str = 'formObj.'+ obj[i].custom_name;
              model = $parse(str);
              model.assign($scope,(obj[i].value)?(obj[i].value):'');*/
           }
           else if($scope.obj[i].ftype == 'ftextarea'){    
               $scope.limitta = (obj[i].maxlength)?obj[i].maxlength:500;
               if($scope.obj[i].required){
                   flag++; 
                   $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><textarea rows="6" ng-model="formObj[obj['+i+'].custom_name]" class="" is-required name="'+$scope.obj[i].custom_name+'" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}" limit-to="'+$scope.limitta+'" formelemname="'+$scope.obj[i].custom_name+'" msg="Please enter a valid {{obj['+i+'].title}}" messageid = "'+$scope.obj[i].custom_name+'"/><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span></div></label>');
               }
               else{
               $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><textarea rows="6" ng-model="formObj[obj['+i+'].custom_name]" class="" name="'+$scope.obj[i].custom_name+'" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}" msg="Please enter a valid {{obj['+i+'].title}}" limit-to="'+$scope.limitta+'" messageid = "'+$scope.obj[i].custom_name+'"/><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span></div></label>');

               }
              /* $scope.formObj[$scope.obj[i].custom_name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
               str = 'formObj.'+ obj[i].custom_name;
               model = $parse(str);
               model.assign($scope,(obj[i].value)?(obj[i].value):'');*/ 
           }
         else if($scope.obj[i].ftype == 'fdropdown'){          

               if($scope.obj[i].required){
                   flag++; 
                   $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><select is-required name="'+$scope.obj[i].custom_name+'" formelemname="'+$scope.obj[i].custom_name+'" messageid = "'+$scope.obj[i].custom_name+'" ng-model="formObj[obj['+i+'].custom_name]" class=""><option value="">-- select --</option><option ng-repeat="sel in obj['+i+'].choicesVal track by $index" value="{{sel}}">{{sel}}</option></select><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span></div></label>');
               }
               else{
                   $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><select name="'+$scope.obj[i].custom_name+'" messageid = "'+$scope.obj[i].custom_name+'" ng-model="formObj[obj['+i+'].custom_name]" class=""><option value="">-- select --</option><option value="{{sel}}" ng-repeat="sel in obj['+i+'].choicesVal track by $index">{{sel}}</option></select><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span></div></label>');
               
               }
               $scope.formObj[$scope.obj[i].custom_name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
               
           }
             else if($scope.obj[i].ftype == 'fdate'){
               $scope.lbl[i] = obj[i].title;
               if($scope.obj[i].required){
               flag++; 
               $scope.newlabelw = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><div class="custom-inputs"><ul class="two-cols" ng-click="functionCall(\'showDateTimePicker\',\'start\')"><li>Select Date</li><li class="text-green semibold"><ul><li>{{formObj[obj['+i+'].custom_name]}}</li></ul></li></ul></div></label>');
             //  $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><div start-view="month" class="input-group calender_ui" moment-picker="formObj[obj['+i+'].custom_name]" format="L"><input class="" is-required formelemname="'+$scope.obj[i].custom_name+'" ng-change="chaValue(obj['+i+'].custom_name)" name="'+$scope.obj[i].custom_name+'" messageid = "'+$scope.obj[i].custom_name+'" validate-date dateerrmsg = "err.'+$scope.obj[i].custom_name+'" ng-model="formObj[obj['+i+'].custom_name]" ng-model-options="{ updateOn: \'blur\'}" /><span class="input-group-addon"><i class="fa fa-calendar"></i></span></div><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span><span ng-bind="err[obj['+i+'].custom_name]"></span></div></label>');
           }
           else{
            $scope.newlabelw = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><div class="custom-inputs"><ul class="two-cols" ng-click="functionCall(\'showDateTimePicker\',\'start\')"><li>Starts</li><li class="text-green semibold"><ul><li>{{formObj[obj['+i+'].custom_name]}}</li></ul></li></ul></div></label>');
            
           //  $scope.newlabel = angular.element('<label><span class="input-label">{{obj['+i+'].title}}</span><div start-view="month" class="input-group calender_ui" moment-picker="formObj[obj['+i+'].custom_name]" format="L"><input formelemname="'+$scope.obj[i].custom_name+'" ng-change="chaValue(obj['+i+'].custom_name)" class="" name="'+$scope.obj[i].custom_name+'" messageid = "'+$scope.obj[i].custom_name+'" validate-date dateerrmsg = "err.'+$scope.obj[i].custom_name+'" ng-model="formObj[obj['+i+'].custom_name]" ng-model-options="{ updateOn: \'blur\'}" /><span class="input-group-addon"><i class="fa fa-calendar"></i></span></div><div class="error-message"><span id="'+$scope.obj[i].custom_name+'"></span><span ng-bind="err[obj['+i+'].custom_name]"></span></div></label>');  
              
           }
           $scope.formObj[$scope.obj[i].custom_name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
           } 
           else if($scope.obj[i].ftype == 'fradio'){
               $scope.newlabel = angular.element('<div class="round-radio"><span class="input-label">{{obj['+i+'].title}}</span><label ng-repeat="li in obj['+i+'].choicesVal track by $index"><input name="'+$scope.obj[i].custom_name+'" ng-model="formObj[obj['+i+'].custom_name]" type="radio" value="{{li}}">{{li}}<i></i></label></div>');  
               $scope.formObj[$scope.obj[i].custom_name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
               if($scope.obj[i].choiceSelected){
               $scope.formObj[$scope.obj[i].custom_name]= $scope.obj[i].choiceSelected;
               }
           }
           else if($scope.obj[i].ftype == 'fcheck'){   
               $scope.arr = '';
                str = 'formObj["'+ $scope.obj[i]["custom_name"]+'"]';
                model = $parse(str);
                model.assign($scope, []); 

               $scope.getlistForChk = function(obj){
                   var listchk = [];
                   for(var j=0;j<optionslength;j++){

                       listchk.push($scope.checkedVal[j]);
                   }
                   return listchk;
               } 
              


               //$scope.cusName = obj[i].custom_name;
           //    console.log(JSON.stringify(obj[i].choicesVal)+"++++++++++++++++++")
               $scope.newlabel = angular.element('<div class="custom-checkbox"><span class="input-label">{{obj['+i+'].title}}</span><ul><li ng-repeat="li in obj['+i+'].choicesVal track by $index"><label><input name="obj['+i+'][\'custom_name\']" type="checkbox" ng-checked="getCheckedValue(li,obj['+i+'][\'custom_name\'],$index)" value={{li}} ng-click="sync(arr,li,obj['+i+'][\'custom_name\'])" ng-model="arr">{{li}}<i></i></label></li></ul></div>');                  
                  
                  var cusName = obj[i]["custom_name"];

                  if($scope.obj[i].value){
                   var tempArr = $scope.obj[i].value;
                   $scope.formObj[cusName] = $scope.obj[i].value;
                  }
                  $scope.getCheckedValue = function(val,ob,index){
                     //$scope.formObj[ob] = [];
                     if($scope.formObj[ob]){
                       for(var v=0;v < $scope.formObj[ob].length;v++){
                           if($scope.formObj[ob][v] == val){
                               
                               return true;
                           }

                       }
                     }  
                    
                     return false;
                  }
           }
           else if($scope.obj[i].ftype == 'ffile'){
               if($scope.obj[i].required){
                   flag++; 
                   $scope.newlabel = angular.element('<div class="upload-doc"><span class="input-label">Upload Document</span><ul><li><input  class="" type="text" is-required formelemname="'+$scope.obj[i].custom_name+'" messageid="'+$scope.obj[i].custom_name+'" name="'+$scope.obj[i].custom_name+'" ng-model="fObj[obj['+i+'].custom_name]"><div class="error-message"><span id="'+$scope.obj[i].custom_name+'" ng-bind="err[obj['+i+'].custom_name]"></span></div></li><li><input modelobj = "'+$scope.obj[i].custom_name+'" upload-file="fileObject.'+$scope.obj[i].custom_name+'" class="upload" type="file"><i>Browse</i></li></ul></div>');
               }
               else{
                   $scope.newlabel = angular.element('<div class="upload-doc"><span class="input-label">Upload Document</span><ul><li><input  class="" type="text" formelemname="'+$scope.obj[i].custom_name+'" messageid="'+$scope.obj[i].custom_name+'" name="'+$scope.obj[i].custom_name+'" ng-model="fObj[obj['+i+'].custom_name]"><div class="error-message"><span id="'+$scope.obj[i].custom_name+'" ng-bind="err[obj['+i+'].custom_name]"></span></div></li><li><input modelobj = "'+$scope.obj[i].custom_name+'" upload-file="fileObject.'+$scope.obj[i].custom_name+'" class="upload" type="file"><i>Browse</i></li></ul></div>');
               }
              //  $scope.fObj[$scope.obj[i].origional_name] = ($scope.obj[i].value)?($scope.obj[i].value):'';

               
           }

           element.append($scope.newlabel);
           $compile($scope.newlabel)($scope);
           $scope.lbl = [];
       }
      /* if(id){*/
           
           $scope.newlabel = angular.element('<div class="button-group mt-20"><a class="button-grey" ng-click="closeModal()">Cancel</a><a class="button-yellow" ng-click="saveForm('+formID+')">Continue</a></div>');
     /*  }
       else{
           $scope.newlabel = angular.element('<div class="col-sm-11 mt-20"><button type="button" class="btn btn-warning text-capitalize" ng-click="saveAddEditMedicalProblems(formObj,addPrblm)">Submit</button><button type="button" class="btn btn-grey text-capitalize" data-dismiss="modal">Cancel</button></div>');
       }
       */
    
       element.append($scope.newlabel);
       $compile($scope.newlabel)($scope);

    }
    
    $scope.setFormScope= function(scope){
      
     $scope.formScope = scope;
   }

   $scope.saveForm = function(formID){
   
       if (requiredFactory.validateBeforeSubmit($scope.formScope['addPrblm'], $scope) || !flag) {
            //   alert("sdfsdf")
           var inquiryId = (JSON.parse($scope.appointmentData.inquiry_type)).id; 
           var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addScreeningDetails,'POST',{"patient_id":$scope.appointmentData.patient_id,
           "inquiry_id":inquiryId,
           "form_id":formID,
           "form_data":$scope.formObj},token);
               promise.then(function(res) {
                   if (res.data.status == true) {
                       $scope.formObj = {};
                       $scope.appointmentData.patient_screening_detail_id = res.data.data.id;
                       showModalService.hide(true);
                       loadingFactory.hide();
                   } else if (res.status == false) {
                       loadingFactory.hide();
                   }

               }, function(err) {

               })
       }
   }

   $scope.sync = function(bool,item,propName){
     if(bool){
       // add item
      //$scope.formObj[propName]=temarr; 
      $scope.formObj[propName].push(item);
     } else {
       // remove item
       for(var i=0 ; i < $scope.formObj[propName].length; i++) {
         if($scope.formObj[propName][i] == item){
           $scope.formObj[propName].splice(i,1);
         }
       }      
     }
     
   };
   $scope.chaValue = function(property){
      //$scope.err[property] = '';
       delete $scope.err[property];
   }

   $scope.uploadDocFile = function(file,ty,form,modelName){
       $scope.contractErr = "";
       if(!modelName){
           $scope.docErr = '';
           var validFormats = 'pdf';
           var size = file.size/1000000 ; // file size in mB
           var ext = (file.name).substring(file.name.lastIndexOf('.') + 1).toLowerCase();
           if(validFormats.indexOf(ext) === -1 || size > 3) {
                           if (size > 3) {
                               $scope.docErr = "File size can not exceed 3 mB";
                           } else {
                               $scope.docErr = "File format should be only pdf";
                           }
         }else{
                   var fileReader = new FileReader();
                   fileReader.readAsDataURL(file);
                   fileReader.onload = function(e) {
                       file.dataUrl = e.target.result;   /*add dataUrl to file properties*/
                       $scope.uploadDoc.doc = file.dataUrl;
                       angular.element(document.querySelector("#uploaddoc")).val(null);
                       uploaddoc();
                   }
         }
                  
       }
       else{
           delete $scope.err[modelName];
           var validFormats = ['jpg', 'img', 'jpeg', 'png', 'bmp','pdf'];
           var size = file.size/1000000 ; // file size in mB
           var ext = (file.name).substring(file.name.lastIndexOf('.') + 1).toLowerCase();
           if(validFormats.indexOf(ext) === -1 || size > 3) {
                           if (size > 3) {
                               $scope.err[modelName] = "File size can not exceed 3 mB";
                           } else {
                               $scope.err[modelName] = "File format should be either jpeg, jpg, img, bmp, png, pdf";
                           }
         }
         else{
               var fileReader = new FileReader();
               fileReader.readAsDataURL(file);
               fileReader.onload = function(e) {
                   $scope.fObj[modelName] = file.name;
                   file.dataUrl = e.target.result;   /*add dataUrl to file properties*/
                   //console.log("file.dataUrl :",file.dataUrl);
                   $scope.formObj[modelName] = file.dataUrl;
               
               }
         }
           
       }
       
   }

           //close add card function
        $scope.closeModal = function(check){
            showModalService.hide(true);
           // $scope.cardInfo = {};
            if(!check){
              $scope.appointmentData.inquiry_type = "";
            }
            var screeningFormObj = JSON.parse($scope.appointmentData.patient_screening_detail);
            $scope.appointmentData.patient_screening_detail_id = screeningFormObj.id;
            $scope.screeningFormName = screeningFormObj.formName;
            Scopes.delete('formInfo');
        }

                /**** for select medical records *****/
            $scope.openModalformedicalRecord = function () {
                var data = {
                                /* for scheduled appoitment*/
                                speciality_id:[],
                                provider_type_id:[],
                                //provider_group_id:$scope.onDemand.provider_group_id,
                                consultation_type:"multi-provider"
                            }
                angular.forEach($scope.providerTypes,function(value,key){
                    if(value.provider_type_id){
                        data.provider_type_id.push(value.provider_type_id);
                        data.speciality_id.push(value.speciality_id);
                    }
                })
                //console.log(data)
                commonGetterService.getMedicalRecordCategory(data,token,$scope);

          };
        $scope.shareMedicalRecords = function(selectAll){
            commonGetterService.saveMedicalRecords($scope.medicalRecordCategory,selectAll);
        }
        $scope.selectAllRecords = function(selectAll){
            if(!selectAll){
                angular.forEach($scope.medicalRecordCategory,function(value,key){
                    $scope.medicalRecordCategory[key].share = 'No';
                })
            }
        }

        $scope.hideModalShare = function(selectAll){
          showModalService.hide(true);
        }

        /**
         * function for receive confirmation on ask an expert
         */
        $scope.confirmStatus = function(patientId,status,index) {
            if($scope.ageWarning){
                status ? $scope.providerTypes[index].speciality_id = '' : $scope.getProviderInquiry($scope.appointmentData.speciality_id,$scope.inquiryType);
            }else{
                status ? $scope.appointmentData.patient_id = '' : getPatientsService.getPatientDetails($scope,$scope.appointmentData.patient_id,'',commonGetterService.getToken());
            }
                
        }
        /**
         * function to show popup on selection of provider group
         */

        $scope.showAgeWarning = function(speciality_id ,inquiry,index) {
            if($scope.specialitiesMData) {
                var status = $scope.specialitiesMData[index][speciality_id].age_group_status;
                $scope.titleSpeciality = $scope.specialitiesMData[index][speciality_id].title;
                $scope.ageWarning = true; 
                getPatientsService.showAgeWarning($scope,speciality_id,inquiry,status,index);
            }
        }
        /**
         * show popover for speciality description
         */
        $scope.showPopover = function(e,index) {
            var description = $scope.specialitiesMData[index][$scope.providerTypes[index].speciality_id].description;
            var title = $scope.specialitiesMData[index][$scope.providerTypes[index].speciality_id].title;
            commonGetterService.showSpecialityDescription(description,title,$scope,e);
        }
       // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      //showModalService.destroy();
    });

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(true);
      data.enableBack = true;
      $rootScope.showMenu = false;
    }); 

    $scope.$on('$ionicView.enter', function (e, data) {
        $scope.providerTypes.push({speciality_id:'',provider_type_id:'',name:''});
    }); 

});