face2face.controller('providerListingCtrl',function($scope,requiredFactory,serverRequestFactory,globalConstants,$timeout,getPatientsService,convertDate,$window,$state,otherValidationCheck,validateDate,$rootScope,$stateParams,commonGetterService,showModalService,$ionicNavBarDelegate,loadingFactory,toastMsg,Scopes,$ionicHistory,$filter){        
    
    var totalRecord ={};
    $scope.loadMore = false;
    searchProviders(Scopes.get('appointmentData'));
    $scope.noRecord = false;
    /*
    * Title switch function @ start
    */
    switch($stateParams.type){
        case 'S':
            $scope.viewTitle = 'Schedule';
        break;
        case 'M':
            $scope.viewTitle = 'Multi-Provider';
        break;
        case 'C':
            $scope.viewTitle = 'Concierge';
        break;
    }

    /*
    * function to search providers
    */

    function searchProviders(data){
        var promise;
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.searchProviders, 'POST', data, commonGetterService.getToken());
        promise.then(function(res) {
            if (res.data.status == true) {
                if(res.data.data != "None"){
                    $scope.providersRecord = res.data.data;
                    // if(Object.keys(totalRecord).length <= 6){
                    //     $scope.providersRecord = totalRecord;
                    //     $scope.loadMore = false;    
                    // }else{
                    //     $scope.loadMore = true;   
                    //     $scope.providersRecord = [];
                    //     for(var i=0; i<6; i++){
                    //         $scope.providersRecord[i] = totalRecord[i];
                    //     }
                    // }
                    $scope.noRecord = false;
                }else{
                    $scope.loadMore = false;
                    $scope.noRecord = true;

                }
                loadingFactory.hide();
                                    
            } else {
                loadingFactory.hide();
               
            }
        }, function(err) {
            loadingFactory.hide();
        });
    }

    /**
    *function to load more provider if provider count is greater than 6
    */

    $scope.loadMoreData = function(){
        var l = $scope.providersRecord.length;
        var endl = Object.keys($scope.totalRecord).length;
        for(var i=l;l< endl;i++){
            $scope.providersRecord[i] = totalRecord[i];
        }
    }

    /*
    * function to go to calendar to schedule appointment
    */
    $scope.oModal ={};
    $scope.schedule = function(providerData){ 
        var appointmentData = Scopes.get('appointmentData');
        appointmentData.provider_id = providerData.id;
        //angular.merge(appointmentData,providerData);

        Scopes.store('appointmentData',appointmentData);
        loadingFactory.show();
        onEventSelected();
        //$state.go("mainView.conCalendar",{type:$stateParams.type});

    }
    function onEventSelected () {      
        showModalService.show($scope,'modules/consumer/scheduleAppointment/template/detailsModal.html','appointment');
    };

    $scope.addToFavorite = function(id,index){
        if(!$scope.providersRecord[index].is_favourite){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addToFavorite,'POST',{"provider_id":id,"status":"Active"},commonGetterService.getToken());
            promise.then(function(res){
                if(res.status){
                    loadingFactory.hide();
                    $scope.providersRecord[index].is_favourite = true;
                }

            })
        }
    }
    var moreInfo = function(index){
        $scope.buttonTitle = 'Schedule';
        $scope.infoIndex = index;
        $scope.providerDetails = $scope.providersRecord[index];
        $scope.title = "Provider Description";
        $scope.templateUrl = 'modules/consumer/scheduleAppointment/template/moreInfo.html';
        showModalService.show($scope,'modules/consumer/scheduleAppointment/template/detailsModalOnDemand.html');
    }

    $scope.functionCall = function(type,params){
        switch(type){
            case 'hideModal':
                showModalService.hide();
                $scope.infoIndex ='';
            break;
            case 'moreInfo':
                moreInfo(params);
            break;
            case 'selectAndSchedule':
                $scope.schedule(params);
            break;

        }
    }



    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      //showModalService.destroy();
    });

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(true);
      data.enableBack = true;
      $rootScope.showMenu = false;
    });  

});