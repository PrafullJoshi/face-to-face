face2face.controller('providerListingMultiCtrl',function($scope,requiredFactory,serverRequestFactory,globalConstants,$timeout,getPatientsService,convertDate,$window,$state,otherValidationCheck,validateDate,$rootScope,$stateParams,commonGetterService,showModalService,$ionicNavBarDelegate,loadingFactory,toastMsg,Scopes,$ionicHistory,showPopup){        
    
    var totalRecord ={};
    $scope.loadMore = false;
    $scope.appointmentData = Scopes.get('appointmentData');
    var providerTypes = Scopes.get('providerTypes');
    var noOfProviders = providerTypes.length;
    $scope.saveInsurance_plan_id = $scope.appointmentData.insurance_plan_id;
    $scope.noRecord = true;
    var selectedProviderIndex={} // array to keep track from which index provider type is selected
    var removedDropDownObject=["NA","NA","NA","NA","NA"]; // array to keep track removed provider type and specility
    var token = commonGetterService.getToken();
    $scope.listProviders = {};
    var previousSelectedPosition; // this is used to replace the selected provider with the previous one
    var index = 0;
    searchProviders();

    /**
    * Rating object
    */
    $scope.ratingsObject = {
        iconOn: 'ion-ios-star',    //Optional
        iconOff: 'ion-ios-star-outline',   //Optional
        iconOnColor: 'rgb(200, 200, 100)',  //Optional
        iconOffColor:  'rgb(200, 100, 100)',    //Optional
        rating:  1, //Optional
        minRating:1,    //Optional
        readOnly:true,
        callback: function(rating, index) {    //Mandatory
            
        }
    };

    /*
    * function to search providers
    */
    $scope.appointmentData.provider_id =[];
    function searchProviders(){
        if(index < noOfProviders){
            if(index+1==noOfProviders){
                $scope.buttonText = "Schedule";
            }else{
                $scope.appointmentData.insurance_plan_id = '';
                $scope.buttonText = "Next";
            }
            $scope.appointmentData.speciality_id = providerTypes[index].speciality_id;
            $scope.appointmentData.provider_type_id = providerTypes[index].provider_type_id;
            $scope.name = providerTypes[index].name;

            // sending selected providerIds to api to remove duplicate providers            
            if(!angular.equals(selectedProviderIndex, {})){  // check if any provider selected
                $scope.appointmentData.provider_id.push(selectedProviderIndex[index-1]);
            }

            var promiseRes = serverRequestFactory.serverComm(globalConstants.serviceUrl.searchProvidersForMultiSchedule,'POST',$scope.appointmentData,token);
            promiseRes.then(function(res){
                if (res.data.status == true && res.data.data != "None") {
                    $scope.listProviders = res.data.data;
                    // angular.forEach($scope.listProviders,function(value,key){
                    //     $scope.ratingsObject[]
                    // })
                    loadingFactory.hide();
                    $scope.noRecord  =false;
                    index++;
                    previousSelectedPosition ='';
                } else {
                    $scope.listProviders ={};
                    index++;
                    //toastMsg.show("No provider Found");
                    loadingFactory.hide();
                    $scope.noRecord = true;
                }
            },function(err) {
                toastMsg.show("Oops!! Something went wrong, Please Try again after sometime");
                loadingFactory.hide();

            }) 

        }
    }

    /*
    * select or remove provider
    */

    $scope.selectProvider = function(position){
        
        if(!selectedProviderIndex[index-1]){
            loadingFactory.show(); 
            addProvider(index-1,position);                             
        }else{
            if(previousSelectedPosition != position){
                showAlert(position);
            }
        }
    }


    /** 
    ** function to add selected provider at index for which it is searched
    */

    function addProvider(saveAt,fromPosition){

        selectedProviderIndex[saveAt] = $scope.listProviders[fromPosition].id;   
        $scope.listProviders[fromPosition].selected = true; 
        previousSelectedPosition = fromPosition;
        loadingFactory.hide();
    }

    function showAlert(newPosition){
        showPopup.show('You have already selected one provider',"<p>Do you want to replace it?</p>",$scope,newPosition,'Ok');
    }


    function replace(newPosition){
        loadingFactory.show();
        $scope.listProviders[previousSelectedPosition].selected = false; 
        addProvider(index-1,newPosition);
        
    }

    /*
    * function to go to calendar to schedule appointment
    */
    $scope.oModal ={};
    function schedule(){
        if(new Date($scope.appointmentData.consultation_start_date + ' '+ $scope.appointmentData.consultation_start_time) > new Date() && !angular.equals(selectedProviderIndex, {})){
            if(Object.keys(selectedProviderIndex).length  > 1){
                var temp =[];
                angular.forEach(selectedProviderIndex, function(value, key) {
                    this.push({provider_id:value,speciality_id:providerTypes[key].speciality_id,provider_type_id:providerTypes[key].provider_type_id});
                },temp);
                var lenProviders = removedDropDownObject.length;
                var tempObj =[];
                $scope.appointmentData.insurance_plan_id = $scope.saveInsurance_plan_id;
                if($scope.appointmentData.provider_id.indexOf(selectedProviderIndex[index-1]) == -1){
                    $scope.appointmentData.provider_id.push(selectedProviderIndex[index-1]);          
                }
                Scopes.store('multiproviderCalandarData',temp);
                Scopes.store('appointmentData',$scope.appointmentData);
                onEventSelected();
                loadingFactory.hide();
                // $state.go("mainView.conCalendar",{type:"M"}).then(function(){
                //     
                // });
            }else{
                toastMsg.show('You have choosen only one provider. For Multi-provider consult, at least two providers are necessary');
                loadingFactory.hide();
            }

        }else{
            loadingFactory.hide();
            if(new Date($scope.appointmentData.consultation_start_date + ' '+ $scope.appointmentData.consultation_start_time) <= new Date() ){
                toastMsg.show("Your Selected time has been expire ,please select new time to proceed");
            }else{
                toastMsg.show("No Provider is selected");
            }

        }

    }
    function onEventSelected () {      
        showModalService.show($scope,'modules/consumer/scheduleAppointment/template/detailsModal.html','appointment');
    };

    $scope.confirmStatus =function(value){
        replace(value);
    }

    $scope.nextAndContinue = function(type){
        switch(type){
            case 'Next':
                if(!angular.equals($scope.listProviders, {})){
                    if(selectedProviderIndex[index-1]){
                        searchProviders();
                    }else{
                        toastMsg.show("Please select Provider");
                    }
                }else{
                    searchProviders();
                }
                break;
            case 'Schedule':
                loadingFactory.show(true);
                schedule();
        }
    }

    $scope.searchWithInsurance = function(){
        index = index -1;
        delete selectedProviderIndex[index];
        searchProviders();
    }

    $scope.addToFavorite = function(id,index){
        if(!$scope.listProviders[index].is_favourite){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addToFavorite,'POST',{"provider_id":id,"status":"Active"},commonGetterService.getToken());
            promise.then(function(res){
                if(res.status){
                    loadingFactory.hide();
                    $scope.listProviders[index].is_favourite = true;
                }

            })
        }
    }

    var moreInfo = function(index){
        $scope.buttonTitle = $scope.listProviders[index].selected?'Selected':'Select';
        $scope.infoIndex = index;
        $scope.providerDetails = $scope.listProviders[index];
        $scope.title = "Provider Description";
        $scope.templateUrl = 'modules/consumer/scheduleAppointment/template/moreInfo.html';
        showModalService.show($scope,'modules/consumer/scheduleAppointment/template/detailsModalOnDemand.html');
    }

    $scope.functionCall = function(type,params){
        switch(type){
            case 'hideModal':
                showModalService.hide(true);
                $scope.infoIndex ='';
            break;
            case 'moreInfo':
                moreInfo(params);
            break;
            case 'selectAndSchedule':
                if(!$scope.listProviders[$scope.infoIndex].selected){
                    $scope.selectProvider($scope.infoIndex);
                }
            break;

        }
    }




    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      //showModalService.destroy();
    });

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(true);
      data.enableBack = true;
      $rootScope.showMenu = false;
    });  

});
