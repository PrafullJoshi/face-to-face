face2face.controller('conScheduledCtrl',function($scope,requiredFactory,serverRequestFactory,globalConstants,$timeout,getPatientsService,convertDate,$window,$state,otherValidationCheck,validateDate,$rootScope,$stateParams,commonGetterService,showModalService,$ionicNavBarDelegate,loadingFactory,toastMsg,Scopes,$ionicHistory,$compile,$parse){        
    $scope.templateUrl = "modules/consumer/scheduledAppointment/template/scheduleTemplate.html";
    $rootScope.mTemplate = "modules/main/mainView/template/menu.html";

    // get patient providertype & state
    getPatientsService.getPatientsforConsumer($scope,'',commonGetterService.getToken());
    commonGetterService.getProviderType($scope,commonGetterService.getToken());
    commonGetterService.getStates($scope);
    $scope.templateUrl = '';
    var tempObjforCal = {};
    var type ,flag = 0;
    $scope.statesData =[];
    $scope.askAnExpert = false;
    $scope.age = '';
    var allTitle ={} // title with key name to send it to api
    init();
    function init(){
        /*
        * init variable
        */
        $scope.appointmentData = {
                "video_call":"",
                "phone_call":"",
                "multi_video_consult":"",
                "concierge_service" : "",
                "inquiry": "",
                "inquiry_type":"",
                "consult_medium" : "Video",
                "insurance_plan_id" : "",
                "zip_code":'',
                "state_id":''
        };
        $scope.exAdd = {
            new:{},
            address:''
        };
        $scope.inquiryType = '';
        
        /*
        * Title switch function @ start
        */
        switch($stateParams.type){
            case 'S':
                $scope.viewTitle = 'Schedule';
                $scope.appointmentData.consult_medium = 'Video';
                changeSelection();
            break;
            case 'M':
                $scope.viewTitle = 'Multi-Provider';
                $scope.appointmentData.consult_medium = 'Multi-Provider';
                changeSelection();
            break;
            case 'C':
                $scope.viewTitle = 'Concierge';
                $scope.appointmentData.consult_medium = 'Concierge';
                changeSelection();
            break;
        }
    }



    /*
    * function to get details and address(only in case of Concierge) of patient
    */
    function getDetails(){
        $scope.askAnExpert = false;
        getPatientsService.showAskAnExpertPopup($scope,$scope.appointmentData.patient_id,commonGetterService.getToken());
        // Remove TODO getPatientsService.getPatientDetails($scope,$scope.appointmentData.patient_id,'',commonGetterService.getToken());
        if($stateParams.type == 'C') {
            getAddress();
        }
    }


    /*
    *function to fetch address list when Concierge appointment
    */

    function getAddress() {
        if(angular.isDefined($scope.appointmentData.patient_id)){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getexaddressConcierge+$scope.appointmentData.patient_id, 'GET', {},commonGetterService.getToken());
                promise.then(function(res) {
                    if (res.data.status == true && res.data.data != "None") {           
                        $scope.addressList = res.data.data;
                        loadingFactory.hide();
                    }else{           
                        loadingFactory.hide();
                    }
                }, function(err) {
                        loadingFactory.hide();
                })
        }else{
            toastMsg.show("Please select patient first");
        }
    }

    /*
    * function to open new address modal in case of Concierge appointment
    */

    function addNewAddress(){
        if(angular.isDefined($scope.appointmentData.patient_id)){
            showModalService.show($scope,'modules/consumer/scheduleAppointment/template/addAddress.html');
        }else{
            toastMsg.show("Please select patient first");
        }
    }
    function hideModal(){
        showModalService.hide(true);
        $scope.exAdd.new ={};
    }
    /* 
    *function to add new address
    */

    function addAddressSubmit(form){
        $scope.exAdd.new.patient_id = $scope.appointmentData.patient_id;
        if(requiredFactory.validateBeforeSubmit(form,$scope) && $scope.statesData[$scope.exAdd.new.state_id] == "New York"){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.saveConciergeAdd,'POST',$scope.exAdd.new,commonGetterService.getToken());
            promise.then(function(res) {
                if (res.data.status == true) {
                    getAddress();
                    hideModal();
                    loadingFactory.hide();
                }else {           
                    loadingFactory.hide();
                }
            }, function(err) {
                loadingFactory.hide();
            });
        }

    }

    function checkState(params){
        if($scope.statesData[params.id] != "New York"){
            document.getElementById(params.type).innerHTML = 'Concierge service is only avalibale for New York City';
            $scope.templateUrl = '';
        }else{
            document.getElementById(params.type).innerHTML = '';
            if(params.type == 'conciergeErr'){
                $scope.templateUrl = "modules/consumer/scheduleAppointment/template/concierge.html";
            }
        }
    }

    $scope.getSpecialities = function(id,notreset){
        var age = $scope.age.split(' ')[0]; 
        commonGetterService.getSpecialities($scope,id,commonGetterService.getToken(),'','',notreset,age);
    }

    /* 
    * function to get state by zip code - called on blur
    */
    $scope.getState = function(zip){
        document.getElementById('zipErr').innerHTML = "";
        if(angular.isDefined(zip) && zip!='' && zip.length ==5){
            if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
                cordova.plugins.Keyboard.close();
            }
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStateByZipcode+zip, 'GET', {},commonGetterService.getToken());
            promise.then(function(res) {
                if (res.data.status == true && res.data.data != "None") {
                    loadingFactory.hide();
                    saveZipcodeStateId = res.data.data.id.toString();
                    $scope.appointmentData.state_id = res.data.data.id.toString();
                    getInsurances($scope.appointmentData.state_id);
                    changeSelection();
                } else {
                    document.getElementById('zipErr').innerHTML = res.data.message;
                    loadingFactory.hide();
                }
            }, function(err) {
                    loadingFactory.hide();
            });
        }else{
            if(angular.isDefined(zip) && zip.length>=1 && zip.length <5){
                document.getElementById('zipErr').innerHTML = "Zip Code should be 5 digits";
            }
        }

    };

    /*
    * function to get enqiry type
    */

    $scope.getInqType = function(newExist){
        $scope.appointmentData.inquiry_type = "";        
        $scope.typeList = [];
        commonGetterService.getInqType($scope,newExist,commonGetterService.getToken());
    }
    //$scope.getInqType();
    /* 
    * get inquiry 
    */
    // $scope.getInq = function(id,typ){
    //     $scope.appointmentData.inquiry = "";
    //     if(id){
    //         commonGetterService.getInq($scope,JSON.parse(id).id,commonGetterService.getToken());
    //     } else{
    //         $scope.inqList = [];
    //     }    
    // }


    function getInsurances(stateId){
        document.getElementById('zipErr').innerHTML ='';
        if(saveZipcodeStateId == stateId){
            $scope.appointmentData.insurance_plan_id = "";
            commonGetterService.getInsurancesPlanByStateId($scope,stateId,commonGetterService.getToken());
            if($scope.appointmentData.consult_medium == 'Concierge'){
                checkState({id:$scope.appointmentData.state_id,type:'conciergeErr'});
            }
        }else{
            document.getElementById('zipErr').innerHTML  = "This Zip code does not belong to the selected State"
        }
    }

    function changeSelection(){
        $scope.disableCheck = true;
        document.getElementById('conciergeErr').innerHTML = '';
        $scope.templateUrl = '';
        if($scope.appointmentData.consult_medium == 'Phone'){       
            $scope.appointmentData.phone_call = 'Y';
            $scope.appointmentData.concierge_service = '';
            $scope.appointmentData.multi_video_consult = '';
            $scope.appointmentData.video_call = '';
            $scope.addClass = 'VMC';
            $scope.viewTitle = 'Schedule';
            type = 'S';
        }else if($scope.appointmentData.consult_medium == 'Video'){
            $scope.appointmentData.video_call = 'Y';
            $scope.appointmentData.multi_video_consult = 'Y';
            $scope.appointmentData.concierge_service = '';
            $scope.appointmentData.phone_call = '';
            $scope.addClass = 'PC';
            $scope.viewTitle = 'Schedule';
            type = 'S';
        }else if($scope.appointmentData.consult_medium == 'Multi-Provider'){
            $scope.appointmentData.multi_video_consult = 'Y';
            $scope.appointmentData.phone_call = 'Y';
            $scope.appointmentData.video_call = 'Y';
            $scope.appointmentData.concierge_service = '';
            $scope.addClass = 'C';
            $scope.viewTitle = 'Multi-Provider';
            type = 'M';
        }else if($scope.appointmentData.consult_medium == 'Concierge'){
            checkState({id:$scope.appointmentData.state_id,type:'conciergeErr'});
            $scope.appointmentData.concierge_service = 'Y';
            $scope.appointmentData.multi_video_consult = '';
            $scope.appointmentData.phone_call = '';
            $scope.appointmentData.video_call = '';
            $scope.addClass = 'PVM';
            $scope.viewTitle = 'Concierge';
            type = 'C';
            if(!$scope.addressList){
                getAddress();
            }
        }
    }

    function continueSubmit(form){
        
        document.getElementById('zipErr')?document.getElementById('zipErr').innerHTML ='':'';
        //alert(JSON.stringify(form));
        if(requiredFactory.validateBeforeSubmit(form,$scope) && otherValidationCheck.validateBeforeSubmit(form)){
            if($scope.appointmentData.zip_code){
                var promiseRes = serverRequestFactory.serverComm(globalConstants.serviceUrl.validateZipcodeByState, 'POST',
                    {
                        "state_id": $scope.appointmentData.state_id,
                        "zip_code": $scope.appointmentData.zip_code
                    },commonGetterService.getToken());
                    promiseRes.then(function(res) {
                    if (res.data.status == true) {
                        loadingFactory.hide();
                        goToNext($scope.appointmentData);
                    }else {
                        document.getElementById('zipErr')?document.getElementById('zipErr').innerHTML = 'Entered zip is not belongs to selected state':'';
                        loadingFactory.hide();
                    }
                    }, function(err) {
                        loadingFactory.hide();
                    });
            }else{
                goToNext($scope.appointmentData);
            }
                   
        }else{
            $scope.$broadcast('myEvent');
        }

    }

    function changeAdd(address){
        address = JSON.parse(address)
        if(address.hasOwnProperty('zip_code')){
            tempObjforCal.concierge_address_name = address.address_name;
            tempObjforCal.concierge_address1 = address.address1;
            tempObjforCal.concierge_address2 = address.address2;
            tempObjforCal.concierge_zip_code = address.zip_code;
            tempObjforCal.concierge_state_id = address.state_id;
            tempObjforCal.concierge_city = address.city;
            tempObjforCal.stateName = $scope.statesData[address.state_id];
        }
        else{
            tempObjforCal.concierge_address_name = address.address_name;
            tempObjforCal.concierge_address1 = address.address1;  
        }
    }

    function goToNext(data){
        Scopes.store('appointmentData',data);
        if($scope.appointmentData.consult_medium == 'Concierge'){
            Scopes.store('addressOnCon',tempObjforCal)
        }
        $state.go('mainView.pickTimeAppointment',{type:type});
    }

    function goBack(){
        //close();
        if($rootScope.previousScreen.name == 'mainView.consumerConsultRoom' || $rootScope.previousScreen.name.split("_")[0] == 'mainView.addPatient'){
            $state.go('mainView.inbox');
        }else{
            $ionicHistory.goBack();
        }
    }
    function saveState(){
        Scopes.store('saveState',type);
        $state.go('mainView.addPatient_1');
    }

    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall = function(functionName,params){
      switch(functionName){
        case 'getDetails':
            getDetails(params);
            break;
        case 'addNewAddress':
            addNewAddress();
            break;
        case 'hideModal':
            hideModal();
            break;
        case 'addAddressSubmit':
            addAddressSubmit(params);
            break;
        case 'checkState':
            checkState(params);
            break;
        case 'changeSelection':
            changeSelection();
            break;
        case 'getInsurances':
            getInsurances();
            break;
        case 'continueSubmit':
            continueSubmit(params);
        break;
        case 'goBack':
            goBack();
        break;
        case 'changeAdd':
            changeAdd(params);
        break;
        case 'saveState':
            saveState();

      }
    }


        /* *****  screening forms  ****** */

        $scope.getProviderInquiry = function(provider_spec_id,newExist){
            if(!$scope.askAnExpert){
                $scope.appointmentData.inquiry_type = " ";        
                $scope.typeList = [];
                if(provider_spec_id){
                    $scope.proSpecId = provider_spec_id;    
                }
                commonGetterService.getProviderInquiry($scope,$scope.proSpecId,newExist,'');
            }
         
        }

        $scope.getScreeningForms = function(inquiry_type){
            $scope.appointmentData.patient_screening_detail_id = "";
            if($scope.patientDetails.fname+' '+$scope.patientDetails.lname!="No Patient"){
                inquiry_type =  JSON.parse(inquiry_type);
                if(inquiry_type.name != 'Others'){
                    $scope.otherInquiry = false;
                    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getScreeningFormFromInquiry+inquiry_type.id,'GET',{},token);
                    promise.then(function(res) {
                    if (res.data.status == true && res.data.data !== "None") {
                         var obj = JSON.parse(res.data.data[0].form.form_structure);
                         commonGetterService.getExistingInquiryForms($scope,$scope.appointmentData.patient_id,inquiry_type.id,token);
                         showModalService.show($scope,'modules/consumer/scheduleAppointment/template/screeningForm.html');
                         $scope.appointmentData.patient_screening_detail = '';
                         $scope.screeningFormName = "";
                         $scope.headerText = res.data.data[0].form.form_name;
                         $timeout(function(){
                            $scope.createFormElements(obj[0],res.data.data[0].form_id);
                         },100);     
                         loadingFactory.hide();

                     } else if (res.status == false || res.data.data == "None") {
                         loadingFactory.hide();
                     }

                 }, function(err) {

                 })   
                }else{
                    $scope.otherInquiry = true;
                }
            }

        }
    $scope.setFormScope= function(scope){      
        $scope.formScope = scope;
    }
      $scope.createFormElements = function(obj,formID){
     
       $scope.obj = obj;
       $scope.formObj = {};
       $scope.fileObject = {};
       $scope.fileObj = {};
       $scope.err = {};
       var str,model;
       var element = angular.element(document.getElementById('addscreen'))
       $scope.newlabel = '';
       element.html($scope.newlabel);
       $compile(element.contents())($scope);
       $scope.lbl = [];
       for(var i = 0;i<$scope.obj.length;i++){
            allTitle[$scope.obj[i].name] = $scope.obj[i].title;
            if(obj[i].ftype == 'ftext'){
               //$scope.formObj[obj[i].name]
               $scope.limit = (obj[i].maxlength)?obj[i].maxlength:128;
               
               if($scope.obj[i].required){
                 flag++;  
                 $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><input type="text" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}" limit-to="'+$scope.limit+'" msg="Please enter a valid {{obj['+i+'].title}}" name="'+$scope.obj[i].name+'" is-required formelemname="'+$scope.obj[i].name+'" messageid = "'+$scope.obj[i].name+'" ng-model="formObj[obj['+i+'].name]"/><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].name+'"></span></div></label>');
               }
               else{
                $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><input type="text" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}"  msg="Please enter a valid {{obj['+i+'].title}}" limit-to="obj['+i+'].maxlength" name="obj['+i+'].name" messageid = "'+$scope.obj[i].name+'" ng-model="formObj[obj['+i+'].name]"/><div class="error-message"><span id="'+$scope.obj[i].name+'"></span></div></label>');
               
               }
             /* $scope.formObj[$scope.obj[i].name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
              str = 'formObj.'+ obj[i].name;
              model = $parse(str);
              model.assign($scope,(obj[i].value)?(obj[i].value):'');*/
           }
           else if($scope.obj[i].ftype == 'ftextarea'){    
               $scope.limitta = (obj[i].maxlength)?obj[i].maxlength:500;
               if($scope.obj[i].required){
                   flag++; 
                   $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><textarea rows="6" ng-model="formObj[obj['+i+'].name]" class="" is-required name="'+$scope.obj[i].name+'" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}" limit-to="'+$scope.limitta+'" formelemname="'+$scope.obj[i].name+'" msg="Please enter a valid {{obj['+i+'].title}}" messageid = "'+$scope.obj[i].name+'"/><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].name+'"></span></div></label>');
               }
               else{
               $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><textarea rows="6" ng-model="formObj[obj['+i+'].name]" class="" name="'+$scope.obj[i].name+'" max-min minl="{{obj['+i+'].minlength}}" maxl="{{obj['+i+'].maxlength}}" msg="Please enter a valid {{obj['+i+'].title}}" limit-to="'+$scope.limitta+'" messageid = "'+$scope.obj[i].name+'"/><div class="error-message"><span id="'+$scope.obj[i].name+'"></span></div></label>');

               }
              /* $scope.formObj[$scope.obj[i].name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
               str = 'formObj.'+ obj[i].name;
               model = $parse(str);
               model.assign($scope,(obj[i].value)?(obj[i].value):'');*/ 
           }
         else if($scope.obj[i].ftype == 'fdropdown'){          

               if($scope.obj[i].required){
                   flag++; 
                   $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><select is-required name="'+$scope.obj[i].name+'" formelemname="'+$scope.obj[i].name+'" messageid = "'+$scope.obj[i].name+'" ng-model="formObj[obj['+i+'].name]" class=""><option value="">-- select --</option><option ng-repeat="sel in obj['+i+'].choicesVal track by $index" value="{{sel}}">{{sel}}</option></select><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].name+'"></span></div></label>');
               }
               else{
                   $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><select name="'+$scope.obj[i].name+'" messageid = "'+$scope.obj[i].name+'" ng-model="formObj[obj['+i+'].name]" class=""><option value="">-- select --</option><option value="{{sel}}" ng-repeat="sel in obj['+i+'].choicesVal track by $index">{{sel}}</option></select><div class="error-message"><span id="'+$scope.obj[i].name+'"></span></div></label>');
               
               }
               $scope.formObj[$scope.obj[i].name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
               
           }
             else if($scope.obj[i].ftype == 'fdate'){
               $scope.lbl[i] = obj[i].title;
               if($scope.obj[i].required){
               flag++; 
               $scope.newlabelw = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><div class="custom-inputs"><ul class="two-cols" ng-click="functionCall(\'showDateTimePicker\',\'start\')"><li>Select Date</li><li class="text-green semibold"><ul><li>{{formObj[obj['+i+'].name]}}</li></ul></li></ul></div></label>');
             //  $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><div start-view="month" class="input-group calender_ui" moment-picker="formObj[obj['+i+'].name]" format="L"><input class="" is-required formelemname="'+$scope.obj[i].name+'" ng-change="chaValue(obj['+i+'].name)" name="'+$scope.obj[i].name+'" messageid = "'+$scope.obj[i].name+'" validate-date dateerrmsg = "err.'+$scope.obj[i].name+'" ng-model="formObj[obj['+i+'].name]" ng-model-options="{ updateOn: \'blur\'}" /><span class="input-group-addon"><i class="fa fa-calendar"></i></span></div><span class="mandatory">*</span><div class="error-message"><span id="'+$scope.obj[i].name+'"></span><span ng-bind="err[obj['+i+'].name]"></span></div></label>');
           }
           else{
            $scope.newlabelw = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><div class="custom-inputs"><ul class="two-cols" ng-click="functionCall(\'showDateTimePicker\',\'start\')"><li>Starts</li><li class="text-green semibold"><ul><li>{{formObj[obj['+i+'].name]}}</li></ul></li></ul></div></label>');
            
           //  $scope.newlabel = angular.element('<label><span class="input-label" ng-bind-html="obj['+i+'].title"></span><div start-view="month" class="input-group calender_ui" moment-picker="formObj[obj['+i+'].name]" format="L"><input formelemname="'+$scope.obj[i].name+'" ng-change="chaValue(obj['+i+'].name)" class="" name="'+$scope.obj[i].name+'" messageid = "'+$scope.obj[i].name+'" validate-date dateerrmsg = "err.'+$scope.obj[i].name+'" ng-model="formObj[obj['+i+'].name]" ng-model-options="{ updateOn: \'blur\'}" /><span class="input-group-addon"><i class="fa fa-calendar"></i></span></div><div class="error-message"><span id="'+$scope.obj[i].name+'"></span><span ng-bind="err[obj['+i+'].name]"></span></div></label>');  
              
           }
           $scope.formObj[$scope.obj[i].name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
           } 
           else if($scope.obj[i].ftype == 'fradio'){
               $scope.newlabel = angular.element('<div class="round-radio"><span class="input-label" ng-bind-html="obj['+i+'].title"></span><label ng-repeat="li in obj['+i+'].choicesVal track by $index"><input name="'+$scope.obj[i].name+'" ng-model="formObj[obj['+i+'].name]" type="radio" value="{{li}}">{{li}}<i></i></label></div>');  
               $scope.formObj[$scope.obj[i].name] = ($scope.obj[i].value)?($scope.obj[i].value):'';
               if($scope.obj[i].choiceSelected){
               $scope.formObj[$scope.obj[i].name]= $scope.obj[i].choiceSelected;
               }
           }
           else if($scope.obj[i].ftype == 'fcheck'){   
               $scope.arr = '';
                str = 'formObj["'+ $scope.obj[i]["name"]+'"]';
                model = $parse(str);
                model.assign($scope, []); 

               $scope.getlistForChk = function(obj){
                   var listchk = [];
                   for(var j=0;j<optionslength;j++){

                       listchk.push($scope.checkedVal[j]);
                   }
                   return listchk;
               } 
              


               //$scope.cusName = obj[i].name;
           //    console.log(JSON.stringify(obj[i].choicesVal)+"++++++++++++++++++")
               $scope.newlabel = angular.element('<div class="custom-checkbox"><span class="input-label" ng-bind-html="obj['+i+'].title"></span><ul><li ng-repeat="li in obj['+i+'].choicesVal track by $index"><label><input name="obj['+i+'][\'name\']" type="checkbox" ng-checked="getCheckedValue(li,obj['+i+'][\'name\'],$index)" value={{li}} ng-click="sync(arr,li,obj['+i+'][\'name\'])" ng-model="arr">{{li}}<i></i></label></li></ul></div>');                  
                  
                  var cusName = obj[i]["name"];

                  if($scope.obj[i].value){
                   var tempArr = $scope.obj[i].value;
                   $scope.formObj[cusName] = $scope.obj[i].value;
                  }
                  $scope.getCheckedValue = function(val,ob,index){
                     //$scope.formObj[ob] = [];
                     if($scope.formObj[ob]){
                       for(var v=0;v < $scope.formObj[ob].length;v++){
                           if($scope.formObj[ob][v] == val){
                               
                               return true;
                           }

                       }
                     }  
                    
                     return false;
                  }
           }
           else if($scope.obj[i].ftype == 'ffile'){
                var stringToadd = '_fileobject'; 
               if($scope.obj[i].required){
                   flag++; 
                   $scope.newlabel = angular.element('<div class="upload-doc"><span class="input-label">Upload Document</span><ul><li><input  class="" type="text" is-required formelemname="'+$scope.obj[i].name+'" messageid="'+$scope.obj[i].name+'" name="'+$scope.obj[i].name+'" ng-model="fObj[obj['+i+'].name'+stringToadd+']"><div class="error-message"><span id="'+$scope.obj[i].name+'" ng-bind="err[obj['+i+'].name]"></span></div></li><li><input modelobj = "'+$scope.obj[i].name+'" upload-file="fileObject.'+$scope.obj[i].name+'" class="upload" type="file"><i>Browse</i></li></ul></div>');
               }
               else{
                   $scope.newlabel = angular.element('<div class="upload-doc"><span class="input-label">Upload Document</span><ul><li><input  class="" type="text" formelemname="'+$scope.obj[i].name+'" messageid="'+$scope.obj[i].name+'" name="'+$scope.obj[i].name+'" ng-model="fObj[obj['+i+'].name'+stringToadd+']"><div class="error-message"><span id="'+$scope.obj[i].name+'" ng-bind="err[obj['+i+'].name]"></span></div></li><li><input modelobj = "'+$scope.obj[i].name+'" upload-file="fileObject.'+$scope.obj[i].name+'" class="upload" type="file"><i>Browse</i></li></ul></div>');
               }
              //  $scope.fObj[$scope.obj[i].origional_name] = ($scope.obj[i].value)?($scope.obj[i].value):'';

               
           }

           element.append($scope.newlabel);
           $compile($scope.newlabel)($scope);
           $scope.lbl = [];
       }
      /* if(id){*/
           $scope.newlabel = angular.element('<div class="button-group mt-20"><a class="button-grey" ng-click="closeModal()">Cancel</a><a class="button-yellow" ng-click="saveForm('+formID+')">Continue</a></div>');
     /*  }
       else{
           $scope.newlabel = angular.element('<div class="col-sm-11 mt-20"><button type="button" class="btn btn-warning text-capitalize" ng-click="saveAddEditMedicalProblems(formObj,addPrblm)">Submit</button><button type="button" class="btn btn-grey text-capitalize" data-dismiss="modal">Cancel</button></div>');
       }
       */
    
       element.append($scope.newlabel);
       $compile($scope.newlabel)($scope);

    }
        $scope.saveForm = function(formID){
            
            if (requiredFactory.validateBeforeSubmit($scope.formScope['addPrblm'], $scope) || !flag) {
                 //   alert("sdfsdf")
                $scope.formObj['all_titles'] = allTitle;
                var inquiryId = (JSON.parse($scope.appointmentData.inquiry_type)).id; 
                var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addScreeningDetails,'POST',{"patient_id":$scope.appointmentData.patient_id,
                "inquiry_id":inquiryId,
                "form_id":formID,
                "form_data":$scope.formObj},token);
                    promise.then(function(res) {
                        if (res.data.status == true) {
                            $scope.formObj = {};
                            $scope.appointmentData.patient_screening_detail_id = res.data.data.id;
                            $scope.screeningFormName = res.data.data.name;
                            showModalService.hide(true);
                            loadingFactory.hide();
                        } else if (res.status == false) {
                            loadingFactory.hide();
                        }

                    }, function(err) {

                    })
            }
        }

        $scope.sync = function(bool,item,propName){
          if(bool){
            // add item
           //$scope.formObj[propName]=temarr; 
           $scope.formObj[propName].push(item);
          } else {
            // remove item
            for(var i=0 ; i < $scope.formObj[propName].length; i++) {
              if($scope.formObj[propName][i] == item){
                $scope.formObj[propName].splice(i,1);
              }
            }      
          }
          
        };
        $scope.chaValue = function(property){
           //$scope.err[property] = '';
            delete $scope.err[property];
        }

        $scope.uploadDocFile = function(file,ty,form,modelName){
            $scope.contractErr = "";
            if(!modelName){
                $scope.docErr = '';
                var validFormats = 'pdf';
                var size = file.size/1000000 ; // file size in mB
                var ext = (file.name).substring(file.name.lastIndexOf('.') + 1).toLowerCase();
                if(validFormats.indexOf(ext) === -1 || size > 3) {
                                if (size > 3) {
                                    $scope.docErr = "File size can not exceed 3 mB";
                                } else {
                                    $scope.docErr = "File format should be only pdf";
                                }
              }else{
                        var fileReader = new FileReader();
                        fileReader.readAsDataURL(file);
                        fileReader.onload = function(e) {
                            file.dataUrl = e.target.result;   /*add dataUrl to file properties*/
                            $scope.uploadDoc.doc = file.dataUrl;
                            angular.element(document.querySelector("#uploaddoc")).val(null);
                            uploaddoc();
                        }
              }
                       
            }
            else{
                delete $scope.err[modelName];
                var validFormats = ['jpg', 'img', 'jpeg', 'png', 'bmp','pdf'];
                var size = file.size/1000000 ; // file size in mB
                var ext = (file.name).substring(file.name.lastIndexOf('.') + 1).toLowerCase();
                if(validFormats.indexOf(ext) === -1 || size > 3) {
                                if (size > 3) {
                                    $scope.err[modelName] = "File size can not exceed 3 mB";
                                } else {
                                    $scope.err[modelName] = "File format should be either jpeg, jpg, img, bmp, png, pdf";
                                }
              }
              else{
                    var fileReader = new FileReader();
                    fileReader.readAsDataURL(file);
                    fileReader.onload = function(e) {
                        $scope.fObj[modelName] = file.name;
                        file.dataUrl = e.target.result;   /*add dataUrl to file properties*/
                        //console.log("file.dataUrl :",file.dataUrl);
                        $scope.formObj[modelName] = file.dataUrl;
                    
                    }
              }
                
            }
            
        }
        //close add card function
        $scope.closeModal = function(check){ //check if we want to only close or reset form
            showModalService.hide(true);
            if(!check){
              $scope.appointmentData.inquiry_type = "";
            }var screeningFormObj =''
            if($scope.appointmentData.patient_screening_detail){
                screeningFormObj = JSON.parse($scope.appointmentData.patient_screening_detail);
                $scope.appointmentData.patient_screening_detail_id = screeningFormObj.id;
                $scope.screeningFormName = screeningFormObj.formName;
            }
            
            Scopes.delete('formInfo');
        }

        /**** for select medical records *****/
        $scope.openModalformedicalRecord = function () {
            var data = {
                            /* for scheduled appoitment*/ 
                            speciality_id:[$scope.appointmentData.speciality_id],
                            provider_type_id:[$scope.appointmentData.provider_type_id],
                            //provider_group_id:$scope.appointmentData.provider_group_id,
                            consultation_type:"schedule"
                        }
            commonGetterService.getMedicalRecordCategory(data,token,$scope);

        }
        $scope.shareMedicalRecords = function(selectAll){
            commonGetterService.saveMedicalRecords($scope.medicalRecordCategory,selectAll);
        }
        $scope.selectAllRecords = function(selectAll){
            if(!selectAll){
                angular.forEach($scope.medicalRecordCategory,function(value,key){
                    $scope.medicalRecordCategory[key].share = 'No';
                })
            }
        }

        $scope.hideModalShare = function(selectAll){
          showModalService.hide(true);
        }
        /**
         * function for receive confirmation on ask an expert
         */
        $scope.confirmStatus = function(patientId,status) {
            if($scope.ageWarning){
                status ? $scope.appointmentData.speciality_id = '' : $scope.getProviderInquiry($scope.appointmentData.speciality_id,$scope.inquiryType);
            }else{
                status ? $scope.appointmentData.patient_id = '' : getPatientsService.getPatientDetails($scope,$scope.appointmentData.patient_id,'',commonGetterService.getToken());
            }
                
        }
        /**
         * function to show popup on selection of provider group
         */

        $scope.showAgeWarning = function(speciality_id ,inquiry) {
            var status = $scope.specialitiesData[speciality_id].age_group_status;
            $scope.titleSpeciality = $scope.specialitiesData[speciality_id].title;
            $scope.ageWarning = true; 
            getPatientsService.showAgeWarning($scope,speciality_id,inquiry,status);
        }
        /**
         * show popover for speciality description
         */
        $scope.showPopover = function(e) {
            var description = $scope.specialitiesData[$scope.appointmentData.speciality_id].description;
            var title = $scope.specialitiesData[$scope.appointmentData.speciality_id].title;
            commonGetterService.showSpecialityDescription(description,title,$scope,e);
        }

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      showModalService.destroy();
      if($scope.popover){
        $scope.popover.remove();
      }
    });

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(false);
      data.enableBack = false;
      $rootScope.showMenu = true;
      if($stateParams.location == 'VH'){
        init();
      }
    }); 

    $scope.$on('$ionicView.enter', function (e, data) {
      
        if($ionicHistory.forwardView()){
            if($ionicHistory.forwardView().stateName != 'mainView.pickTimeAppointment'){
               init();
            }
        }

    });

    $scope.triggerSubmit = function() {
    }; 

    });

