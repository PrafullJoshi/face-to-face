face2face.controller('shareMedicalRecordCtrl',function($scope,commonGetterService){        
	/**** for select medical records *****/

$scope.shareMedicalRecords = function(selectAll){
    commonGetterService.saveMedicalRecords($scope.medicalRecordCategory,selectAll);
}
$scope.selectAllRecords = function(selectAll){
    if(!selectAll){
        angular.forEach($scope.medicalRecordCategory,function(value,key){
            $scope.medicalRecordCategory[key].share = 'No';
        })
    }
}
})