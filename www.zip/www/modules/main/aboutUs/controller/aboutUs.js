
face2face.controller("aboutusCtrl",function($scope,globalConstants,serverRequestFactory,loadingFactory,$rootScope,$ionicNavBarDelegate) {
 
    var promise;
    promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getAboutUs,'GET',{}); // call the login api 
    promise.then(function(res){
      if(res.data.status == true && res.data.data != "None"){
        $scope.aboutUsData = res.data.data;
   
        if(!!$scope.aboutUsData.page.image && !!$scope.aboutUsData.page.video_link){
          $scope.imageShow = true;
          $scope.playShow  = true;
        }else if(!!$scope.aboutUsData.page.image && ($scope.aboutUsData.page.video_link == "" || $scope.aboutUsData.page.video_link == null || $scope.aboutUsData.page.video_link == undefined)){
          $scope.imageShow = true;
          $scope.playShow  = false;
        }
        else if(!!$scope.aboutUsData.page.video_link && ($scope.aboutUsData.page.image == "" || $scope.aboutUsData.page.image == null || $scope.aboutUsData.page.image == undefined)){
          $scope.imageShow = false;
          $scope.playShow  = false;
          $scope.link = $scope.aboutUsData.page.video_link;
        }
        loadingFactory.hide();
      }
      else {
        loadingFactory.hide();
      }
    },function(err){
      loadingFactory.hide();
    });

  $scope.playVideo = function(){
    $scope.imageShow = false;
    $scope.link = $scope.aboutUsData.page.video_link+'?autoplay=1';
  }

  $scope.$on('$ionicView.beforeEnter', function (e, data) {
     $rootScope.menuSelected = " ";  
     $ionicNavBarDelegate.showBackButton(false);
     data.enableBack = false;
     $rootScope.showMenu = true;
  });



});

