face2face.controller('appSettingCtrl',function($scope,requiredFactory,serverRequestFactory,globalConstants,$timeout,getPatientsService,convertDate,$window,$state,otherValidationCheck,validateDate,$rootScope,$stateParams,commonGetterService,showModalService,$ionicNavBarDelegate,loadingFactory,toastMsg,Scopes,$ionicHistory,showPopup){        
    
    var token = commonGetterService.getToken();
    $scope.userType = commonGetterService.getUsertype();

    /**
      * Get Provider & consumer App Settings Details like availability and notifiction from the server. 
      * @type @exp;serverRequestFactory@call serverComm with url ;
    */
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getNotificationSetting,"GET","",token);
    promise.then(function(response){
        if(response.data.status == true && response.data.data!='None'){
            loadingFactory.hide();
            $scope.setting = response.data.data;
            if($scope.userType == 1){
                $scope.disableNEnableCheckbox();
            }
        }else{
            loadingFactory.hide();
        }

    })


    /*
    * Function to disable & enable checkboxes on when click on Availability 
    */

    $scope.disableNEnableCheckbox = function(){
        if($scope.setting.provider_setting.is_temporary_unavailable == 'Y'){
            $scope.otherCheckBoxDisable = true;
            $scope.setting.provider_setting.on_demand_appointment = 'N';
            $scope.setting.provider_setting.multiprovider_scheduled_appointment = 'N';
            $scope.setting.provider_setting.concierge_service = 'N';
        }else{
            $scope.setting.provider_setting.is_temporary_unavailable =='N'
            $scope.otherCheckBoxDisable = false;
        }
    };

    $scope.submitNotificationSetting = function(){
        /**
        * Post Provider Account Settings Details like charges per hour and availability to the server. 
        * @type @exp;serverRequestFactory@call serverComm with url ;
        */
        if($scope.userType == 2){
            delete $scope.setting.provider_setting;
        }
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.notificationSetting,"POST",$scope.setting,token);
        promise.then(function(response){
            if(response.data.status){
                loadingFactory.hide();
                toastMsg.show('Setting has been updated');
            }else{
                toastMsg.show('Oops! some error occured. Please try again later');
                loadingFactory.hide();
            }
        });

    }
 

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      //showModalService.destroy();
    });

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(false);
      data.enableBack = false;
      $rootScope.showMenu = true;
    });  

});
