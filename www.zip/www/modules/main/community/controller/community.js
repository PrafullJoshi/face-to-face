/**
@controller for community
@Description - list the 

**/

face2face.controller('communityForumsCtrl',function($scope,globalConstants,serverRequestFactory,requiredFactory,otherValidationCheck,commonGetterService,toastMsg,loadingFactory,$state,$ionicNavBarDelegate,$rootScope){
  	
  	$rootScope.menuSelected = "Community";
  	/*
	* Get list of community Forums
  	*/
  	var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getListOfCommunity, 'GET', {},getToken());
  	promise.then(function(res){
  		if(res.data.status && res.data.data!="None"){
  			$scope.communityList = res.data.data;
  			loadingFactory.hide();
  		}else{
        $scope.communityList =[];
  			loadingFactory.hide();
  		}
  	},function(e){
      $scope.communityList = [];
  		loadingFactory.hide();
  	})

  	/*
  	* function to get token from localStorage to send service
  	*/
  	function getToken(){
  		if(localStorage.userData){
    		return JSON.parse(localStorage.userData).token;
    	}
  	}

  $scope.$on('$ionicView.beforeEnter', function (e, data) {
    if($rootScope.previousScreen.name == 'mainView.conDashboard' || $rootScope.previousScreen.name == 'mainView.proDashboard'){
      enableBack = true;
    }else{
      enableBack = false;
    }
    $ionicNavBarDelegate.showBackButton(enableBack);
    data.enableBack = enableBack;
    $rootScope.showMenu = !enableBack;
  });
});

/**
@controller for community
@Description - list the 

**/

face2face.controller('communityCtrl',function($scope,globalConstants,serverRequestFactory,requiredFactory,otherValidationCheck,commonGetterService,toastMsg,loadingFactory,$state,$ionicNavBarDelegate,$rootScope){
  $scope.$on('$ionicView.beforeEnter', function (e, data) {
    $rootScope.menuSelected = "Community";
    if($rootScope.previousScreen.name == 'mainView.conDashboard' || $rootScope.previousScreen.name == 'mainView.proDashboard'){
      enableBack = true;
    }else{
      enableBack = false;
    }
    $ionicNavBarDelegate.showBackButton(enableBack);
    data.enableBack = enableBack;
    $rootScope.showMenu = !enableBack;
  });
});


