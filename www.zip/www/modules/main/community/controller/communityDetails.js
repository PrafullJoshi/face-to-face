/**
@controller for community
@Description - list the 

**/

face2face.controller('communityForumsDetailsCtrl',function($scope,globalConstants,serverRequestFactory,requiredFactory,otherValidationCheck,commonGetterService,toastMsg,loadingFactory,$state,$rootScope,$stateParams,showModalService,toastMsg,Scopes,$ionicNavBarDelegate){
  	
  	$rootScope.menuSelected = "Community";
    getTopics({'provider_type_id':$stateParams.sId,'sort_by':"Most Recent"});
    $scope.sortBy = 'Most Recent';
    commonGetterService.getAgeGroupDropDown($scope,getToken());
    commonGetterService.getProviderType($scope,getToken());
    $scope.addTopic={'provider_type_id':$stateParams.sId};
    var totalTopics =[];
    var startIndex = 0;
    $scope.loadmore = false;
    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall=function(functionName,params){
      switch(functionName){
        case 'sortTopic':
          sortTopic(params);
          break;
        case 'showModal':
          showModal();
        break;
        case 'hideModal':
          hideModal();
        break;
        case 'addTopicSubmit':
          addTopicSubmit(params);
        break;

      }
    }

  	/*
	  * Get list of community Forums
  	*/
    function getTopics(data){
      var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getCommunitySilosTopic, 'POST', data,getToken());
      promise.then(function(res){
        if(res.data.status && res.data.data!="None"){
          $scope.communitySilos = res.data.data;
          var l = $scope.communitySilos.community_topics.length;
          if(l>5){
            //angular.copy($scope.communitySilos.community_topics, totalTopics);
            //$scope.communitySilos.community_topics.splice(5,totalTopics.length);
            //$scope.loadmore = true;
          }
          loadingFactory.hide();

        }
      }, function(err) {
          loadingFactory.hide();
      });
    }

    /*
    * function to sort topic 
    */
    function sortTopic(type){
      $scope.sortBy = type;
      getTopics({'provider_type_id':$stateParams.sId,'sort_by':type});
    }


    /*
    * function to open modal for add topics 
    */
    function showModal(){
      showModalService.show($scope,'modules/main/community/template/addTopic.html');
    }
    /*
    * function to hide modal for add topics 
    */
    function hideModal(){
      $scope.addTopic={'provider_type_id':$stateParams.sId};
      showModalService.hide(true);
    }
    /*
    * function for adding topic
    */
    function addTopicSubmit(form){
      document.getElementById('terms').innerHTML ='';
      if (requiredFactory.validateBeforeSubmit(form, $scope) && $scope.addTopic.terms) {
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addForum, 'POST', $scope.addTopic,getToken());
          promise.then(function(res) {
              if (res.data.status == true && res.data.data != "None") {
                  loadingFactory.hide();
                  toastMsg.show('New community topic has been added successfully');
                  getTopics({'provider_type_id':$stateParams.sId,'sort_by':$scope.sortBy});
                  hideModal();
              } else {
                  loadingFactory.hide();
                  toastMsg.show(res.data.message);
              }
          }, function(err) {
              loadingFactory.hide();
          });
      }else{
        if(!$scope.addTopic.terms){
          document.getElementById('terms').innerHTML = 'Please Accept terms and conditions'
        }
        
      }
    }
    /**
    * Load more the Topics
    */
    $scope.loadMore = function(){
      if(totalTopics.length>0){
        for(var i=startIndex;i<startIndex+5;i++){
          $scope.communitySilos.community_topics.push(totalTopics[i]);
        }
        startIndex = startIndex+5;
        if($scope.communitySilos.community_topics.length == totalTopics.length){
          $scope.loadmore = false;
        }
        $scope.$broadcast('scroll.infiniteScrollComplete');
      }
    }



  	/*
  	* function to get token from localStorage to send service
  	*/
  	function getToken(){
  		if(localStorage.userData){
    		return JSON.parse(localStorage.userData).token;
    	}
  	}

    // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      showModalService.destroy();
    });

    $scope.$on('$ionicView.enter', function(){
        if(Scopes.get('replied')){
          getTopics({'provider_type_id':$stateParams.sId,'sort_by':$scope.sortBy});
          Scopes.delete('replied');
        }
    })
    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(true);
      data.enableBack = true;
      $rootScope.menuSelected = "Community";
      $rootScope.showMenu = false;
    });
});
