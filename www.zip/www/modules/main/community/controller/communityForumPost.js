

face2face.controller("communityForumsPostCtrl",function($scope, globalConstants,serverRequestFactory, $state, requiredFactory,otherValidationCheck,$stateParams,$window,loadingFactory,showModalService,Scopes,showPopup,toastMsg,$ionicHistory,$ionicNavBarDelegate,$rootScope) {
    $scope.topicData =[];
    $scope.postDescription = "";
    // init();
    var listdataToreply;

    function init(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.viewForum+$stateParams.id, 'GET', {},getToken());
      promise.then(function(res) {
          if (res.data.status == true && res.data.data != "None") {
              loadingFactory.hide();
              $scope.topicData = res.data.data;
              if($scope.topicData.Comments){
                  if($scope.topicData.Comments.length <= 5){
                      $scope.topicData.topicComments = $scope.topicData.Comments;    
                  }else{
                      $scope.seeMore = true;
                      $scope.topicData.topicComments = {};
                      for(var i=1; i<=5; i++){
                          $scope.topicData.topicComments[i] = $scope.topicData.Comments[i];
                      }
                  }
                  
              } 

          } else {
              loadingFactory.hide();
          }
      }, function(err) {
          loadingFactory.hide();
      });
    }

    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall=function(functionName,params){
      switch(functionName){
        case 'reply':
          postreply(params);
          break;
        case 'showModal':
          showModal(params);
        break;
        case 'hideModal':
          hideModal();
        break;
        case 'addPost':
          addPost(params);
        break;
        case 'deleteForum':
          deleteConfirm({id:params,url:globalConstants.serviceUrl.deleteForum,title:'this Community Topic?',msg:'Community Topic'});
        break;
        case 'deleteComment':
          deleteConfirm({id:params,url:globalConstants.serviceUrl.deleteComment,title:'this comment?',msg:'Comment'});
        break;


      }
    }

    /*
    * function to open modal for add topics 
    */
    function showModal(data){
      if(data){
        $scope.replyType = 'reply';
        listdataToreply = data; // save data to send in reply api
      }else{
        $scope.replyType ='addPost';
      }      
      showModalService.show($scope,'modules/main/community/template/addPost.html');
    }

    /*
    * function to hide modal for add topics 
    */
    function hideModal(){
      showModalService.hide(true);
    }

    /*
    * function to add post to a forum
    */

    function addPost(postDescription){
      if(postDescription){
          var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addComment, 'POST', {
              "forum_id": $stateParams.id,
              "description":postDescription
          },getToken());
          promise.then(function(res) {
              if (res.data.status == true && res.data.data == "None") {
                  loadingFactory.hide();
                  $scope.postDescription = "";
                  hideModal();                 
                  init();
                  Scopes.store('replied',true);
              } else {
                  loadingFactory.hide();
              }
          }, function(err) {
              loadingFactory.hide();
          });    
      }
    }

    /*$scope.showMore = function(){
        $scope.seeMore = false;
        $scope.topicData.topicComments = $scope.topicData.Comments;
    }*/

    var postreply = function(postDescription){
        if(!!postDescription){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.commentReply, 'POST', {
                "forum_id": $stateParams.id,
                "parent": listdataToreply.parent  == 0 ? listdataToreply.id : listdataToreply.parent,
                "description": postDescription
            },getToken());
            promise.then(function(res) {
                if (res.data.status == true && res.data.data == "None") {
                    loadingFactory.hide();
                    $scope.postDescription = "";  
                    hideModal();
                    init();
                    Scopes.store('replied',true);
                } else {
                    loadingFactory.hide();
                }
            }, function(err) {
                loadingFactory.hide();
            });
        }
    } 


    function deleteConfirm(comment){
        showPopup.show('Delete','Are you sure you want to delete ' + comment.title,$scope,comment,'Delete');
    }

    $scope.confirmStatus = function(comment){
      deleteComment(comment);
    }

    function deleteComment(comment){
      //globalConstants.serviceUrl.deleteForum
       var promise = serverRequestFactory.serverComm(comment.url+comment.id, 'PUT', {},getToken());
        promise.then(function(res) {
            if (res.data.status == true) {
                loadingFactory.hide();
                toastMsg.show(comment.msg +' has been deleted successfully');
                if(comment.msg == 'Comment'){
                  init();
                }else{
                  $ionicHistory.goBack();
                }                
                Scopes.store('replied',true);
            } else {
                loadingFactory.hide();
                toastMsg.show('Oops! some error occured. Please try again later');
            }
        }, function(err) {
            loadingFactory.hide();
        }); 
    }

    /*
    * function to get token from localStorage to send service
    */
    function getToken(){
      if(localStorage.userData){
        return JSON.parse(localStorage.userData).token;
      }
    }

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      if($state.current.name == data.stateName){
        init();
      }
      $ionicNavBarDelegate.showBackButton(true);
      data.enableBack = true;
      $rootScope.menuSelected = "Community";
      $rootScope.showMenu = false;


    });

});