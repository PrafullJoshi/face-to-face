face2face.controller("webinarDtlsCtrl",function($scope,$window, $state,$stateParams, serverRequestFactory,globalConstants,commonGetterService,loadingFactory,showPopup,showModalService,toastMsg,coupanCodePaymentService,$ionicNavBarDelegate,$rootScope) {
   
   
    $scope.webinartopic = $stateParams.webinartopic;
    $scope.webinarpresenter = $stateParams.webinarpresenter;
    var token = commonGetterService.getToken();
    userType = $window.localStorage['userData'].user_type_id;
    if($stateParams.webinarurl){
        $scope.webinarUrl = $stateParams.webinarurl;
        // window.open($stateParams.webinarurl, '_system');
    }
    $scope.terms = {};
    getWebinarData();

     /*
     * This function is made for prevent extra scope to be generated  
     */
     $scope.functionCall = function(functionName,params){
       
       switch(functionName){
        
         case 'hideModal':
             hideModal();
             break;
         case 'continuePayment':
             continuePayment();
             break;
         
         case 'getWebinarData':
             getWebinarData();
             break;
         case 'addCard':
            addCard();
            break;
        }
     }

   function getWebinarData(){
     var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinarDetails+"?webinar_id="+$stateParams.id,'GET',{},token);
     promise.then(function(res){
       loadingFactory.hide();
     
       if(res.data.status && res.data.data!="None"){

       $scope.webinarDetail = res.data.data;
       if($scope.webinarDetail.webinar_documents.length > 0){
         $scope.fileList = $scope.webinarDetail.webinar_documents;
       }
        // $scope.fileList = res.data.data[0];    
       } else {
         
         loadingFactory.hide();
       }
     },function(err){
       //alert(JSON.stringify(err))
     })
   }


   $scope.downloadFile = function(url,name){
   
    
   if(url){
    if(!ionic.Platform.isIOS()){
        loadingFactory.show();
        var urlArr = url.split('/');

        var fileTransfer = new FileTransfer();

        if (!ionic.Platform.isIOS()){
        //alert(cordova.file.externalRootDirectory)
            window.resolveLocalFileSystemURL(cordova.file.externalRootDirectory, onFileSystemSuccess, onError);
        } else {
            // for iOS
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onFileSystemSuccess, onError);
        }

        function onError(e) {
            navigator.notification.alert("Error : Downloading Failed");
        };

        function onFileSystemSuccess(fileSystem) {
            var entry = "";
            if (!ionic.Platform.isIOS()) {
                entry = fileSystem;
            } else {
                entry = fileSystem.root;
            }
            entry.getDirectory("Face2FaceHealth", {
                create: true,
                exclusive: false
            }, onGetDirectorySuccess, onGetDirectoryFail);
        };

        function onGetDirectorySuccess(dir) {
            cdr = dir;
            dir.getFile("Download/", {
                create: true,
                exclusive: false
            }, gotFileEntry);
        };
        function onGetDirectoryFail(dir){
        
        }
        function gotFileEntry(fileEntry) {
            // URL in which the pdf is available
           
            var documentUrl = url;
            var uri = encodeURI(documentUrl);
          
            fileTransfer.download(uri, cdr.nativeURL + urlArr[urlArr.length-1],
                function(entry) {
                    loadingFactory.hide();
                    
                    toastMsg.show('Download Completed')
                },
                function(error) {
                    loadingFactory.hide();
                    navigator.notification.alert(ajaxErrorMsg);
                },
                false
            );
        };
    }
    else{
        window.open(url,'_blank')
    }

     } 
 }

$scope.goBack = function(){
    $state.go("mainView.communityWebinars");
}


$scope.$on('$ionicView.beforeEnter', function (e, data) {
  $ionicNavBarDelegate.showBackButton(true);
  data.enableBack = true;
  $rootScope.showMenu = false;
  
});


});

