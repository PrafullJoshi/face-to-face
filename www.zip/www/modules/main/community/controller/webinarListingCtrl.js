face2face.controller("webinarListingCtrl",function($scope,$window, $state,Scopes, serverRequestFactory,globalConstants,commonGetterService,loadingFactory,showPopup,showModalService,toastMsg,coupanCodePaymentService,$timeout,convertDate) {
 
 var token = commonGetterService.getToken();
 userType = $window.localStorage['userData'].user_type_id;
 $scope.terms = {};
 $scope.filterRes = {};
 $window.Stripe.setPublishableKey(globalConstants.stripeKey);
  /*
  * This function is made for prevent extra scope to be generated  
  */
  $scope.functionCall = function(functionName,params){
    
    switch(functionName){
     
      case 'hideModal':
          hideModal();
          break;
      case 'continuePayment':
          continuePayment();
          break;
      
      case 'stripeCallback':
          stripeCallback();
          break;
      case 'addCard':
         addCard();
         break;
     }
  }

/* get webinar listing */

  $scope.getWebinar = function(webinart){
    $scope.webinarType = webinart;
    $scope.webinarsList = '';
    pageno = 1;
    var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinar+'?filter_by='+$scope.filterby+'&search_by='+$scope.searchKey+'&sort_by='+$scope.sortby+'&categories_by='+$scope.webinarType+'&limit=6'+'&timezone='+timeZone(), 'GET', {},token);
    promise.then(function(res){
      loadingFactory.hide();
      if(res.data.status && res.data.data!="None"){
      
        $scope.webinarsList = res.data.data.webinar;
       // console.log(JSON.stringify($scope.webinarsList) +" 0000999999999999999999999999999")
        $scope.totalWebinar = res.data.data.total_count;
        $scope.$broadcast('scroll.infiniteScrollComplete');
        if($scope.totalWebinar > $scope.webinarsList.length){
          $scope.loadMore = true;
        }else{
           $scope.loadMore = false;
        }
      } else {
        $scope.webinarsList = [];
        $scope.loadMore = false;
        loadingFactory.hide();
      }
    },function(err){
      //alert(JSON.stringify(err))
    })
  }
  $scope.init = function(){
    $scope.webinarType = 'Future';
    $window.scrollTo(0,0);
    $scope.gridView = true;
    $scope.filterby = 'All';
    $scope.searchKey = '';
    $scope.sortby = '';
    $scope.webinarUpdates = 'N';
    $scope.webinarCouponCode = '';
    $scope.data = {};
    $scope.data.webinarCouponCode = '';
    $scope.data.prowebinarUpdates = 'N';
    $scope.data.proacceptTerms = 'N';
    
      
    $scope.getWebinar($scope.webinarType);
  }

  function timeZone(){
     var currentTimeZoneOffsetInHours = new Date().getTimezoneOffset() / 60;
     return (currentTimeZoneOffsetInHours);
   }

   $scope.getRegisteredWebinarStatus = function(webinar){
     
     $scope.webinarDetail = webinar; //for localStorage
     $scope.webinarId = webinar.id;
     $scope.webinarPrice = webinar.cost;
     $scope.webinarTopic = webinar.topic;
   
     if(webinar.webinar_type == 'Future'|| webinar.webinar_type == 'Past' ||(webinar.webinar_type == 'LIVE NOW' && (!webinar.register))){
      
         var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getRegisteredWebinarStatus+"webinar_id="+webinar.id+"&webinar_type="+webinar.webinar_type, 'GET', {},token);
         promise.then(function(res){

             if(res.data.status && res.data.data!="None"){
                 loadingFactory.hide();
                
                if(webinar.webinar_type == 'Past'&& webinar.register == true){
                 
                 if(webinar.play_url){
                  
                     $state.go('mainView.communityWebinarsDtls',{'webinarurl' : webinar.play_url,"webinartopic":webinar.topic,"webinarpresenter":webinar.presenter,"id":webinar.id,"webinarType":$scope.webinarType});

                  }
                  else{
                    toastMsg.show('Unable to process the request');
                  }
                 
                }
                else{
                   afterLogin(res.data.data,webinar);
                }
             }else{
                 loadingFactory.hide();
           }
         }, function(err) {
             loadingFactory.hide();
         })
      
       
     }
     else if(webinar.webinar_type == 'LIVE NOW'){
      

      if(webinar.register){
       // if(webinar.webinar_order.join_url){

          $state.go('mainView.communityWebinarsDtls',{'webinarurl' : webinar.webinar_order.join_url,"webinartopic":webinar.topic,"webinarpresenter":webinar.presenter,"id":webinar.id});

       // }
        
       }
      
     }
     
   }

   function addCard(){
       showModalService.hide();
       $scope.cardInfo = {};
       $scope.months = [1,2,3,4,5,6,7,8,9,10,11,12];
       $scope.years = addYears();
       commonGetterService.getStates($scope);
       showModalService.show($scope,'modules/consumer/billing/template/add-card.html');
       $scope.typeofAction = 'Add';
   }

  function addYears(){
      var dd = new Date();
      dd = dd.getFullYear();
      var oldYr = dd;
      var yr = [];
      yr.push(dd);
      for(var o = 1;o <30 ;o++){
          yr.push(++dd);
      }
      return yr.sort();
  }

   function afterLogin(webinarAlreadyPurchased,webinar){
       $scope.loggedinUser = true;
      
       if(webinarAlreadyPurchased.already_purchase_status == true && webinar.webinar_type == 'Future'){
              toastMsg.show('You have already been registered to this webinar');
            }else{
           if(webinarAlreadyPurchased.max_attendies_status == true && webinar.webinar_type == 'Future'){
                toastMsg.show('You can not register to this webinar as the attendee limit has been exceed for the same');
                       
           }else{
          
             if(userType == 1){
               if($scope.webinarPrice > 0){
                 $scope.showcardMsg = '';
              
               }else{
                showModalService.show($scope,'modules/main/community/template/registarWebinarConsumer.html');
              
               }
             }else{
            
               showModalService.show($scope,'modules/main/community/template/registarWebinarConsumer.html');
              

               if($scope.webinarPrice > 0){
                   coupanCodePaymentService.getCards($scope,token);
               }
             }
           }
       }
      
   }

   $scope.buttonText = function(type,register){
    
     if(type=="Future"){
       if(register == true){
         return 'Registered';
       }else if(register == false){
         return 'Register';
       }
      
   }else if(type=="Past"){
     if(register == true){
      return 'Watch Webinar Again';
    }
    else{
      return 'Buy Webinar';
    }
  
   }
   else{
    if(register == true){
      return 'Enter Webinar';
    }else if(register == false){
      return 'Register';
    }
    
   }
   }

  /* var getCards = function(){
     $scope.noCards = '';
     $scope.listofcards = [];
     var promiseforCards = serverRequestFactory.serverComm(globalConstants.serviceUrl.stripCardList,'POST',{},token);  // get the consumer detail list  
     promiseforCards.then(function(res){
     var res = res.data;
    
     if(res.status == true && res.data != "None"){
       loadingFactory.hide();                                   
       var result = res.data;
       for(var i = 0;i<result.length;i++){
           $scope.listofcards.push({last4 : result[i].last4, cardNo : 'XXXXXXXXXXXX'+result[i].last4, stripID : result[i].id , selectedid : res.stripe_card_id,month:result[i].exp_month,year:result[i].exp_year});
           if(res.stripe_card_id == result[i].id){
             $scope.list.selectedCard = $scope.listofcards[i];
           }
       }
       
       
      }
      else if(res.data == "None"){
       $scope.noCards = "No card added. Please add a card to continue";
       loadingFactory.hide();
      }


     },function(err){ 
       $scope.noSamePlans = 'Oops! some error occured. Please try again later';
       
     })
   }*/

   function continuePayment(){
   
       if($scope.webinarPrice > 0){
           if(!$scope.couponApplied){
             $scope.webinarCouponCode = '';
           }
           if($scope.list.selectedCard){
               $scope.noCards = ' ';
               if($scope.terms.acceptTerms == "Y"){
                  registerWebinar($scope.list.selectedCard.stripID);
               } else{
                 $scope.termsnConditions = "Please accept the terms and conditions";
               }
           } else{
            
               $scope.noCards = "No card added. Please add a card to continue";
               if($scope.terms.acceptTerms != "Y"){
                 $scope.termsnConditions = "Please accept the terms and conditions";
               }else{
                 $scope.termsnConditions = '';
               }
         }
           
       }else{
           if($scope.terms.acceptTerms == "Y"){
             registerWebinar('');
           }else{
             $scope.noSamePlans = "Please accept the terms and conditions";
           }
       }


   }

  $scope.stripeCallback = function(code,result){
     
     coupanCodePaymentService.submitStrip(code,result,$scope,token);

     $timeout(function(){
    //  showModalService.show($scope,'modules/main/community/template/registarWebinarConsumer.html');
     // coupanCodePaymentService.getCards($scope,token);   
     },1000);
   
   }

   var registerWebinar = function(stripID){
     if($scope.webinarPrice <= 0){
       $scope.webinarCouponCode = '';
     }
     var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.registerWebinar, 'POST', {
       "webinar_id" : $scope.webinarId,
       "source" : stripID, //stripe id in case of consumer and card token in case of provider
       "coupon_code" : $scope.webinarCouponCode,
       "newsletter_subsciption_status": $scope.webinarUpdates,
       "webinar_type": $scope.webinarType

     },token);
     promise.then(function(res){
        loadingFactory.hide();
       if(res.data.status && res.data.data!="None"){
      /*   $window.localStorage.removeItem('webinardetailForRegister');
       */  
         toastMsg.show('You have been successfully registered to this webinar');
         showModalService.hide();
         $scope.getWebinar($scope.webinarType);
         $scope.terms.acceptTerms = '';
        /* $scope.termAndCondModal = false;
         $scope.registerWebinarModal = false;
         $scope.addCardModal = false;
         $scope.updateCardModal = false;
         $scope.signupModal = false;
         $scope.providerCardModal = false;*/
       } else {
          loadingFactory.hide();
          $scope.terms.acceptTerms = '';
       }
     })
   }
   $scope.loadMoreWebinar = function(){
     pageno++;
     
     if($scope.loadMore){
      promiseRes = serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinar+'?filter_by='+$scope.filterby+'&search_by='+$scope.searchKey+'&sort_by='+$scope.sortby+'&categories_by='+$scope.webinarType+'&limit=6&page='+pageno+'&timezone='+timeZone(), 'GET', {});
      promiseRes.then(function(res) {
       
        if (res.data.status == true && res.data.data != "None") {
        
         loadingFactory.hide();
          $scope.$broadcast('scroll.infiniteScrollComplete');
          $scope.webinarsList = $scope.webinarsList.concat(res.data.data.webinar);
         
          if($scope.totalWebinar > $scope.webinarsList.length){
            $scope.loadMore = true;
          }else{
             $scope.loadMore = false;
          }
        } else {
          $scope.courses = [];
          $scope.loadMore = false;
         loadingFactory.hide();
          $scope.$broadcast('scroll.infiniteScrollComplete');
        }
      }, function(err) {
         loadingFactory.hide();
          $scope.$broadcast('scroll.infiniteScrollComplete');
      });
     }
     else{
       $scope.$broadcast('scroll.infiniteScrollComplete');
     }
  
   }

 function hideModal(){
     /*$scope.oModal.hide();
     $scope.oModal.remove();
     if($scope.templateUrl != 'modules/consumer/scheduleAppointment/template/consentSign.html'){
           close();
         }*/
   //  if()
   showModalService.hide();
 }

 $scope.closeModal = function(){
  showModalService.hide(true);
  $scope.cardInfo = {};
  Scopes.delete('formInfo');
  Scopes.delete('formInfoValidation')
 }

 function timeZone(){
     var currentTimeZoneOffsetInHours = new Date().getTimezoneOffset() / 60;
     return (currentTimeZoneOffsetInHours);
   }
  
   $scope.closeNav = function() {
     
       document.getElementById("myNav").style.width = "0%";
       document.getElementById("overlayOut").style.width = "0%";
   }

   $scope.getFilteredWebinar = function(sort_by){
    
     $scope.sort_by = sort_by;
     $scope.closeNav();
     if($scope.webinarType == 'Future'){
     
      var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinar+'?sort_by='+sort_by+'&categories_by=Future&limit=3&timezone='+timeZone(), 'GET', {},token);
     }
     else if($scope.webinarType == 'Past'){
      var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinar+'?sort_by='+sort_by+'&categories_by=Past&limit=3&timezone='+timeZone(), 'GET', {},token);
     }
        promise.then(function(res){
       loadingFactory.hide();
       if(res.data.status && res.data.data!="None"){
         $scope.webinarsList = res.data.data.webinar;
        
         $scope.futureWebinarCount = res.data.data.total_count;

       }
     })
   }

/*   $scope.getPastWebinar = function(sortBy){
     $scope.sortBy = sortBy;
     var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinar+'?sort_by='+sortBy+'&categories_by=Past&limit=3&timezone='+timeZone(), 'GET', {},token);
     promise.then(function(res){
       loadingFactory.hide();
       if(res.data.status && res.data.data!="None"){
         $scope.pastWebinarsList = res.data.data.webinar;
         $scope.pastWebinarCount = res.data.data.total_count;
       }
     })
   }*/
   $scope.openNav = function() {
       document.getElementById("myNav").style.width = "65%";
       document.getElementById("overlayOut").style.width = "100%";
       //console.log($scope.filterRes.fill + " 0000000000000000000000000000000000000000000000000000")
       
       $scope.filterList = [{
           filKeys: 'Most Popular', 
           selected: 0
           
         }, {
           filKeys: 'Most Oldest',
           selected: 0
         }, {
           filKeys: 'Most Recent',
           selected: 0
         }];
   }
 
 $scope.convertDate = function(date){
  if($scope.webinarType == 'Past')
   return convertDate.toYYYYmmdd(date);
 }

 $scope.getText = function(date,type){

  if(type == 'LIVE NOW'){
    return 'LIVE NOW';
  }
  else{
    return date;
  }
 }
  
 $scope.init();

});