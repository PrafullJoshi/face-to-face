face2face.controller('patientSignUp',function($scope,$timeout,$injector,globalConstants,serverRequestFactory,$window,validatePass,$state,requiredFactory,otherValidationCheck){

$scope.consumerSignupAPIMsg = '';
$scope.showMsg = false;
$scope.init = function(){
$scope.formSignup = {
    email: '',
	  username :'',
    errCapMssg:''
};
$scope.cap={
   captcha:''
}
$scope.recaptcha.createCaptcha();

}
//var $validationProvider = $injector.get('$validation');
$scope.pForm ={
	 //checkValid: $validationProvider.checkValid,
	 validateFlag:true,
	 submitForm: function(form) {
      $scope.pForm.validateFlag = true;
     /* $validationProvider.validate(form)  
      	  .success(function(){*/
            // check the required feilds
          if(requiredFactory.validateBeforeSubmit(form,$scope) &&  otherValidationCheck.validateBeforeSubmit()){

      	        if($scope.pForm.validateAfterSubmit()){

                    promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.consumerSignup,'POST',$scope.formSignup); // call consumer sign up api 
                    promise.then(function(res){

                      if(res.data.status == true && res.data.data != "None"){
                          var cusData = res.data.data;
                          var loginData = {
                            "fname"     : cusData.fname,
                            "lname"     : cusData.lname,
                            "email"     : cusData.email,
                            "username"  : cusData.username,
                            "token"     : cusData.token,
                            "userTypeId"    : cusData.user_type_id
                          };
                         $window.localStorage['userData'] = JSON.stringify(loginData);
                         //$state.go("main.thankYou");
                          if($window.localStorage['pNavigateState'] == "main.communitySilos"){
                              if(cusData.user_type_id == '1'){
                                $state.go("providerMain.communityJoinTerms");
                              }else if(cusData.user_type_id == '2'){ // Consumer id
                                $state.go('patientMain.communityJoinTerms');
                              }
                          }else{
                            $state.go("main.subPlan");
                          }
                         

                        $('#loader').hide();
                      }
                      else if(res.data.status == false){
                        $scope.showMsg = true;
                        if((res.data.message).hasOwnProperty('email')){
                          $scope.consumerSignupAPIMsg = globalConstants.errorMessages.uniqueEmail;
                        }else if((res.data.message).hasOwnProperty('username')){
                          $scope.consumerSignupAPIMsg = globalConstants.errorMessages.uniqueUser;
                        }
                         
                        $('#loader').hide();
                      window.scrollTo(0,0);
                      }

                    },function(err){

                    });

      	        }
           }
      	 /* })
      	 .error(function(){
             
      	 });*/
        
      },

      validateAfterSubmit:function(){
 //  check if captcha and password is valid before submitting 
         var capText = $scope.captchaText;
         $scope.cap.captcha = ($scope.cap.captcha).toLowerCase();
         capText = (capText).toLowerCase();
         if(capText != $scope.cap.captcha){
         	$scope.formSignup.errCapMssg = globalConstants.errorMessages.wrongCaptcha;
         	$scope.pForm.validateFlag = false;
          return $scope.pForm.validateFlag;
         }
         var res = validatePass.validate($scope.formSignup.password,$scope.formSignup.confirm_password,$scope.formSignup.email,$scope.formSignup.username)
          
         $scope.pForm.validateFlag = res.flag;
         if(res.flag)
           $scope.formSignup.errPassMssg = res.msg;
         else
           $scope.formSignup.errPassMsg = res.msg;

         return $scope.pForm.validateFlag;
      }

}

$scope.recaptcha = {
 // create a random key 
  
    createCaptcha:function(){
       $scope.captchaText = "";
       $scope.cap.captcha = "";
           var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
           var possibleNumer = "012345";
           for( var i=0; i <= 5; i++ )
               $scope.captchaText += possible.charAt(Math.floor(Math.random() * possible.length));
           
           $scope.capStyle = globalConstants.captchaStyle[possibleNumer.charAt(Math.floor(Math.random() * possibleNumer.length))];
           
   }



}
//  TO disable copy paste drag of captcha text on all browsers

$('#captchaText').bind("cut copy paste drag",function(e) {
    e.preventDefault();

});

$('#captchaText').on("dragstart", function() {
     return false;
});   
$scope.init();  // initialize the controller ..

});