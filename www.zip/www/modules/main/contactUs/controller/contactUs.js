/**
@controller for contact us 

**/

face2face.controller('contactUs',function($scope,globalConstants,serverRequestFactory,requiredFactory,otherValidationCheck,commonGetterService,toastMsg,loadingFactory,$state){
   $scope.contact = {provider_type_id:'',news_updates:'N'};
   $scope.providerTypeData =[];
   commonGetterService.getProviderType($scope);
   $scope.contactUsSubmit = function(form){
	    if(requiredFactory.validateBeforeSubmit(form,$scope) && otherValidationCheck.validateBeforeSubmit()){     
	        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.contactUs,'POST',$scope.contact);  
	        promise.then(function(res){
	            if(res.data.status == true && res.data.data != "None"){
	           		loadingFactory.hide();
	           		toastMsg.show(res.data.message);
	           		$scope.contact = {provider_type_id:'',news_updates:'N'};
	           		$state.go("mainView.inbox");
	           		//$ionicHistory.goBack();
	           	}else if(res.status == false){
	           		toastMsg.show('Oops! some error occured. Please try again later');
	           		loadingFactory.hide();
	           	}


	        },function(err){
	        	toastMsg.show('Oops! some error occured. Please try again later');
	        	loadingFactory.hide();
	        })
	   
	    }
    }
    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      	$ionicNavBarDelegate.showBackButton(false);
	    data.enableBack = false;
	    $rootScope.showMenu = true;
    });  
});