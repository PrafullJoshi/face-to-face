
face2face.controller("footerCtrl",function($scope,$state, $rootScope, convertDate) {

  $rootScope.checkHeader = function(fwdState){
    var currentState = $state.current.name;
    if( currentState.indexOf("main") != -1){
      if(fwdState == 'faqs'){
        $state.go("main.faqs");
      } else if(fwdState == 'privacyTerms'){
        $state.go("main.privacyTerms");
      }
      else if(fwdState == 'contactUs'){
        $state.go("main.contactUs");
      }else if(fwdState == 'consent'){
        $state.go("main.consent");
      }else if(fwdState == 'modal'){
        $state.go("main.modal");
      }
    }
    else if( currentState.indexOf("providerMain") != -1){
      if(fwdState == 'faqs'){
        $state.go("providerMain.faqs");
      } else if(fwdState == 'privacyTerms'){
        $state.go("providerMain.privacyTerms");
      }
      else if(fwdState == 'contactUs'){
        $state.go("providerMain.contactUs");
      }else if(fwdState == 'consent'){
        $state.go("providerMain.consent");
      }else if(fwdState == 'modal'){
        $state.go("providerMain.modal");
      }
    }
    else{
      if(fwdState == 'faqs'){
        $state.go("patientMain.faqs");
      } else if(fwdState == 'privacyTerms'){
        $state.go("patientMain.privacyTerms");
      }
      else if(fwdState == 'contactUs'){
        $state.go("patientMain.contactUs");
      }else if(fwdState == 'consent'){
        $state.go("patientMain.consent");
      }else if(fwdState == 'modal'){
        $state.go("patientMain.modal");
      }
    }
  }

  $('body').css({'margin-bottom':$('footer').height() + "px"});
  $(window).resize(function(){
    $('body').css({'margin-bottom':$('footer').height() + "px"});
  });




$scope.yr = convertDate.passYr();
// to get media links from backend
//mediaLinksService.getMediaLinks($scope);


});


