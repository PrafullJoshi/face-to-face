/*Controller to manage Main header when unlogged in
*/


face2face.controller("mainHeaderCtrl",function($scope, $window, $state,serverRequestFactory,globalConstants,$rootScope) {
	var token,userType;
	if(localStorage.userData){
     	var userData = JSON.parse(localStorage.userData);
     	token = userData.token;
     	userType = userData.userTypeId;
    }

    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.siloMenu, 'GET', {});
    promise.then(function(res) {
        if (res.data.data) {
          $('#loader').hide();
          $scope.siloHeading = res.data.data;
        } else {
          $('#loader').hide();
        }
      }, function(err) {
        $('#loader').hide();
      });

    // var promise1 = serverRequestFactory.serverComm(globalConstants.serviceUrl.headerMenu, 'GET', {});
    // promise1.then(function(res) {
    //     if (res.data.data) {
    //       $('#loader').hide();
    //       $scope.headerMenu = res.data.data;
    //       console.log($scope.headerMenu);
    //     } else {
    //       $('#loader').hide();
    //     }
    //   }, function(err) {
    //     $('#loader').hide();
    //   });


    $scope.consumerLinks = function(state){

    	if(state == "patientMain.conOnDemandNewIssue"){
    		if(userType == 2 && token){
    			$state.go(state);
    		}else{
    			$state.go('main.conOnDemandNewUser');
    		}
    	}

    }
    $scope.goConsumerProvider = function(){
        if($state.current.name == 'main.landingPage.providerhome'){
           $state.go("main.pSignUp1"); 
        }else{
           $state.go("main.patientSignUp");
        }
        
    }

    $scope.saveCommunityData = function(id,title){
        var communityData = {
        "provider_type_id"  : id,
        "title"             : title
      }
        $window.localStorage["communityData"] = JSON.stringify(communityData);
        $state.go("main.communitySilos",'',{reload:true})

    }

    // $scope.commonFunc = function(param,record){
    //   for(var i=0; i<$scope.siloData.length;i++){
    //     if(record.url == $scope.siloData[i].slug){
    //       id = $scope.siloData[i].id;
    //       title = $scope.siloData[i].title;
    //       color = $scope.siloData[i].color;
    //     }
    //   }
    //   if(param=='siloPage'){
    //     getSiloPageData(id,color);
    //   } else if(param == 'communityPage'){
    //     $scope.saveCommunityData(id,title);
    //   }
    // }

});