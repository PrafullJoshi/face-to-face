face2face.controller("loginCtrl",function($scope,$state,globalConstants,serverRequestFactory,$stateParams,$window,validatePass,requiredFactory,loadingFactory,toastMsg,$ionicHistory,$rootScope,calendarSync,$timeout,commonGetterService) {
  $ionicHistory.clearCache();
  localStorage.removeItem('userData');
  // Initialization of global variables
  $scope.serviceMsgs          = ''; // for flash error msg
  $scope.showMsg              = false;
  $scope.errMsg               = "";
  $scope.decodedEmail         = $stateParams.decodedEmail;
  $scope.changePwd            = {}; // for password validation
  $scope.changePwd.email      = "";
  $scope.changePwd.username   = "";

  // Ajax call for getting username when came to reset password page from email url
  if($state.current.name === "main.resetPass"){
    var promise;
    var secretKey = $stateParams.secretKey; // Secret key getting from url
    promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getUsername+secretKey,'GET',{}); // call the login api
    promise.then(function(res){
      if(res.data.status == true){
        $scope.changePwd.username = res.data.data.username;
        // $('#loader').hide();
      }

      else {
        $state.go("main.error");
      //   $('#loader').hide();
      }
    },function(err){
      $scope.showMsg = true;
      $scope.serviceMsgs = "Oops!! Something went wrong";
      // $('#loader').hide();
    });
  }

  $scope.init = function(){

  // For checking 'keep me logged in'
    if(localStorage.rembMe === 'true'){
      $scope.data.userEmail = localStorage.userEmail;
      $scope.data.pass = localStorage.pass;
      $scope.data.rembMe = true;
    }
    if(localStorage.email){
      $scope.changePwd.username = localStorage.username;
      $scope.changePwd.email = localStorage.email;
    }
  };

  // For sign in validation
  $scope.data = {

    //Sign in method
    signin : function(form) {
      var promise;
      if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
        cordova.plugins.Keyboard.close();
      }      
      $ionicHistory.clearCache();
      $ionicHistory.clearHistory();
      if(requiredFactory.validateBeforeSubmit(form,$scope)){
        //console.log(JSON.stringify(form));

        //storing value in localstorage according to  keep me logged in action.
        if($scope.data.rembMe){
          $window.localStorage["userEmail"] = $scope.data.userEmail;
          $window.localStorage["pass"]      = $scope.data.pass;
          $window.localStorage["rembMe"]    = true;
          promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.login,'POST',{"username":$scope.data.userEmail,"password":$scope.data.pass,"timezone" :(new Date().getTimezoneOffset() / 60),'source':'mobile'});  //the login api
        } else {
          $window.localStorage["userEmail"] = '';
          $window.localStorage["pass"]      = '';
          $window.localStorage["rembMe"]    = false;
          
          promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.login,'POST',{'username':$scope.data.userEmail,'password':$scope.data.pass,"timezone" :(new Date().getTimezoneOffset() / 60),'source':'mobile'}); //the login api
        }
        promise.then(function(res){

          if(res.data.status == true && res.data.data != "None" ){
           
            $scope.showMsg = false;
            var cusData = res.data.data;

           /* var host = extractDomain.extractRootDomain(window.location.hostname);
            var mtoken = (cusData.moodle_token) ? cusData.moodle_token:'';
            var loginTime = new Date(); 
            document.cookie = "emr_token="+cusData.emr_token+"; domain="+host+"; path=/";
            document.cookie = "moodle_token="+mtoken+"; domain="+host+"; path=/";
            document.cookie = "status=login; domain="+host+"; path=/"; 
            document.cookie = "activityTime=" + loginTime + "; domain="+host+"; path=/";*/
            var loginTime = new Date(); 
            localStorage.activitystore = loginTime;

            var loginData = {
              "fname"     : cusData.fname,
              "lname"     : cusData.lname,
              "email"     : cusData.email,
              "username"  : cusData.username,
              "token"     : cusData.token,
              "userTypeId"    : cusData.user_type_id,
              "emrToken"  : cusData.emr_token,
              "helpHide": cusData.help_visited_mobile,
            };
            calendarSync.getCalendarEvents(cusData.token); // sync calendar with device
            //getInboxCount(cusData.token);

            window.FirebasePlugin.getToken(function(token) {
               // save this server-side and use it to push notifications to this device
               commonGetterService.updateNotificationToken(token);
            }, function(error) {
               console.error(error);
            });
            $window.localStorage['userData'] = JSON.stringify(loginData);
            if($window.localStorage['userData']){
                  var userData = JSON.parse($window.localStorage['userData']);
                    if(userData.userTypeId == 2){
                       $rootScope.mTemplate = "modules/main/mainView/template/menu.html";
                       $rootScope.tabFlag = true;  
                       }
                       else{
                         $rootScope.mTemplate = "modules/main/mainView/template/menuProvider.html";
                         $rootScope.tabFlag = false;  
                       }
            }
              if(cusData.user_type_id == '1'){ // Provider id
                 $timeout(function(){$state.go('mainView.proDashboard')},10);
                //$state.go('mainView.inbox',{reload:true});
              }
              else if(cusData.user_type_id == '2'){ // Consumer id
                //$state.go('mainView.inbox',{reload:true});
                $timeout(function(){$state.go('mainView.conDashboard')},10);
              }
             loadingFactory.hide();

           }else{
              $scope.showMsg = true;
            //  $scope.serviceMsgs = "Invalid Username or Password";
              toastMsg.show("Invalid Username or Password")
              loadingFactory.hide();
         }

        },function(err){
          $scope.showMsg = true;
          $scope.serviceMsgs = "Oops!! Something went wrong";
         loadingFactory.hide();
        });
      }
    },
// Forgot password method
    forgotPassSub:function(form){
      if(requiredFactory.validateBeforeSubmit(form,$scope)){
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.forgotPass,'POST',{"username":$scope.data.usernameEmail}); // call the login api
        promise.then(function(res){

          if(res.data.status == true && res.data.data != "None"){
              // For email decoding which shows in next page.
              $scope.decodedEmail = res.data.data.email;
              $window.localStorage["username"] = res.data.data.username;
              $window.localStorage["email"] = res.data.data.email;
              var str = ($scope.decodedEmail).split('@');
              var size = str[0].length;
              var star = '';
              for(var i = 0;i<=(size-2);i++){
                var star = star + '*';
              }
              $scope.decodedEmail = star + str[0].substring((size-2),size)+ '@' + str[1];
              $state.go('main.checkEmail',{ decodedEmail : $scope.decodedEmail });
              loadingFactory.hide();
          }else {
            $scope.showMsg = true;
            $scope.serviceMsgs = "Email or Username does not exist";
            loadingFactory.hide();
          }

        },function(err){
          $scope.showMsg = true;
          $scope.serviceMsgs = "Oops!! Something went wrong";
          loadingFactory.hide();
        });
      }
    },
// Method for reset password
    resetPassword:function(form){
      if(requiredFactory.validateBeforeSubmit(form,$scope)){
        var secretKey = $stateParams.secretKey; // Secret key getting from url
        var res = validatePass.validate($scope.changePwd.password,$scope.changePwd.confirm_password,$scope.changePwd.email,$scope.changePwd.username);
        if(res.flag === true){
          promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.resetPassword+secretKey,'POST',{"password":$scope.changePwd.password,"confirm_password":$scope.changePwd.confirm_password}); // call the login api
          promise.then(function(res){
            if(res.data.status == true){
            //  $('#myModal').modal('show');
             //  $('#loader').hide();
            }
            else if(res.data.status == false && res.data.message == "Old and New password cannot be same"){
              $scope.showMsg = true;
              $scope.serviceMsgs = "Old and New password cannot be same";
             //  $('#loader').hide();
           }else {
              $state.go("main.error");
           //    $('#loader').hide();
            }
          },function(err){
            $scope.showMsg = true;
            $scope.serviceMsgs = "Oops!! Something went wrong";
          //   $('#loader').hide();
          });
        }
      }
    }
  },

// Method for returning to sign in page after successfull password reset
  $scope.retSignin = function(){
    $state.go('main.login');
  }
// redirect to web's forgot password

$scope.gotoForgotPassword = function(){

      inAppBrowserRef= window.open(globalConstants.gHost+'/#/main/forgotPassword','_blank','location=yes');

}
 $scope.myGoBack = function() {
    $state.go('pre-signin');
  };
// call init method
  $scope.init();


});


