face2face.controller("thankYouCtrl",function($scope,$rootScope,$window, $state,serverRequestFactory,globalConstants) {
	$scope.nextPage = function(){
		if($rootScope.previousState === "main.pSignUp6"){
			var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.login,'POST',{"username":localStorage.username,"password":localStorage.password});  // the login api 
			promise.then(function(res){
				localStorage.clear();
         		if(res.data.status == true && res.data.data != "None" ){
		            $('#loader').hide();
		            var cusData = res.data.data;
		            var loginData = {
		              "fname"    	: cusData.fname,
		              "lname"    	: cusData.lname,
		              "email"     	: cusData.email,
		              "username" 	: cusData.username,
		              "token"     	: cusData.token,
		              "userTypeId"  : cusData.user_type_id
		            };
		            $window.localStorage['userData'] = JSON.stringify(loginData);
					$state.go("providerMain.providerDashboard");
	            }
	        },function(err){
	           $('#loader').hide();
	        });

		} else{
			$state.go("patientMain.dashboard");
		}
	}

});


