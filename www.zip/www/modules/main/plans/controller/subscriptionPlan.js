face2face.controller('subscriptionPlan',function($scope,$window,serverRequestFactory,globalConstants,$state,requiredFactory){
  $scope.token = JSON.parse($window.localStorage['userData']).token;
    //pk_test_2gzR3WyOmsErAwWExGMXhs5t   qa key
    //pk_test_8OSAmgRe0R3cqksGG2EqxOaa
    
	$window.Stripe.setPublishableKey(globalConstants.stripeKey);
	$scope.showPlanForm=true;
	$scope.noSamePlans = '';
  $scope.noCards = '';
	$scope.list={}
  $scope.message = '';
  $scope.couponApplied = false;
	//$scope.list.months = ['January','February','March','April','May','June','July','August','September','October','November','December'];

  $scope.list.months= [1,2,3,4,5,6,7,8,9,10,11,12];
	$scope.list.year = addYears();
	$scope.carddata = {};
  $scope.planName = '';
  $scope.cardInfo = {};
  $scope.cardInfoUpd = {};
  $scope.showMsg = false;
  $scope.showMsgPln = false;
  $scope.planType = '';
   // $scope.showMsg = false;
   function addYears(){
     
     var dd = new Date();
     dd = dd.getFullYear();
     var oldYr = dd;
     var yr = [];
     /*for(o = 30;o > 1 ;o--){
         yr.push(--oldYr);
     } */
     yr.push(dd);
     for(o = 1;o <30 ;o++){
         yr.push(++dd);
     } 

     return yr.sort();
  }



  
/* intiliaze data */
    $scope.init = function(){
    	
    	//$scope.placouponCode = "";
    	
    	$scope.plan = {
    		subUpdates:'N',
    		acceptTerms:'',

    	};
    	 // gets the state list from the api
    	  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStateList,'GET');  
    	  promise.then(function(res){
    	     if(res.data.status == true){
    	      
    	       $scope.plan.stateList =  res.data.data;
              $('#loader').hide();

    	     }else if(res.status == false){
    		 	$('#loader').hide();
    		 }


    	  },function(err){

    	  })


  /*var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getconsDetail,'GET','',$scope.token);  // to get the consumer detail list  
  promise.then(function(res){
     var res = res.data;
     if(res.status == true){
       $('#loader').hide();
     }
     else if(res.status == false){
      $('#loader').hide();
     }
    
  },function(err){ 

  })*/

}
    
  // get all plans
    $scope.getPlans = function(){
      var promisePl = serverRequestFactory.serverComm(globalConstants.serviceUrl.getPlans,'GET','',$scope.token);  
      promisePl.then(function(res){
      var res = res.data;
      if(res.status == true){
         res = res.data;

         if(res.hasOwnProperty('selected_plan')){
         	$scope.planId = res.selected_plan;
         	$window.localStorage.selectedPlId = res.selected_plan;
          $scope.planType = res.plan_type;
          
         	if(res.plan_type != 'Free'){
         		$scope.showPlanForm = false;
            $scope.getCards();
         	}
         }
         else{
         	$scope.planId = res.selected_plan;
         }
           $scope.planList = res.plans;

          $('#loader').hide();                  
       }
       else if(res.status == false){
        $('#loader').hide();
       }
      },function(err){ 

      })
    }
    
    $scope.getPlans(); // get subscription plans

    $scope.checkCouponCode = function(event){
      $scope.couponErr = "";
      event.stopPropagation();
      $scope.couponErr = '';
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.chkCouponDetails,'POST',{plan_id:$scope.planId,coupon_code:$scope.plan.couponCode},$scope.token);  // get the consumer detail list  
      promise.then(function(res){
      var res = res.data;
      if(res.status == true){
        
          $scope.couponErr = "Coupon code applied successfully";
          $scope.couponSuccess = true;
            $('#loader').hide(); 
            $scope.couponApplied = true;

       }
       else if(res.status == false){
           $scope.plan.couponCode = '';
           $scope.couponErr = "Invalid coupon code";
            $('#loader').hide();
       }


      },function(err){ 

      })
    }
    $scope.selectPl = function(selectedid,price){

    	//console.log($scope.plan.selectedPlan);
        $scope.couponErr = "";
        $scope.cardInfo = {};
        $scope.plan.couponCode = '';
        $scope.noSamePlans='';
    	if(price){
              if($scope.showPlanForm){
                $scope.getCards();
              }
              $scope.showPlanForm = false;
              $scope.plan.subUpdates = 'N';
              $scope.plan.acceptTerms = '';
              $scope.planId = selectedid;

    	}
    	else{
    		$scope.showPlanForm = true;
    		$scope.plan.subUpdates = 'N';
    		$scope.plan.acceptTerms = '';
    		$scope.planId = selectedid;
    	}

    }
    
    $scope.getCards = function(){
      $scope.noCards = '';
      $scope.listofcards = [];
      var promiseforCards = serverRequestFactory.serverComm(globalConstants.serviceUrl.stripCardList,'POST',{},$scope.token);  // get the consumer detail list  
      promiseforCards.then(function(res){
      var res = res.data;
     
      if(res.status == true && res.data != "None"){
        var result = res.data;
        for(var i = 0;i<result.length;i++){
            $scope.listofcards.push({cardNo : 'XXXXXXXXXXXX'+result[i].last4, stripID : result[i].id , selectedid : res.stripe_card_id,month:result[i].exp_month,year:result[i].exp_year});
            if(res.stripe_card_id == result[i].id){
              $scope.list.selectedCard = $scope.listofcards[i];
            }
        }
        
        $('#loader').hide();                                   
        
       }
       else if(res.data == "None"){
        $scope.noCards = "No card added. Please add a card to continue";
        $('#loader').hide();
       }


      },function(err){ 
        $scope.noSamePlans = 'Oops! some error occured. Please try again later';
        
      })
    }
    
    $scope.updateCardIdOnchange = function(id){
      if(id){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateDefaultCard + id ,'GET',{},$scope.token,'',true);  // get the consumer detail list  
                   promise.then(function(res){
                   var res = res.data;
                   if(res.status == true){
                     
                      $('#loader').hide();              
                    }
                    else if(res.status == false){
                     
                     $('#loader').hide();
                    }


                   },function(err){ 

                   })
      }
     
    }
    $scope.submitFreePlan= function(){
      $scope.message = "";
        $scope.showMsgPln = false;
           if($scope.plan.acceptTerms == "Y"){
           	 if($scope.planId !== parseInt($window.localStorage.selectedPlId) || $scope.planType == 'Free'){
                         // if($scope.couponApplied)
                            //$scope.showMsg = false;
                          $scope.noSamePlans = '';
           	 		          $scope.planfreeData = {
           	 		        	plan_id: $scope.planId,
           	 		        	newsletter_subsciption_status:$scope.plan.subUpdates,
           	 		        	terms_use:$scope.plan.acceptTerms,
           	 		        //	coupon_code:$scope.plan.couponCode,
           	 		        	card:''

           	 		        }
                          

                            var promisePPl = serverRequestFactory.serverComm(globalConstants.serviceUrl.subscribePlan,'POST',$scope.planfreeData,$scope.token);  // get the consumer detail list  
                            promisePPl.then(function(res){
                            var res = res.data;
                            if(res.status == true ){
                              $window.localStorage.selectedPlId = res.data.plan_id;  
                              $scope.message = "Plan has been subscribed successfully";
                              $('#myModalPl').modal('show');  
                              $('#loader').hide();                                   
                              
                             }
                             else if(res.status == false){
                              $scope.showMsg = true;
                              $scope.cardErr = res.message;
                              $('#loader').hide();
                             }


                            },function(err){ 
                              $scope.noSamePlans = 'Oops! some error occured. Please try again later';
                              
                            })
                      
                          
           	 	           
           	 }else{
           	 	$scope.noSamePlans = "Please choose some other plan. You have already chosen this plan";
           	 	
           	 }
           }
    	    else{
              $scope.noSamePlans = "Please accept the terms and conditions"
            }

    }
	$scope.stripeCallback = function (code, result) {
     $scope.showMsg = false;
     $scope.message = "";
	    if (result.error) {
	       if(result.error.hasOwnProperty('message')){
           
           $scope.cardErr = result.error.message;
           $scope.showMsg = true;
           console.log(result.error.message);
         }
         else{


           $scope.consData = {
                   name:$scope.cardInfo.name,
                   address_city:$scope.cardInfo.city,
                   address_line1:$scope.cardInfo.address1 ,
                   address_line2:($scope.cardInfo.address2) ? $scope.cardInfo.address2 : ' ',
                   address_state:$scope.cardInfo.state ,
                   address_zip:$scope.cardInfo.zip_code ,
                   cvc:$scope.cardInfo.cvc ,                 
                   exp_month:$scope.cardInfo.exp_month ,
                   exp_year:$scope.cardInfo.exp_year , 
                   number:$scope.cardInfo.number
              
           }

           if(code == 408){
             //var othervF1 = otherValidationCheck.validateBeforeSubmit();
             //if(requiredFactory.validateBeforeSubmit($scope.conFormProf,$scope)){
              
               var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',$scope.consData,$scope.token);  // get the consumer detail list  
               promise.then(function(res){
               var res = res.data;
               if(res.status == true){
                   $scope.cardInfo.cvc = '';
                   $scope.message = "Card has been added successfully"
                   $('#myModalPl').modal('show');
                   $('#add-card').modal('hide'); 
                   $('#loader').hide();  
                   $scope.getCards(); 
                   $scope.cardInfo = {};

                }
                else if(res.status == "error"){
                 $scope.showMsg = true;
                 $scope.cardErr = res.message;
                 window.scrollTo(0,0);
                 $('#loader').hide();
                }


               },function(err){ 

               })


             //}
           }

           console.log(result.error);
         }
         
	       $scope.noSamePlans = result.error.message;
	       console.log(result.error.message);

	    } else {
	        console.log('success! token: ' + result.id);
	                  $scope.noSamePlans = '';
	        	       /* $scope.planData = {
	        	        	plan_id: $scope.planId,
	        	        	newsletter_subsciption_status:$scope.plan.subUpdates,
	        	        	terms_use:$scope.plan.acceptTerms,
	        	        	coupon_code:$scope.plan.couponCode,
	        	        	card:result

	        	        }*/
	        	     /*   if($scope.plan.acceptTerms == "Y"){*/
	        	        		// if($scope.planId !== parseInt($window.localStorage.selectedPlId)){
	        	        		 	var promisePPl = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',result,$scope.token);  // get the consumer detail list  
	        	        		 	promisePPl.then(function(res){
	        	        		 	var res = res.data;
	        	        		 	if(res.status == true ){
	        	        		 	      
	        	        		 	      $window.localStorage.selectedPlId = res.data.plan_id;  
                                $scope.message = "Card has been added successfully"
	        	        		 	      $('#myModalPl').modal('show'); 
                                $('#add-card').modal('hide'); 
                                $('#loader').hide();
                                $scope.getCards(); 
	        	        		 	      $scope.cardInfo = {};   
	        	        		 	 }
	        	        		 	 else if(res.status == false){
                             $scope.showMsg = true;
                               if(res.hasOwnProperty('message')){
                                $scope.plan.couponCode = '';                                
                                $scope.apiMessage = res.message;
                               }
                                window.scrollTo(0,0);
                               $('#loader').hide(); 
	        	        		 	 }


	        	        		 	},function(err){ 
	        	        		 		$scope.noSamePlans = 'Oops! some error occured. Please try again later';
	        	        		 		
	        	        		 	})
	        	        	
	    }
     
	};
 
  $scope.submitPaidPlan = function(){
    $scope.message = "";
    if(!$scope.couponApplied){
          $scope.plan.couponCode = '';
        }
     $scope.planData = {
                          plan_id: $scope.planId,
                          newsletter_subsciption_status:$scope.plan.subUpdates,
                          terms_use:$scope.plan.acceptTerms,
                          coupon_code:$scope.plan.couponCode,
                       
                       }

        if($scope.list.selectedCard){
          $scope.noCards = '';

         if($scope.plan.acceptTerms == "Y"){
          if($scope.planId !== parseInt($window.localStorage.selectedPlId)){
              $scope.noSamePlans = '';
              if(!$scope.noCards){
              var promisePPl = serverRequestFactory.serverComm(globalConstants.serviceUrl.subscribePlan,'POST',$scope.planData,$scope.token);  // get the consumer detail list  
              promisePPl.then(function(res){
              var res = res.data;
              if(res.status == true ){
                $window.localStorage.selectedPlId = res.data.plan_id;  
                $scope.message = "Plan has been subscribed successfully"
                $('#myModalPl').modal('show');  
                $('#loader').hide();                                   
                $scope.couponApplied = false;
               }
               else if(res.status == false){
                $('#loader').hide();
               }


              },function(err){ 
                $scope.noSamePlans = 'Oops! some error occured. Please try again later';
                
              })
           } 
          }
           else{
           $scope.noSamePlans = "Please choose some other plan. You have already chosen this plan";
                         
           }
         }
         else{
                $scope.noSamePlans = "Please accept the terms and conditions";
         }
      } else{
        $scope.noCards = "No card added. Please add a card to continue";
        if($scope.plan.acceptTerms != "Y"){
          $scope.noSamePlans = "Please accept the terms and conditions";
        }else{
          $scope.noSamePlans = '';
        }
      }

  }

  $scope.showcardPopup = function(type,form){
  $scope.cardErr ="";
  $scope.conFormProf = form
  if(type === 'add'){
    $("#add-card").modal('show');
  }
  else{
   
    if($scope.list.selectedCard){
     // $scope.list.selectedCard = JSON.parse($scope.list.selectedCard);
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateCard + $scope.list.selectedCard.stripID ,'GET',{},$scope.token);  // get the consumer detail list  
                 promise.then(function(res){
                 var res = res.data;
                 if(res.status == "success"){
                      $scope.cardInfoUpd.name = res.response.name;
                      $scope.cardInfoUpd.city = res.response.address_city;
                      $scope.cardInfoUpd.address1 = res.response.address_line1;
                      $scope.cardInfoUpd.address2 = res.response.address_line2;
                      $scope.cardInfoUpd.state = res.response.address_state;
                      $scope.cardInfoUpd.zip_code = res.response.address_zip;
                      $scope.cardInfoUpd.exp_month = JSON.stringify(res.response.exp_month);
                      $scope.cardInfoUpd.exp_year = JSON.stringify(res.response.exp_year);
                      $scope.cardInfoUpd.number = "XXXXXXXXXXXX" + res.response.last4;
                      $scope.cardInfoUpd.cvc = res.response.cvc_check;
                   
                    $('#loader').hide();              
                  }
                  else if(res.status == "error"){
                   $scope.showMsg = true;
                   $scope.cardErr = res.message;
                   window.scrollTo(0,0);
                   $('#loader').hide();
                  }


                 },function(err){ 

                 })
                  $("#update-card").modal('show');
    }
  

  }
}
$scope.updateCard = function(form){
  $scope.message = "";
  var obj = {
    address_city : $scope.cardInfoUpd.city,
   // address_country : '',
    name : $scope.cardInfoUpd.name,
    address_line1 : $scope.cardInfoUpd.address1,
    address_line2 : ($scope.cardInfoUpd.address2) ? $scope.cardInfoUpd.address2 : ' ',
    address_state : $scope.cardInfoUpd.state,
    address_zip : $scope.cardInfoUpd.zip_code,
    exp_month : $scope.cardInfoUpd.exp_month,
    exp_year : $scope.cardInfoUpd.exp_year,
    card_id : $scope.list.selectedCard.stripID 
  }
   
  if(requiredFactory.validateBeforeSubmit(form,$scope)){
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.submitUpdatedCard ,'POST',obj,$scope.token);  // get the consumer detail list  
               promise.then(function(res){
               var res = res.data;
               if(res.status == "success"){
                $scope.message = "Card has been updated successfully"
                  $("#update-card").modal('hide');
                  $('#myModalPl').modal('show');
                  $('#loader').hide();              
                }
                else if(res.status == "error"){
                 $scope.showMsg = true;
                 $scope.cardErr = res.message;
                 window.scrollTo(0,0);
                 $('#loader').hide();
                }


               },function(err){ 

               })
  }
}
$scope.clearForm=function(form){
 
 $(".errorMsg span").html('');
}
	$scope.back=function(){
    if($scope.message == "Card has been added successfully"){

    } 
    else if($scope.message == "Card has been updated successfully"){

    }
    else{
      $state.go("main.thankYou");
    }
	  
	}
	$scope.init();
});

