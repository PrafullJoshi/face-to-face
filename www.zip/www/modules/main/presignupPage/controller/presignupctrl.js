
face2face.controller("presignupctrl",function($scope,$rootScope,$state,$timeout,globalConstants) {
    var inAppBrowserRef;
    var saveUrl;
    $scope.goToSignup = function(type){
     if(type === 'consumer'){
      //inAppBrowserRef = cordova.InAppBrowser.open('http://f2f-staging.kiwireader.com/#/main/csignUp', '_blank', 'location=yes');
      inAppBrowserRef= window.open(globalConstants.gHost+'/main/csignUp/mobile','_system','location=yes,clearcache=yes,clearsessioncache=yes');

     }
     else if(type === 'provider'){
      //inAppBrowserRef = cordova.InAppBrowser.open('http://f2f-staging.kiwireader.com/#/main/pSignUp1', '_blank', 'location=yes');

       inAppBrowserRef = window.open(globalConstants.gHost+'/main/pSignUp1?from=mobile','_system','location=yes');
     }
      //inAppBrowserRef.addEventListener('loadstop', loadStopCallBack);
      inAppBrowserRef.addEventListener('loadstart', loadStopCallBack);
    }



    var loadStopCallBack = function(event){
      $timeout(function(){
         if(event.url.indexOf('thankYou')>=0){

           inAppBrowserRef.close();
           $state.go("signin");

         }
       },500);

      }
      
      $scope.myGoBack =function(){
        $state.go("pre-signin");
      }


});

