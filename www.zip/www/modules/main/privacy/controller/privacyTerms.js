
face2face.controller("privacyTermsCtrl",function($scope,$state,globalConstants,serverRequestFactory,$sce,loadingFactory) {
 
    var promise;
    promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getPrivacyTerms,'GET',{}); // call the login api 
    promise.then(function(res){
      if(res.data.status == true && res.data.data != "None"){
        (res.data.data.page.description).replace(/$ICON_MINUS/g,"<span class='termsIcon'><i class='more-less fa fa-minus'></i></span>");
        (res.data.data.page.description).replace(/$ICON_PLUS/g,"<span class='termsIcon'><i class='more-less fa fa-plus'></i></span>");  
        
         $scope.privacyTermsData = res.data.data.page.description;
        loadingFactory.hide();
      }
      else {
         loadingFactory.hide();
      }
    },function(err){
      loadingFactory.hide();
    });

  $scope.to_trusted = function(html_code) {
      return $sce.trustAsHtml(html_code);
 }

 /********  Privacy Terms Starts Here ********/

 
  // function toggleIcon(e) {
  //     $(e.target)
  //         .prev('.privacyTerms .panel-heading')
  //         .find(".more-less")
  //         .toggleClass('fa-plus fa-minus');
  // }
  // $('.panel-group').on('hidden.bs.collapse', toggleIcon);
  // $('.panel-group').on('shown.bs.collapse', toggleIcon);


  /******** Privacy Terms **********/


});

