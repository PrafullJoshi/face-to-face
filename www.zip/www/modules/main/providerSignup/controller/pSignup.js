face2face.controller("pSignUpCtrl", ['$scope', '$rootScope', '$http', '$window', 'globalConstants', 'serverRequestFactory', '$state', '$injector', '$compile', '$timeout', 'validatePass', 'requiredFactory', 'otherValidationCheck', 'Scopes', 'validateDate', function($scope, $rootScope, $http, $window, globalConstants, serverRequestFactory, $state, $injector, $compile, $timeout, validatePass, requiredFactory, otherValidationCheck, Scopes, validateDate) {
  // var $validationProvider = $injector.get('$validation');
  $scope.data = {};
  $scope.data.deaNo = "";
  var promise;
  $scope.errmsg = "";
  $scope.dobErr = '';
  $scope.npiExpErr = '';
  $scope.deaExpErr = '';
  $scope.dateerrMsg = "";
  $scope.data.unameErr = "";
  $scope.data.emailErr = "";
  $scope.data.organizationType = "organization";
  $scope.data.photo = "";
  $scope.invalid = false;
  $scope.data.title = '';
  var photoObj;
  var contractObj;
  $scope.licstates = [];
  $scope.states_lic = {};
  var plans = [];
  $scope.contractErr = "";
  $scope.licstateErr = "licstateErr";
  promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.downloadlink, 'GET', {});
  promise.then(function(res) {
    if (res.data.status == true && res.data.data != "None") {
        $('#loader').hide();
        $scope.data.downloadlink = res.data.data;
        // $scope.downloadlink = "https://face2face-dev.s3.amazonaws.com/profileImage/57ee37cec0211.jpeg";
    } else {
        $('#loader').hide();
    }
  }, function(err) {
      $('#loader').hide();
  });
  $scope.titles = [{name:"Mr."},{name:"Miss"},{name:"Dr."},{name:"Mrs."}];
  // create a random key
  $scope.createCaptcha = function() {
            $scope.captchaText = "";
            $scope.cap.captcha = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var possibleNumer = "012345";
            for (var i = 0; i <= 5; i++)
                $scope.captchaText += possible.charAt(Math.floor(Math.random() * possible.length));
            $scope.capStyle = globalConstants.captchaStyle[possibleNumer.charAt(Math.floor(Math.random() * possibleNumer.length))];
        }
        // }
    if ($state.current.name === "main.pSignUp1") {
        $window.scrollTo(0, 0);
        if ($rootScope.previousState === "main.pSignUp2" || $rootScope.previousState === "") {
            // Do nothing
        } else {
            localStorage.clear();
        }
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.providerType, 'GET', {});
        promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.providerTypeData = res.data.data;
                $scope.passValid = {};
                $scope.data.provider_type_id = localStorage.provider_type_id;
                $scope.passValid.email = localStorage.email;
                $scope.passValid.username = localStorage.username;
                $scope.passValid.password = localStorage.password;
                $scope.passValid.confirm_password = localStorage.confirm_password;
                $scope.data.fname = localStorage.fname;
                $scope.data.lname = localStorage.lname;
                $scope.data.title = localStorage.title;
                $scope.data.gender = localStorage.gender;
                $scope.data.dob = localStorage.dob;
                $scope.data.ssn_no = localStorage.ssn_no;
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });
    }
    if ($state.current.name === "main.pSignUp2") {
        $window.scrollTo(0, 0);
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStates, 'GET', {});
        promise.then(function(res) {

            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.statesData = res.data.data;
                $scope.data.state_id = localStorage.state_id;
                $scope.data.city = localStorage.city;
                $scope.data.address1 = localStorage.address1;
                $scope.data.address2 = localStorage.address2;
                $scope.data.zip = localStorage.zip;
                $scope.data.home_phone = localStorage.home_phone;
                $scope.data.home_fax = localStorage.home_fax;
                $scope.data.office_phone = localStorage.office_phone;
                $scope.data.office_fax = localStorage.office_fax;
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });
    }
    if ($state.current.name === "main.pSignUp3") {
        $window.scrollTo(0, 0);
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getSpecialities + "provider_type_id=" + localStorage.provider_type_id, 'GET', {});
        promise.then(function(res) {
            // console.log(res)
            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.photoErr = "";
                $scope.specialitiesData = res.data.data;
                $scope.data.bio = localStorage.bio;
                $scope.data.photo_name = localStorage.photo_name;
                $scope.data.speciality_id = localStorage.speciality_id;
                $scope.data.speciality_experience = localStorage.speciality_experience;
                if (localStorage.individual == 'individual') {
                    $scope.data.organizationType = localStorage.individual;
                    $scope.organizationName = true;
                }
                $scope.data.organization_name = localStorage.organization_name;
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });
    }
    if ($state.current.name === "main.pSignUp4") {
        $window.scrollTo(0, 0);
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStates, 'GET', {});
        promise.then(function(res) {
            //console.log(res)
            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.licstatesData = res.data.data;
                // $scope.licstatesData = {"0" :"NYC",
                // "1":"CF"};
                $scope.data.bio = localStorage.bio;
                $scope.data.npi_number = localStorage.npi_number;
                $scope.data.npi_number_expiration = localStorage.npi_number_expiration;
                $scope.data.dea_number = localStorage.dea_number;
                $scope.data.dea_number_expiration = localStorage.dea_number_expiration;
                $scope.data.contract_document_name = localStorage.contract_document_name;
                // $scope.stateNLicense = localStorage.storestateNLicense;
                if (localStorage.storestateNLicense) {
                    $scope.stateNLicense = JSON.parse(localStorage.storestateNLicense);
                } else {
                    $scope.stateNLicense = [{
                        html: '<div class="state-input clearfix"><div class="col-sm-6 col-xs-6"><select name="state1" class="form-control" id="lstate_id1" ng-model="stateNLicense[$index].state" is-required formelemname="state1" messageid = "{{licstateErr + $index}}"><option value="">Select</option><option value="{{key}}" ng-repeat="(key,value) in licstatesData">{{value}}</option></select></div><div class="col-sm-6 col-xs-6"><input name="license1-info" id="license_number1" class="form-control" is-required formelemname="license1-info" messageid = "{{licstateErr + $index}}" alphanumeric-only="alphanumeric" limit-to="15" max-min minl="0" maxl="15" ng-model="stateNLicense[$index].license" placeholder="License Number" type="text"><span class="mandatory">*</span></div><div class="errorMsg"><span id="{{licstateErr + $index}}"></span></div></div>',
                        state: '',
                        license: ''
                    }, {
                        html: '<div class="state-input clearfix"><div class="col-sm-6 col-xs-6"><select name="{{index}}" class="form-control" ng-model="stateNLicense[$index].state" ><option value="">Select</option><option value="{{key}}" ng-repeat="(key,value) in licstatesData">{{value}}</option></select></div><div class="col-sm-6 col-xs-6"><input name="{{$index}}" class="form-control" alphanumeric-only="alphanumeric" limit-to="15" placeholder="License Number" ng-model="stateNLicense[$index].license" type="text"></div><a class="add-remove-btn fa fa-plus-circle add" title="Add" ng-click="addFields()">Add</a><a class="add-remove-btn fa fa-minus-circle remove" title="Remove" ng-if="$index < (stateNLicense.length-1)" ng-click="removeFields($index)">Remove</a><div class="errorMsg"><span id="{{licstateErr + $index}}"></span></div></div>',
                        state: '',
                        license: ''
                    }];
                }
                $compile($scope.stateNLicense)($scope);
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });
    }
    if ($state.current.name === "main.pSignUp5") {
        $window.scrollTo(0, 0);
        if (localStorage.checkBoxinfo && $rootScope.previousState != "main.pSignUp4") {
            $scope.statesData = JSON.parse(localStorage.checkBoxinfo);
        } else {
            var state = JSON.parse(localStorage.states_lic);
            var l = state.length;
            var state_idArr = [];
            for (var i = 0; i < l; i++) {
                stateId = parseInt(state[i].state_id);
                if (!!stateId) {
                    state_idArr.push(stateId);
                }
            }
            promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getInsurance, 'POST', {
                "state_idArr": state_idArr
            });
            promise.then(function(res) {
                //console.log(res)
                if (res.data.status == true && res.data.data != "None") {
                    $('#loader').hide();
                    $scope.statesData = res.data.data;
                } else {
                    $('#loader').hide();
                }
            }, function(err) {
                $('#loader').hide();
            });
        }
    }
    if ($state.current.name === "main.pSignUp6") {
        $window.scrollTo(0, 0);
        $scope.cap = {
            captcha: ''
        }
        $scope.createCaptcha();
    }
    $scope.savePage1 = function() {
        $window.localStorage["provider_type_id"] = $scope.data.provider_type_id;
        $window.localStorage["email"] = $scope.passValid.email;
        $window.localStorage["username"] = $scope.passValid.username;
        $window.localStorage["password"] = $scope.passValid.password;
        $window.localStorage["confirm_password"] = $scope.passValid.confirm_password;
        $window.localStorage["fname"] = $scope.data.fname;
        $window.localStorage["lname"] = $scope.data.lname;
        if(!!$scope.data.title){
            $window.localStorage["title"] = $scope.data.title;
        }else{
            $window.localStorage["title"] = "";
        }
        $window.localStorage["gender"] = $scope.data.gender;
        $window.localStorage["dob"] = $scope.data.dob;
        $window.localStorage["ssn_no"] = $scope.data.ssn_no;
    }
    $scope.savePage2 = function() {
        $window.localStorage["state_id"] = $scope.data.state_id;
        $window.localStorage["city"] = $scope.data.city;
        $window.localStorage["address1"] = $scope.data.address1;
        if($scope.data.address2){
            $window.localStorage["address2"] = $scope.data.address2;
        }else{
            $window.localStorage["address2"] = "";
        }
        $window.localStorage["zip"] = $scope.data.zip;
        if (!!$scope.data.home_phone) {
            $window.localStorage["home_phone"] = $scope.data.home_phone;
        } else {
            $window.localStorage["home_phone"] = "";
        }
        if ($scope.data.home_fax) {
            $window.localStorage["home_fax"] = $scope.data.home_fax;
        } else {
            $window.localStorage["home_fax"] = "";
        }
        if ($scope.data.office_phone) {
            $window.localStorage["office_phone"] = $scope.data.office_phone;
        } else {
            $window.localStorage["office_phone"] = "";
        }
        if ($scope.data.office_fax) {
            $window.localStorage["office_fax"] = $scope.data.office_fax;
        } else {
            $window.localStorage["office_fax"] = "";
        }
    }
    $scope.savePage3 = function(photo) {
        $window.localStorage["speciality_id"] = $scope.data.speciality_id;
        $window.localStorage["photo"] = photo;
        if (!!$scope.data.bio) {
            $window.localStorage["bio"] = $scope.data.bio;
        } else {
            $window.localStorage["bio"] = "";
        }
        if (!!$scope.data.photo_name) {
            $window.localStorage["photo_name"] = $scope.data.photo_name;
        } else {
            $window.localStorage["photo_name"] = "";
        }
        if (!!$scope.data.speciality_experience) {
            $window.localStorage["speciality_experience"] = $scope.data.speciality_experience;
        } else {
            $window.localStorage["speciality_experience"] = "";
        }
        if ($scope.data.organizationType == "individual") {
            $window.localStorage["individual"] = $scope.data.organizationType;
            $window.localStorage["organization_name"] = "";
        } else {
            $window.localStorage["individual"] = $scope.data.organizationType;
            $window.localStorage["organization_name"] = $scope.data.organization_name;
        }
        // if(!!$scope.data.organization_name){
        // } else {
        // $window.localStorage["organization_name"] = "";
        // }
    }
    $scope.savePage4 = function() {
        if (!!$scope.data.contract) {
            $window.localStorage["contract"] = $scope.data.contract;
        } else {
            $window.localStorage["contract"] = "";
        }
        if (!!$scope.licstates) {
            $window.localStorage["states_lic"] = JSON.stringify($scope.licstates);
        }
        if (!!$scope.data.npi_number) {
            $window.localStorage["npi_number"] = $scope.data.npi_number;
        } else {
            $window.localStorage["npi_number"] = "";
        }
        if (!!$scope.data.npi_number_expiration) {
            $window.localStorage["npi_number_expiration"] = $scope.data.npi_number_expiration;
        } else {
            $window.localStorage["npi_number_expiration"] = "";
        }
        if (!!$scope.data.dea_number) {
            $window.localStorage["dea_number"] = $scope.data.dea_number;
        } else {
            $window.localStorage["dea_number"] = "";
        }
        if (!!$scope.data.dea_number_expiration) {
            $window.localStorage["dea_number_expiration"] = $scope.data.dea_number_expiration;
        } else {
            $window.localStorage["dea_number_expiration"] = "";
        }
        if (!!$scope.data.contract_document_name) {
            $window.localStorage["contract_document_name"] = $scope.data.contract_document_name;
        } else {
            $window.localStorage["contract_document_name"] = "";
        }
    }
    $scope.savePage5 = function() {
        if (!!$scope.data.npi_number) {
            $window.localStorage["npi_number"] = $scope.data.npi_number;
        } else {
            $window.localStorage["npi_number"] = "";
        }
        if (!!$scope.data.npi_number_expiration) {
            $window.localStorage["npi_number_expiration"] = $scope.data.npi_number_expiration;
        } else {
            $window.localStorage["npi_number_expiration"] = "";
        }
        if (!!$scope.data.dea_number) {
            $window.localStorage["dea_number"] = $scope.data.dea_number;
        } else {
            $window.localStorage["dea_number"] = "";
        }
        if (!!$scope.data.dea_number_expiration) {
            $window.localStorage["dea_number_expiration"] = $scope.data.dea_number_expiration;
        } else {
            $window.localStorage["dea_number_expiration"] = "";
        }
        if (!!$scope.data.contract_document_name) {
            $window.localStorage["contract_document_name"] = $scope.data.contract_document_name;
        } else {
            $window.localStorage["contract_document_name"] = "";
        }
    }
    $scope.page1next = function(form) {
        if (validateDate.validateDt($scope.data.dob, 'providerDOB').flag && requiredFactory.validateBeforeSubmit(form, $scope) && otherValidationCheck.validateBeforeSubmit() && $scope.dobErr == "") {
            var validatePassRes = validatePass.validate($scope.passValid.password, $scope.passValid.confirm_password, $scope.passValid.email, $scope.passValid.username);
            if (validatePassRes.flag == true) {
                var promise;
                promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.checkUniqueUserandEmail, 'POST', {
                    username: $scope.passValid.username,
                    email: $scope.passValid.email
                });
                promise.then(function(res) {
                    //console.log(res)
                    if (res.data.status == true && res.data.data == "None") {
                        $('#loader').hide();
                        $scope.data.unameErr = "";
                        $scope.data.emailErr = "";
                        $scope.savePage1();
                        $state.go('main.pSignUp2');
                    } else {
                        $('#loader').hide();
                        //console.log();
                        $scope.data.emailErr = "";
                        $scope.data.unameErr = "";
                        if (!!res.data.message.username) {
                            $scope.data.unameErr = "Already exist";
                        }
                        if (!!res.data.message.email) {
                            $scope.data.emailErr = "Already exist"
                        }
                    }
                }, function(err) {
                    $('#loader').hide();
                });
            }
        }
    }
    $scope.page2next = function(form) {
        if (requiredFactory.validateBeforeSubmit(form, $scope) && otherValidationCheck.validateBeforeSubmit()) {
            $scope.savePage2();
            $state.go('main.pSignUp3');
        }
    }
    $scope.page3next = function(form) {
        $scope.data.orgErr = "";
        if ($scope.data.organizationType == 'organization') {
            if ($scope.data.organization_name == undefined || $scope.data.organization_name == "") {
                $scope.data.orgErr = "This field is required."
            } else {
                $scope.data.orgErr = "";
            }
        }
        if (requiredFactory.validateBeforeSubmit(form, $scope) && $scope.data.orgErr == "" && $scope.photoErr == "") {
            // var promise;
            //console.log(photoObj)
            if (photoObj) {
                promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.uploadProfileImage, 'POST', {
                    "photoObj": photoObj
                });
                promise.then(function(res) {
                    //console.log(res)
                    if (res.data.status == true) {
                        $('#loader').hide();
                        // $scope.savePage3(res.data.data.photo);
                        $scope.data.photo = res.data.data;
                        $scope.savePage3($scope.data.photo);
                        $state.go('main.pSignUp4')
                    } else {
                        $('#loader').hide();
                        $scope.photoErr = "Image unable to upload";
                    }
                }, function(err) {
                    $('#loader').hide();
                });
            } else {
                $scope.savePage3("");
                $state.go('main.pSignUp4')
            }
        }
    }
    $scope.page4next = function(form) {
        var count = 0;
        //console.log($scope.stateNLicense)
        for(var i=1; i<$scope.stateNLicense.length; i++){
            for(var j=0; j<i; j++){
                if(!!$scope.stateNLicense[i].state && !!$scope.stateNLicense[i].license || $scope.stateNLicense[i].state == "" && $scope.stateNLicense[i].license == "" || $scope.stateNLicense[i].state == "" && $scope.stateNLicense[i].license == undefined){
                    if($scope.stateNLicense[j].state == $scope.stateNLicense[i].state && !!$scope.stateNLicense[i].state){
                        document.getElementById("licstateErr"+i).innerHTML = "States can't be same";
                        count++;
                        break;
                    } else{
                        document.getElementById("licstateErr"+i).innerHTML = "";
                    }
                }
                else if(!!$scope.stateNLicense[i].state && $scope.stateNLicense[i].license == "" || !!$scope.stateNLicense[i].state && $scope.stateNLicense[i].license == undefined || $scope.stateNLicense[i].state == "" && !!$scope.stateNLicense[i].license) {
                    if($scope.stateNLicense[i].state == ""){
                        document.getElementById("licstateErr"+i).innerHTML = "Please select the State";
                        count++;
                    } else{
                        document.getElementById("licstateErr"+i).innerHTML = "Please entered the license number";
                        count++;
                    }
                }
            }
        }
        if (requiredFactory.validateBeforeSubmit(form, $scope) && count<=0 && $scope.contractErr == "" && $scope.npiExpErr == "" && $scope.deaExpErr == "") {
            $scope.npiErr = "";
            if (validateDate.validateDt($scope.data.npi_number_expiration, 'npiExpDOB').flag && validateDate.validateDt($scope.data.dea_number_expiration, 'deaExpDOB').flag) {
                promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.verifyNpi + $scope.data.npi_number, 'GET', {});
                promise.then(function(res) {
                    if (res.data.status == true) {
                        $scope.npiErr = "";
                        $('#loader').hide();
                        beforepage4nextfinal(form);
                    } else {
                        $('#loader').hide();
                        $scope.npiErr = "Invalid Npi number"
                    }
                }, function(err) {
                    $('#loader').hide();
                });
            }
        }
    }

    function beforepage4nextfinal(form) {
        if (contractObj && $scope.npiErr == "") {
            promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.uploadContract, 'POST', {
                "photoObj": contractObj
            });
            promise.then(function(res) {
                if (res.data.status == true) {
                    // $scope.savePage3(res.data.data.photo);
                    $scope.data.contract = res.data.data;

                    $('#loader').hide();
                    page4nextFinal(form);
                } else {
                    $('#loader').hide();
                    $scope.contractErr = "File unable to upload";
                }
            }, function(err) {
                $('#loader').hide();
            });
        } else {
            page4nextFinal(form);
        }
    }

    function page4nextFinal(form) {
        if(requiredFactory.validateBeforeSubmit(form, $scope) && $scope.npiErr == "" && $scope.contractErr == "" && $scope.npiExpErr == "" && $scope.deaExpErr == "") {
            var l = $scope.stateNLicense.length;
            $window.localStorage["storestateNLicense"] = JSON.stringify($scope.stateNLicense);
            for(var i = 0; i < l; i++) {
                if(!!$scope.stateNLicense[i].state){
                    $scope.licstates.push({
                    'state_id': $scope.stateNLicense[i].state,
                    'license_number': $scope.stateNLicense[i].license
                });
                    
                }
            }
            // $window.localStorage["states_lic"] = JSON.stringify($scope.licstates);
            $scope.savePage4();
            $state.go("main.pSignUp5");
        }
    }
    $scope.page5next = function() {
        $window.localStorage["checkBoxinfo"] = JSON.stringify($scope.statesData);
        var license_and_insurances = JSON.parse(localStorage.states_lic);
        var provider_license_and_insurances = [];
        //console.log("plans : ", plans);
        //console.log("plans : ", license_and_insurances.length);
        if (plans.length > 0) {
            for (var i = 0; i < license_and_insurances.length; i++) {
                var planId = [];
                for (j = 0; j < plans.length; j++) {
                    if (license_and_insurances[i].state_id == plans[j].state_id) {
                        planId.push(plans[j].id);
                    } 
                }
                provider_license_and_insurances.push({
                    "state_id": license_and_insurances[i].state_id,
                    "license_number": license_and_insurances[i].license_number,
                    "insurance_plan_id": planId
                })
            }
            //console.log(provider_license_and_insurances);
        } 
        else {
            for (j = 0; j < license_and_insurances.length; j++) {
                provider_license_and_insurances.push({
                    "state_id": license_and_insurances[j].state_id,
                    "license_number": license_and_insurances[j].license_number,
                    "insurance_plan_id": []
                })
            }
        }
        $window.localStorage["provider_license_and_insurances"] = JSON.stringify(provider_license_and_insurances);
        $state.go("main.pSignUp6")
    }
    $scope.checkedValue = function(obj) {
        if (obj.checked) {
            var data = {
                "state_id": obj.state_id,
                "id": obj.id
            };
            plans.push(data);
        }
    }

    $scope.page6next = function(form) {
        if (requiredFactory.validateBeforeSubmit(form, $scope)) {
            var capText = $scope.captchaText;
            $scope.cap.captcha = ($scope.cap.captcha).toLowerCase();
            capText = (capText).toLowerCase();
            if (capText != $scope.cap.captcha) {
                $scope.errCapMssg = globalConstants.errorMessages.wrongCaptcha;
            } else {
                var promise;
                promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.providerSignup, 'POST', {
                    "title": localStorage.title,
                    "fname": localStorage.fname,
                    "lname": localStorage.lname,
                    "email": localStorage.email,
                    "username": localStorage.username,
                    "password": localStorage.password,
                    "confirm_password": localStorage.confirm_password,
                    "photo": localStorage.photo,
                    "photo_name": localStorage.photo_name,
                    "ssn_no": localStorage.ssn_no,
                    "dob": localStorage.dob,
                    "gender": localStorage.gender,
                    "terms_of_use": 1,
                    "provider_license_and_insurances": JSON.parse(localStorage.provider_license_and_insurances),
                    "provider_profile": {
                        "state_id": localStorage.state_id,
                        "provider_type_id": localStorage.provider_type_id,
                        "city": localStorage.city,
                        "address1": localStorage.address1,
                        "address2": localStorage.address2,
                        "zip": localStorage.zip,
                        "home_phone": localStorage.home_phone,
                        "home_fax": localStorage.home_fax,
                        "office_phone": localStorage.office_phone,
                        "office_fax": localStorage.office_fax,
                        "bio": localStorage.bio,
                        "speciality_id": localStorage.speciality_id,
                        "speciality_experience": localStorage.speciality_experience,
                        "individual": localStorage.individual,
                        "organization_name": localStorage.organization_name,
                        "npi_number": localStorage.npi_number,
                        "npi_number_expiration": localStorage.npi_number_expiration,
                        "dea_number": localStorage.dea_number,
                        "dea_number_expiration": localStorage.dea_number_expiration,
                        "contract": localStorage.contract,
                        "contract_document_name": localStorage.contract_document_name
                    }
                });
                promise.then(function(res) {
                    if (res.data.status == true && res.data.data == "None") {
                        $('#loader').hide();
                        $state.go("main.thankYou");
                    } else {
                        $('#loader').hide();
                        $state.go("main.error");
                    }
                }, function(err) {
                    $('#loader').hide();
                    $state.go("main.error");
                });
            }
        }
    }
    $scope.init = function() {}
    $scope.init();
    $scope.page2pre = function() {
        // $scope.savePage2();
        $state.go("main.pSignUp1");
    }
    $scope.addFields = function() {
        var fields = {};
        fields.html = '<div class="state-input clearfix"><div class="state-input clearfix"><div class="col-sm-6 col-xs-6"><select name="{{$index}}" class="form-control" ng-model="stateNLicense[$index].state"><option value="">Select</option><option value="{{key}}" ng-repeat="(key,value) in licstatesData">{{value}}</option></select></div><div class="col-sm-6 col-xs-6"><input name="{{$index}}" alphanumeric-only="alphanumeric" limit-to="15"class="form-control" placeholder="License Number" ng-model="stateNLicense[$index].license" type="text"></div><a class="add-remove-btn fa fa-plus-circle add" title="Add" ng-click="addFields()">Add</a><a class="add-remove-btn fa fa-minus-circle remove" title="Remove" ng-if="$index < (stateNLicense.length-1)" ng-click="removeFields($index)">Remove</a><div class="errorMsg"><span id="{{licstateErr + $index}}"></span></div></div>';
        $scope.stateNLicense.push({
            html: fields.html,
            state: '',
            license: ''
        });
        $compile(fields.html)($scope);
    }
    $scope.removeFields = function(index) {
        $scope.stateNLicense.splice(index, 1);
    }
    $scope.uploadDocFile = function(file) {
        $scope.photoErr = "";
        //file.type.split(/).indexOf('image');
        if ($state.current.name == 'main.pSignUp3') {
            var validFormats = ['jpg', 'img', 'jpeg', 'png', 'bmp'];
            $scope.data.photo_name = file.name;
            var size = file.size / 1000000; // file size in mB
            var ext = $scope.data.photo_name.substring($scope.data.photo_name.lastIndexOf('.') + 1).toLowerCase();
            if (validFormats.indexOf(ext) === -1 || size > 5) {
                if (size > 5) {
                    $scope.photoErr = "Image size can not exceed 5 mB";
                } else {
                    $scope.photoErr = "Image format should be jpeg, jpg, img, bmp and png";
                }
            } else {
                var fileReader = new FileReader();
                fileReader.readAsDataURL(file);
                fileReader.onload = function(e) {
                    file.dataUrl = e.target.result; /*add dataUrl to file properties*/

                    photoObj = file.dataUrl;

                }
            }
        } else if ($state.current.name == 'main.pSignUp4') {
            $scope.contractErr = "";
            var size = file.size / 1000000; // file size in mB
            if (file.name.indexOf('pdf') != -1 && size < 2) {
                $scope.data.contract_document_name = file.name;
                // contractObj = file;
                var fileReader = new FileReader();
                fileReader.readAsDataURL(file);
                fileReader.onload = function(e) {
                    file.dataUrl = e.target.result; /*add dataUrl to file properties*/

                    contractObj = file.dataUrl;

                }
            } else {
                $scope.data.contract_document_name = file.name;
                $scope.contractErr = "File format should be pdf and not more than 2mb.";
            }
        }
    };
   
    $scope.organizationChange = function() {
            if ($scope.data.organizationType === "individual") {
                $scope.organizationName = true;
            } else {
                $scope.organizationName = false;
            }
        }
        // $scope.downloadContract = function(){
        // }
    $('#captchaText').bind("cut copy paste drag ", function(e) {
        e.preventDefault();
    });
    $('#captchaText').on("dragstart", function() {
        return false;
    });
}]);