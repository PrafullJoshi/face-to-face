face2face.controller("webinarListingCtrl",function($scope, $state, serverRequestFactory,globalConstants,$window,$location,Socialshare,requiredFactory,$stateParams,$rootScope) {
  $('.navbar-nav a.active').removeClass('active');
  var pageno = 1;
  $scope.loadMore = false;
  if(localStorage.userData){
      var userData = JSON.parse(localStorage.userData),
      userType = userData.userTypeId,
      token = userData.token;
     }
 
  $scope.getWebinar = function(){
    pageno = 1;
    var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinar+'?filter_by='+$scope.filterby+'&search_by='+$scope.searchKey+'&sort_by='+$scope.sortby+'&categories_by='+$scope.webinarType+'&limit=6'+'&timezone='+timeZone(), 'GET', {},token);
    promise.then(function(res){
      $('#loader').hide();
      if(res.data.status && res.data.data!="None"){
        $scope.webinarsList = res.data.data.webinar;
        $scope.totalWebinar = res.data.data.total_count;
        if($scope.totalWebinar > $scope.webinarsList.length){
          $scope.loadMore = true;
        }else{
           $scope.loadMore = false;
        }
      } else {
        $scope.webinarsList = [];
        $scope.loadMore = false;
        $('#loader').hide();
      }
    })
  }
  $scope.init = function(){
    $window.scrollTo(0,0);
    $scope.gridView = true;
    $scope.filterby = 'All';
    $scope.searchKey = '';
    $scope.sortby = '';
    $scope.webinarUpdates = 'N';
    $scope.webinarCouponCode = '';
    $scope.data = {};
    $scope.data.webinarCouponCode = '';
    $scope.data.prowebinarUpdates = 'N';
    $scope.data.proacceptTerms = 'N';
    $scope.webinarType = $stateParams.webinarType ? $stateParams.webinarType : 'Future';
    $scope.webinarTypeArray = {"Future" : "Upcoming Webinars","Past" : "Past Webinars"};
    
    $scope.getWebinar();
  }

  $scope.loadMoreWebinar = function(){
    pageno++;
    promiseRes = serverRequestFactory.serverComm(globalConstants.serviceUrl.getWebinar+'?filter_by='+$scope.filterby+'&search_by='+$scope.searchKey+'&sort_by='+$scope.sortby+'&categories_by='+$scope.webinarType+'&limit=6&page='+pageno, 'GET', {});
    promiseRes.then(function(res) {
      if (res.data.status == true && res.data.data != "None") {
        $('#loader').hide();
        $scope.webinarsList = $scope.webinarsList.concat(res.data.data.webinar);
        if($scope.totalWebinar > $scope.webinarsList.length){
          $scope.loadMore = true;
        }else{
           $scope.loadMore = false;
        }
      } else {
        $scope.courses = [];
        $scope.loadMore = false;
        $('#loader').hide();
      }
    }, function(err) {
        $('#loader').hide();
    });
  }

  $scope.share =function(type,webinar){
    if(type=='email'){
        var attrs= {
          'socialshareSubject':webinar.fullname,
          'socialshareBody':globalConstants.gHost+'/#'+$location.url(),
        }
      }else if(type=='facebook'){
        var attrs = {
            'socialshareVia':'744272235723774',
            'socialshareUrl': globalConstants.gHost+'/#'+$location.url(),
            'socialshareType':'feed',
            'socialshareText':webinar.fullname,
            //'socialshareMedia':webinar.image,
            // 'socialshareDescription':angular.element(webinar.description).text().substring(0,130),
          }
      }else{
        var attrs =  {
            //'socialshareVia': 'f2f-qa.kiwireader.com/#'+$location.url(),
            'socialshareUrl': globalConstants.gHost+'/#'+$location.url(),
            'socialshareText':webinar.fullname ,
            //'socialshareMedia':webinar.image,
            // 'socialshareDescription':angular.element(webinar.description).text(),
          }
      }
    Socialshare.share({
      'provider': type,
      'attrs': attrs,
    })
  }

  $scope.viewChange = function(form){
    if(form=="grid"){
      $scope.gridView = true;
    }else{
      $scope.gridView = false;
    }
  }

  $scope.formatDate = function(start_date){
    return moment(start_date).format('MMMM DD, YYYY')
  }
  
  $scope.formatTime = function(start_date){
    return moment(start_date).format('LT')
  }

  $scope.getRegisteredWebinarStatus = function(webinar){
    $scope.webinarDetail = webinar; //for localStorage
    $scope.webinarId = webinar.id;
    $scope.webinarPrice = webinar.cost;
    $scope.webinarTopic = webinar.topic;
    if(webinar.webinar_type == 'Future'){
      if(token){
        var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.getRegisteredWebinarStatus+"webinar_id="+webinar.id, 'GET', {},token);
        promise.then(function(res){
            if(res.data.status && res.data.data!="None"){
                $('#loader').hide();
                afterLogin(res.data.data);
            }else{
                $('#loader').hide();
          }
        }, function(err) {
            $('#loader').hide();
        })
      }else{
        $('#webinarModal').modal('show');
        $scope.loginModal = true;
        $scope.registerWebinarModal = false;
        $scope.termAndCondModal = false;
        $scope.addCardModal = false;
        $scope.updateCardModal = false;
        $scope.successModal = false;
        $scope.signupModal = false;
        $scope.providerCardModal = false;
      }
      
    }
    
  }

  //For default popup open after signup

  if(token && userType == 2 && localStorage.webinardetailForRegister && $rootScope.previousState === "main.thankYou"){
    var webinardetail = JSON.parse(localStorage.webinardetailForRegister);
    $scope.getRegisteredWebinarStatus(webinardetail);
  }
  
  $scope.buttonText = function(type,register){
    if(type=="Future"){
      if(register == true){
        return 'Registered';
      }else{
        return 'Register';
      }
    }else{
      return 'Watch';
    }
  }


  $scope.login = function(form) {
    if(requiredFactory.validateBeforeSubmit(form, $scope)) {
        var promise;
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.login, 'POST', {
            'username': $scope.data.userEmail,
            'password': $scope.data.pass,
            'webinar_id' : $scope.webinarId 
        });
        promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
            $('#loader').hide();
            $scope.showserviceMsg = false;
            var cusData = res.data.data;
            var loginData = {
              "fname"      : cusData.fname,
              "lname"      : cusData.lname,
              "email"      : cusData.email,
              "username"   : cusData.username,
              "token"      : cusData.token,
              "userTypeId" : cusData.user_type_id,
              "userId"     : cusData.id
            };
            token = cusData.token;
            userType = cusData.user_type_id;
            $window.localStorage['userData'] = JSON.stringify(loginData);
            if(cusData.user_type_id == 1){
              if(cusData.status == 'Suspended' || cusData.status == 'Pending'){
                $window.localStorage["providerStatus"] = cusData.status;
                $state.go('providerMain.providerDashboard');
              }else{
                afterLogin(cusData.webinarAlreadyPurchased);
              }
            }else{
              if(cusData.notifications.ConsultTransaction == true && cusData.notifications.SubscriptionExpiry == true && cusData.notifications.SubscriptionTransaction == true){
                afterLogin(cusData.webinarAlreadyPurchased);
              } else{
                $window.localStorage["consPopup"] = JSON.stringify(cusData.notifications);
                $state.go('patientMain.dashboard');
              }
            }

          }else{
            $scope.showserviceMsg = true;
            $scope.serviceMsgs = "Invalid Username or Password";
            $('#loader').hide();
          }
        },function(err){
          $scope.showserviceMsg = true;
        $scope.serviceMsgs = "Oops!! Something went wrong";
        $('#loader').hide();
        });
                   
        }
    }

    $scope.signupAction = function(){
      $scope.signupModal = true;
      $scope.loginModal = false;
      $scope.termAndCondModal = false;
      $scope.registerWebinarModal = false;
      $scope.addCardModal = false;
      $scope.updateCardModal = false;
      $scope.successModal = false;
      $scope.providerCardModal = false;
    }

    $scope.patientSignup = function(){
      $window.localStorage['webinardetailForRegister'] = JSON.stringify($scope.webinarDetail); 
      $state.go('main.patientSignUp',{'from' : 'webinarListing'});
    }

    //card Payment start here 

    $window.Stripe.setPublishableKey(globalConstants.stripeKey);
    if(userType == 1){
      $scope.noCards = 'Provider';
    }else{
      $scope.noCards = '';
    }
    $scope.couponApplied = false;
    $scope.cardInfoUpd = {};
    $scope.cardInfo = {};
    $scope.list={};
    $scope.list.months= [1,2,3,4,5,6,7,8,9,10,11,12];
    $scope.list.year = addYears();
    $scope.plan = {};
    $scope.acceptTerms = 'N';
    function addYears(){
     
     var dd = new Date();
     dd = dd.getFullYear();
     var oldYr = dd;
     var yr = [];
     /*for(o = 30;o > 1 ;o--){
         yr.push(--oldYr);
     } */
     yr.push(dd);
     for(o = 1;o <30 ;o++){
         yr.push(++dd);
     } 

     return yr.sort();
  }
    // gets the state list from the api
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStateList,'GET');  
    promise.then(function(res){
     if(res.data.status == true){
      
       $scope.plan.stateList =  res.data.data;
      $('#loader').hide();

     }else if(res.status == false){
        $('#loader').hide();
     }


    },function(err){

    })

    var getCards = function(){
      $scope.noCards = '';
      $scope.listofcards = [];
      var promiseforCards = serverRequestFactory.serverComm(globalConstants.serviceUrl.stripCardList,'POST',{},token);  // get the consumer detail list  
      promiseforCards.then(function(res){
      var res = res.data;
     
      if(res.status == true && res.data != "None"){
        $('#loader').hide();                                   
        var result = res.data;
        for(var i = 0;i<result.length;i++){
            $scope.listofcards.push({last4 : result[i].last4, cardNo : 'XXXXXXXXXXXX'+result[i].last4, stripID : result[i].id , selectedid : res.stripe_card_id,month:result[i].exp_month,year:result[i].exp_year});
            if(res.stripe_card_id == result[i].id){
              $scope.list.selectedCard = $scope.listofcards[i];
            }
        }
        
        
       }
       else if(res.data == "None"){
        $scope.noCards = "No card added. Please add a card to continue";
        $('#loader').hide();
       }


      },function(err){ 
        $scope.noSamePlans = 'Oops! some error occured. Please try again later';
        
      })
    }


    function afterLogin(webinarAlreadyPurchased){
        // $('#loginModal').modal('hide');
        $('#alreadyRegisteredModal').modal('hide');
        $('#registrationLimitExceedModal').modal('hide');
        $scope.loggedinUser = true;
        if(webinarAlreadyPurchased.already_purchase_status == true){
          $('#webinarModal').modal('hide');
            $('#alreadyRegisteredModal').modal('show');
        }else{
            if(webinarAlreadyPurchased.max_attendies_status == true){
              $('#webinarModal').modal('hide');
                $('#registrationLimitExceedModal').modal('show');
            }else{
              $('#webinarModal').modal('show');
              $scope.updateCardModal = false;
              $scope.termAndCondModal = false;
              $scope.successModal = false;
              $scope.loginModal = false;
              $scope.signupModal = false;
              $scope.addCardModal = false;
              if(userType == 1){
                if($scope.webinarPrice > 0){
                  $scope.showcardMsg = '';
                  // $scope.providerPayment = true;
                  $scope.providerCardModal = true;
                  $scope.registerWebinarModal = false;
                  $scope.addCardModal = false;
                }else{
                  $scope.registerWebinarModal = true;
                  $scope.providerCardModal = false;
                  $scope.addCardModal = false;
                }
              }else{
                $scope.registerWebinarModal = true;
                $scope.providerCardModal = false;
                $scope.addCardModal = false;
                if($scope.webinarPrice > 0){
                    getCards();
                }
              }
            }
        }
         
    }

    $scope.updateCardIdOnchange = function(id){
      if(id){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateDefaultCard + id ,'GET',{},token,'',true);  // get the consumer detail list  
           promise.then(function(res){
           var res = res.data;
           if(res.status == true){
             
              $('#loader').hide();              
            }
            else if(res.status == false){
             
             $('#loader').hide();
            }


           },function(err){ 

           })
      }
     
    }

    $scope.stripeCallback = function (code, result) {
         $scope.showMsg = false;
         $scope.message = "";
            if (result.error) {
               if(result.error.hasOwnProperty('message')){
               
               $scope.cardErr = result.error.message;
               $scope.showMsg = true;
               console.log(result.error.message);
             }
             else{
               $scope.consData = {
                    name:$scope.cardInfo.name,
                    address_city:$scope.cardInfo.city,
                    address_line1:$scope.cardInfo.address1 ,
                    address_line2:($scope.cardInfo.address2) ? $scope.cardInfo.address2 : ' ',
                    address_state:$scope.cardInfo.state ,
                    address_zip:$scope.cardInfo.zip_code ,
                    cvc:$scope.cardInfo.cvc ,                 
                    exp_month:$scope.cardInfo.exp_month ,
                    exp_year:$scope.cardInfo.exp_year , 
                    number:$scope.cardInfo.number
                  
               }

               if(code == 408){
                 //var othervF1 = otherValidationCheck.validateBeforeSubmit();
                 //if(requiredFactory.validateBeforeSubmit($scope.conFormProf,$scope)){
                  
                   var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',$scope.consData,token);  // get the consumer detail list  
                   promise.then(function(res){
                   var res = res.data;
                   if(res.status == true){
                       $scope.cardInfo.cvc = '';
                       $scope.showMsg = false;
                       $scope.message = "Card has been added successfully"
                       // $('#add-card').modal('hide'); 
                       $scope.registerWebinarModal = true;
                       $scope.addCardModal = false;
                       $scope.updateCardModal = false;
                       $scope.termAndCondModal = false;
                       $scope.successModal = false;
                       $scope.loginModal = false;
                       $scope.signupModal = false;
                        $scope.providerCardModal = false;
                       $('#loader').hide();  
                       getCards(); 
                       $scope.cardInfo = {};

                    }
                    else if(res.status == "error"){
                     $scope.showMsg = true;
                     $scope.cardErr = res.message;
                     window.scrollTo(0,0);
                     $('#loader').hide();
                    }


                   },function(err){ 

                   })


                 //}
               }

               console.log(result.error);
             }
             
               $scope.noSamePlans = result.error.message;
               console.log(result.error.message);

            } else {
                console.log('success! token: ' + result.id);
                  $scope.noSamePlans = '';
                   /* $scope.planData = {
                        plan_id: $scope.planId,
                        newsletter_subsciption_status:$scope.plan.subUpdates,
                        terms_use:$scope.plan.acceptTerms,
                        coupon_code:$scope.plan.couponCode,
                        card:result

                    }*/
                 /*   if($scope.plan.acceptTerms == "Y"){*/
                            // if($scope.planId !== parseInt($window.localStorage.selectedPlId)){
                    var promisePPl = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',result,token);  // get the consumer detail list  
                    promisePPl.then(function(res){
                    var res = res.data;
                    if(res.status == true ){
                          $scope.showMsg = false;
                          $window.localStorage.selectedPlId = res.data.plan_id;  
                        $scope.message = "Card has been added successfully"
                                  // $('#registerWebinarModal').modal('show');
                                  //   $('#add-card').modal('hide'); 
                                    $scope.registerWebinarModal = true;
                                    $scope.addCardModal = false;
                                    $scope.updateCardModal = false;
                                    $scope.termAndCondModal = false;
                                    $scope.successModal = false;
                                    $scope.loginModal = false;
                                    $scope.signupModal = false;
                                     $scope.providerCardModal = false;
                                    $('#loader').hide();
                                    getCards(); 
                              $scope.cardInfo = {};   
                         }
                             else if(res.status == false){
                     $scope.showMsg = true;
                       if(res.hasOwnProperty('message')){
                        $scope.plan.couponCode = '';                                
                        $scope.apiMessage = res.message;
                       }
                        window.scrollTo(0,0);
                       $('#loader').hide(); 
                             }


                            },function(err){ 
                                $scope.noSamePlans = 'Oops! some error occured. Please try again later';
                                
                            })
                                
            }
     
    };

    $scope.stripeCallbackForProvider = function (code, result) {
      $scope.showcardMsg = false;
      $scope.noCards = 'Provider';
      $scope.message = "";
      $scope.acceptTermsErr = '';
      if(!$scope.couponApplied){
        $scope.data.webinarCouponCode = '';
      }else{
        if($scope.couponErr == 'Coupon code applied successfully'){
          $scope.webinarCouponCode = $scope.data.webinarCouponCode;
        }
      }
      
        if(result){
          if(result.error){
            if(result.error.hasOwnProperty('message')){

              $scope.paymentcardErr = result.error.message;
              $scope.showcardMsg = true;
              console.log(result.error.message);
            }
          }else{
            if($scope.data.proacceptTerms == "Y"){
              console.log('success! token: ' + result.id);
              $scope.webinarUpdates = $scope.data.prowebinarUpdates;
              registerWebinar(result.id);
            }else{
              $scope.acceptTermsErr = "Please accept the terms and conditions";
            } 
        } 
      }
    };

$scope.showcardPopup = function(type,form){
  $scope.cardErr ="";
  $scope.conFormProf = form
  if(type === 'add'){
   $scope.addCardModal = true;
   $scope.registerWebinarModal = false;
   $scope.updateCardModal = false;
   $scope.termAndCondModal = false;
   $scope.successModal = false;
   $scope.loginModal = false;
   $scope.signupModal = false;
   $scope.providerCardModal = false;
  }
  else{
   
    if($scope.list.selectedCard){
      $scope.showMsg = false;
     // $scope.list.selectedCard = JSON.parse($scope.list.selectedCard);
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateCard + $scope.list.selectedCard.stripID ,'GET',{},token);  // get the consumer detail list  
                 promise.then(function(res){
                 var res = res.data;
                 if(res.status == "success"){
                      $scope.cardInfoUpd.name = res.response.name;
                      $scope.cardInfoUpd.city = res.response.address_city;
                      $scope.cardInfoUpd.address1 = res.response.address_line1;
                      $scope.cardInfoUpd.address2 = res.response.address_line2;
                      $scope.cardInfoUpd.state = res.response.address_state;
                      $scope.cardInfoUpd.zip_code = res.response.address_zip;
                      $scope.cardInfoUpd.exp_month = JSON.stringify(res.response.exp_month);
                      $scope.cardInfoUpd.exp_year = JSON.stringify(res.response.exp_year);
                      $scope.cardInfoUpd.number = "XXXXXXXXXXXX" + res.response.last4;
                      $scope.cardInfoUpd.cvc = res.response.cvc_check;
                   
                    $('#loader').hide();              
                  }
                  else if(res.status == "error"){
                   $scope.showMsg = true;
                   $scope.cardErr = res.message;
                   window.scrollTo(0,0);
                   $('#loader').hide();
                  }


                 },function(err){ 

                 })
                  // $("#update-card").modal('show');
                $scope.updateCardModal = true;
                $scope.registerWebinarModal = false;
                $scope.addCardModal = false;
                $scope.termAndCondModal = false;
                $scope.successModal = false;
                $scope.loginModal = false;
                $scope.signupModal = false;
                 $scope.providerCardModal = false;
    }
  

  }
}

// $scope.clearForm=function(form){
 
 
// }

$scope.updateCard = function(form){
  $scope.message = "";
  var obj = {
    address_city : $scope.cardInfoUpd.city,
   // address_country : '',
    name : $scope.cardInfoUpd.name,
    address_line1 : $scope.cardInfoUpd.address1,
    address_line2 : ($scope.cardInfoUpd.address2) ? $scope.cardInfoUpd.address2 : ' ',
    address_state : $scope.cardInfoUpd.state,
    address_zip : $scope.cardInfoUpd.zip_code,
    exp_month : $scope.cardInfoUpd.exp_month,
    exp_year : $scope.cardInfoUpd.exp_year,
    card_id : $scope.list.selectedCard.stripID 
  }
   
  if(requiredFactory.validateBeforeSubmit(form,$scope)){
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.submitUpdatedCard ,'POST',obj,token);  // get the consumer detail list  
               promise.then(function(res){
               var res = res.data;
               if(res.status == "success"){
                    $scope.message = "Card has been updated successfully"
                    // $("#update-card").modal('hide');
                    $scope.registerWebinarModal = true;
                    $scope.updateCardModal = false;
                    $scope.addCardModal = false;
                    $scope.termAndCondModal = false;
                    $scope.successModal = false;
                    $scope.loginModal = false;
                    $scope.signupModal = false;
                    $scope.providerCardModal = false;
                  $('#loader').hide();              
                }
                else if(res.status == "error"){
                 $scope.showMsg = true;
                 $scope.cardErr = res.message;
                 window.scrollTo(0,0);
                 $('#loader').hide();
                }


               },function(err){ 

               })
  }
}

    $scope.checkCouponCode = function(event,coupon){
      $scope.providerCouponforWebinar = true;
      $scope.couponErr = "";
      event.stopPropagation();
       var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.webinarCouponCode ,'POST',{
            "coupon_code" : coupon,
            "amount" : $scope.webinarPrice
       },token);  // get the consumer detail list  
       promise.then(function(res){
        $scope.providerCouponforWebinar = false; // for not calling the stripe
       var res = res.data;
          if(res.status == true){
              $scope.couponErr = "Coupon code applied successfully";
              $scope.couponSuccess = true;
                $('#loader').hide(); 
                $scope.couponApplied = true;
                //$scope.afterDiscount = res.data.amount;
           }
           else if(res.status == false){
               $scope.plan.couponCode = '';
                $scope.couponSuccess = false;
               $scope.couponErr = "Invalid coupon code";
                $('#loader').hide();
           }


       },function(err){ 

       })
      }


    $scope.continuePayment = function(){
        if($scope.webinarPrice > 0){
            if(!$scope.couponApplied){
              $scope.webinarCouponCode = '';
            }
            if($scope.list.selectedCard){
              $scope.noCards = '';
                if($scope.acceptTerms == "Y"){
                   registerWebinar($scope.list.selectedCard.stripID);
                } else{
                  $scope.noSamePlans = "Please accept the terms and conditions";
                }
            } else{
                $scope.noCards = "No card added. Please add a card to continue";
                if($scope.acceptTerms != "Y"){
                  $scope.noSamePlans = "Please accept the terms and conditions";
                }else{
                  $scope.noSamePlans = '';
                }
          }
            
        }else{
            if($scope.acceptTerms == "Y"){
              registerWebinar('');
            }else{
              $scope.noSamePlans = "Please accept the terms and conditions";
            }
        }


    }

/*************************************/

function timeZone(){
    var currentTimeZoneOffsetInHours = new Date().getTimezoneOffset() / 60;
    return (currentTimeZoneOffsetInHours);
  }

  
    var registerWebinar = function(stripID){
      if($scope.webinarPrice <= 0){
        $scope.webinarCouponCode = '';
      }
      var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.registerWebinar, 'POST', {
        "webinar_id" : $scope.webinarId,
        "source" : stripID, //stripe id in case of consumer and card token in case of provider
        "coupon_code" : $scope.webinarCouponCode,
        "newsletter_subsciption_status": $scope.webinarUpdates,        
      },token);
      promise.then(function(res){
        $('#loader').hide();
        if(res.data.status && res.data.data!="None"){
          $window.localStorage.removeItem('webinardetailForRegister');
          $scope.successModal = true;
          $scope.termAndCondModal = false;
          $scope.registerWebinarModal = false;
          $scope.addCardModal = false;
          $scope.updateCardModal = false;
          $scope.signupModal = false;
          $scope.providerCardModal = false;
        } else {
          $('#loader').hide();
        }
      })
    }


  $scope.cancelPopup = function(){
    $scope.webinarCouponCode = ''
    $scope.couponErr = "";
    $scope.data = {};
    $scope.cardInfo = {};
    // $('#loginModal').modal('hide');
    $window.localStorage.removeItem('webinardetailForRegister');
    $('#alreadyRegisteredModal').modal('hide');
    $('#registrationLimitExceedModal').modal('hide');
    $('#webinarModal').modal('hide');
    $scope.getWebinar('');
    if(token){
        if(userType == 1){
            $state.go("providerMain.webinarListing",{'webinarType' : $scope.webinarType}); // provider
        }else{
            $state.go("patientMain.webinarListing",{'webinarType' : $scope.webinarType}); // consumer 
        }
    }else{
       $state.go("main.webinarListing",{'webinarType' : $scope.webinarType});
    }
  }

    $scope.termAndCond = function(){
      if(userType == 2){
        $scope.termAndCondModal = true;
        $scope.registerWebinarModal = false;
        $scope.addCardModal = false;
        $scope.updateCardModal = false;
        $scope.successModal = false;
        $scope.loginModal = false;
        $scope.signupModal = false;
        $scope.providerCardModal = false;
        var promise = serverRequestFactory.serverComm('/Pages/webinar-terms-conditions', 'GET', {});
        promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.termAndCondData = res.data.data.page;
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });
      }
    }

    $scope.showWebinarModal = function(){
        $(".errorMsg span").html('');
        $scope.registerWebinarModal = true;
        $scope.termAndCondModal = false;
        $scope.addCardModal = false;
        $scope.updateCardModal = false;
        $scope.successModal = false;
        $scope.loginModal = false;
        $scope.signupModal = false;
        $scope.providerCardModal = false;
    }

  $scope.init();

});