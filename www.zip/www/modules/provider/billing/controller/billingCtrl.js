face2face.controller('providerBillingCtrl', function ($window, $scope, globalConstants, serverRequestFactory, requiredFactory, otherValidationCheck, $state, loadingFactory, toastMsg, commonGetterService, $timeout, showModalService, Scopes) {

    /* get token from local storage */
    var token = commonGetterService.getToken();
    $scope.onDemandAndFareSetting = {};
    var no = globalConstants.defaultValues.No;
    var yes = globalConstants.defaultValues.Yes;


    /**
     * Get Provider Account Settings Details like charges per hour and availability from the server. 
     * @type @exp;serverRequestFactory@call serverComm with url ;
     */
    var getPromiseChargeAvailability = serverRequestFactory.serverComm(globalConstants.serviceUrl.getProviderAccountSetting, "GET", "", token, "", true);
    getPromiseChargeAvailability.then(function (response) {
        var blank = globalConstants.defaultValues.blank;
        if (response.data.status == true && response.data.data != globalConstants.defaultValues.apiBlankData) {
            $scope.onDemandAndFareSetting = response.data.data;
            if($scope.onDemandAndFareSetting.on_demand_insurance_charges == 0) $scope.onDemandAndFareSetting.on_demand_insurance_charges = blank;
            if($scope.onDemandAndFareSetting.on_demand_non_insurance_charges == 0 ) $scope.onDemandAndFareSetting.on_demand_non_insurance_charges = blank;
            if($scope.onDemandAndFareSetting.off_hours_charges == 0 ) $scope.onDemandAndFareSetting.off_hours_charges = blank;
            if($scope.onDemandAndFareSetting.after_hours_charges == 0 ) $scope.onDemandAndFareSetting.after_hours_charges = blank
            if($scope.onDemandAndFareSetting.scheduled_insurance_charges == 0 ) $scope.onDemandAndFareSetting.scheduled_insurance_charges = blank;
            if($scope.onDemandAndFareSetting.scheduled_non_insurance_charges == 0 ) $scope.onDemandAndFareSetting.scheduled_non_insurance_charges = blank;
        } else {
            $scope.onDemandAndFareSetting = {
                on_demand_insurance_charges: blank,
                on_demand_non_insurance_charges: blank,
                off_hours_charges: blank,
                after_hours_charges: blank,
                scheduled_insurance_charges: blank,
                scheduled_non_insurance_charges: blank,
                same_as_on_demand: no,
                is_temporary_unavailable: no,
                on_demand_appointment: yes,
                multiprovider_scheduled_appointment: yes,
                concierge_service: no,
                phone_call: yes,
                video_call: yes,
            };
        }


        $scope.disableNEnableCheckbox();

    });
    var submitChargeAvailability = function (ChargeAvailabilitydata, bankDetails) {
        /**
         * Post Provider Account Settings Details like charges per hour and availability to the server. 
         * @type @exp;serverRequestFactory@call serverComm with url ;
         */
        ChargeAvailabilitydata.id = $scope.onDemandAndFareSetting.id;
        ChargeAvailabilitydata.on_demand_insurance_charges = round(ChargeAvailabilitydata.on_demand_insurance_charges);
        ChargeAvailabilitydata.on_demand_non_insurance_charges = round(ChargeAvailabilitydata.on_demand_non_insurance_charges);
        ChargeAvailabilitydata.off_hours_charges = round(ChargeAvailabilitydata.off_hours_charges);
        ChargeAvailabilitydata.after_hours_charges = round(ChargeAvailabilitydata.after_hours_charges);
        ChargeAvailabilitydata.scheduled_insurance_charges = round(ChargeAvailabilitydata.scheduled_insurance_charges);
        ChargeAvailabilitydata.scheduled_non_insurance_charges = round(ChargeAvailabilitydata.scheduled_non_insurance_charges);
        var postPromiseChargeAvailability = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateProviderAccountSetting, "POST", ChargeAvailabilitydata, token);
        postPromiseChargeAvailability.then(function (response) {
        if (response.data.status) {
            submitBankingDetail(bankDetails);
        } else {
            showerror(globalConstants.errorMessages.commonError);
            loadingFactory.hide();
        }
        });
    }

    /**
     * Get Display Provider Payment Method Settings Details Banking or Cheque from the server. 
     * @type @exp;serverRequestFactory@call serverComm with url ;
     */
    var getPromiseBanking = serverRequestFactory.serverComm(globalConstants.serviceUrl.getProviderAccountSettingBankingDetails, "GET", "", token, "", true);
    getPromiseBanking.then(function (response) {
       
        $scope.bankInfo = response.data.data == globalConstants.defaultValues.apiBlankData ? { payment_method: globalConstants.defaultValues.providerPaymentTypeBank } : response.data.data;
        loadingFactory.hide();

    })
    /*
    * Function to submit Banking details
    */
    var submitBankingDetail = function (BankingDetails) {
        delete BankingDetails['user_id'];
        if ($scope.bankInfo.id) {
            BankingDetails.id = $scope.bankInfo.id;
            if (BankingDetails.payment_method == globalConstants.defaultValues.providerPaymentTypeCheque) {
                delete BankingDetails['bank_name'];
                delete BankingDetails['routing_number'];
                delete BankingDetails['account_number'];
                delete BankingDetails['account_type'];
                delete BankingDetails['branch_address'];
            } else {
                delete BankingDetails['cheque_in_favor_off'];
                delete BankingDetails['mailing_address'];
            }
        }
        /**
         * Post Provider Account Settings Details banking Details to the server. 
         * @type @exp;serverRequestFactory@call serverComm with url ;
         */
        var postPromiseBanking = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateProviderAccountSettingBankingDetails, "POST", BankingDetails, token, "", true);
        postPromiseBanking.then(function (response) {
        if (response.data.status) {
            $timeout(function () {
                loadingFactory.hide();
                showerror(globalConstants.errorMessages.accountSettingSuccess);
            }, 1000)
        } else {
            showerror(globalConstants.errorMessages.commonError);
            loadingFactory.hide();
        }
        })
    }

    /*
    * Function to disable & enable checkboxes on when click on Availability 
    */

    $scope.disableNEnableCheckbox = function () {

        if ($scope.onDemandAndFareSetting.is_temporary_unavailable == yes) {
            $scope.otherCheckBoxDisable = true;
            $scope.onDemandAndFareSetting.on_demand_appointment = no;
            $scope.onDemandAndFareSetting.multiprovider_scheduled_appointment = no;
            $scope.onDemandAndFareSetting.concierge_service = no;
        } else {
            $scope.onDemandAndFareSetting.is_temporary_unavailable == no
            $scope.otherCheckBoxDisable = false;
        }
        
    };
    $scope.updateValue = function (value) {

        if (value == yes) {
            $scope.onDemandAndFareSetting.scheduled_insurance_charges = $scope.onDemandAndFareSetting.on_demand_insurance_charges;
            $scope.onDemandAndFareSetting.scheduled_non_insurance_charges = $scope.onDemandAndFareSetting.on_demand_non_insurance_charges;
        }

    }
    $scope.submitDetails = function (fareAndAvailbaleDatils, bankDetails, form) {
        
        if (requiredFactory.validateBeforeSubmit(form, $scope) && otherValidationCheck.validateBeforeSubmit()) {
            submitChargeAvailability(fareAndAvailbaleDatils, bankDetails);
        }

    }
    /**
     * Round off the number till two digits after decimal
     * @param {number} number 
     */
    function round(number) {
        number = parseFloat(number);
        return +(Math.round(number + "e+" + 2) + "e-" + 2);
    }
    /**
     * Show error/Success msg 
     * @param {String} msg 
     */
    function showerror(msg) {
        toastMsg.show(msg);  
    }


});
