face2face.controller("videoConsultingRoomCtrl",function($scope,globalConstants,serverRequestFactory,$state,$window,requiredFactory,convertDate,$stateParams,$rootScope,Scopes,$ionicNavBarDelegate,consultRoomService,validateDate,showModalService,toastMsg,$filter,commonGetterService,loadingFactory,showPopup) {
    var token = commonGetterService.getToken();
    $scope.scheduleTitle = 'Schedule a Follow-Up';
    $scope.consultData = Scopes.get('consultData');
    var name = $scope.consultData.patient.fname+' '+ $scope.consultData.patient.lname;
    $scope.patientName = name != globalConstants.askAnExpertPopup.name ? name : $scope.consultData.consumer.fname + ' ' + $scope.consultData.consumer.lname; 
    // name != globalConstants.askAnExpertPopup.name ? 
    $scope.provider = true;
    if($stateParams.type == 'Multi-Provider' || $stateParams.type == 'Video'){
      if($stateParams.type == 'Multi-Provider' && $scope.consultData.accepted_first == 'No'){
        $scope.consultData.start_url = $scope.consultData.join_url;
      }
      //window.open($scope.consultData.start_url, '_system');
      consultRoomService.zoomInit('',{meeting_id:$scope.consultData.zoom_meeting_data.id,user_id:$scope.consultData.zoom_meeting_data.host_id,userName:$scope.consultData.provider.fname,token:'QwzM8RxgfzHFnRR3eK23L8maQFAGWFfBaj8U'},$scope.consultData.id,$scope,token,1);
      cordova.plugins.backgroundMode.enable();
    }
    consultRoomService.getDiagnosis($scope);
    startCheckingForExtendOrEnd();

    // cordova.plugins.backgroundMode.on('enable', function(){
    //   startCheckingForExtendOrEnd();
    // });
    // callback on click of local notifiction
    cordova.plugins.notification.local.on("click", function(notification) {
      showPopup.show('Extend Meeting','<p>Do you want to extend the meeting?</p>', $scope,'','Extend');
    });

    var interval;
    getEndConStatus();
    function startCheckingForExtendOrEnd(){
      interval = setInterval(function(){
        getEndConStatus();
        if($scope.consultData.multi_provider =='Yes'){
          ifProviderReqestedExtendReq();
        }     
      },15000); // for extend
    }

    function getEndConStatus(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getEndStatus + $scope.consultData.id , 'GET',{}, token,'','silent'); // get stattus of meeting 
      promise.then(function(res) {
        if (res.data.status == true) {
          if(res.data.data == "Completed"){
            $scope.alreadyEnded = true;
            clearInterval(interval);
          }
        }
      },function(res){
        if(res.status == 401){
          hideModal();
          if(interval){
            clearInterval(interval);
          }
        }
      })
    }

    function ifProviderReqestedExtendReq(){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.providerExtendReq + $scope.consultData.id, 'GET', {}, token,'','silent'); // get the consumer detail list  
      promise.then(function(res) {       
        if (res.data.status == true) {
          if(cordova.plugins.backgroundMode.isActive()){
            cordova.plugins.notification.local.schedule({
              id: 1,
              title: 'Face2FaceHealth',
              text: 'Extend Meeting',
              at:new Date()
            })
          }
          if(!cordova.plugins.backgroundMode.isActive()){
            showPopup.show('Extend Meeting','<p>Do you want to extend the meeting?</p>', $scope,'','Extend');
          }
        } else if (res.status) {
          
        }

     },function(res){
        if(res.status == 401){
          if(interval){
            clearInterval(interval);
          }
          hideModal();
        }
      })
    }

    //callback on cleck ok to extend 
    $scope.confirmStatus =function(status,type){
      if(type != 'cancel'){
        acceptedDeclined('Accepted');
      }else{
        acceptedDeclined('Declined');
      }
    }

    /**
    * function to show modal of Schedule a follow up
    */
    function showModal(type){
      switch(type){
        case 'Extend':
          if(!$scope.alreadyEnded){
            $scope.extendTimeArray = [10,20,30];
            $scope.extendTime = "10";
            showModalService.show($scope,'modules/provider/consultWaitingRoom/template/extendMeeting.html');
          }
        break;
        case 'S-Follow-Up':
          $scope.consultation_end_date = {
            displayDate: convertDate.toMMddYYYYInString(new Date()),
            displayTime: convertDate.toAmPM(new Date()),
            date:new Date()
          };
          $scope.consultation_start_date = {
            displayDate: convertDate.toMMddYYYYInString(new Date()),
            displayTime: convertDate.toAmPM(new Date()),
            date:new Date()
          };
          showModalService.show($scope,'templates/scheduleAFollowUp.html'); 
        break;
        case 'R-Follow-Up':
          $scope.appointmentData = {
            provider_type_id:'',
            speciality_id:''
          };
          commonGetterService.getProviderType($scope,token);
          showModalService.show($scope,'modules/provider/consultWaitingRoom/template/recommandFollowUp.html'); 
        break;
      }
     
    }

    /* 
    *function to hide modal 
    */
    function hideModal (){
      showModalService.hide(true);  
    }
    /**
    *
    */
    function hideSchedule(){
      hideModal();
    }


    /**
    * function to show date time picker
    */
    function showDateTimePicker(type){
      validateDate.showDatePickerforCosult($scope,type);
    }

    /*
    * function for scheduling a follow up 
    */
    function submitScheduleFollowUp(){ // form and data
      if(validateTime()){
        var data={};
        data.consult_id = $scope.consultData.id;
        data.consultation_start_time =   $filter('date')($scope.consultation_start_date.date, 'HH:mm:00');
        data.consultation_end_time = $filter('date')($scope.consultation_end_date.date, 'HH:mm:00');
        data.consultation_start_date = $filter('date')($scope.consultation_start_date.date, 'MM/dd/yyyy');
        consultRoomService.scheduleFollowUp(data,token,$scope);
      }
    }

    function validateTime(){
      if($scope.consultation_start_date.date < $scope.consultation_end_date.date && $scope.consultation_start_date.date >= new Date()){
        return true;
      }else{
        if($scope.consultation_start_date.date <= new Date()){
          toastMsg.show('You can not choose time less than or equal to current time');
        }else{
          toastMsg.show('You can not choose start time greater than or equal to end time');
        }
        return false;
      }
    }

    /*
    * function to end meeting
    */
    function endMeeting(type){
      var slient =false;
      if(type == ' '){
        slient = true; // not to show loader
      }
      if(!$scope.alreadyEnded){
        consultRoomService.endConference(type,$scope,$scope.consultData.id,token,'',slient);
      }
    }

    /**
    * function to recommand a follow Up
    */
    function submitRecommandFollowUp(form){
      if (requiredFactory.validateBeforeSubmit(form, $scope)) {
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.recommendFollowUp, 'POST', {
        "consumer_id":$scope.consultData.consumer.id,
        "patient_id":$scope.consultData.patient.id,
        "provider_type_id": $scope.appointmentData.provider_type_id,
        "speciality_id": $scope.appointmentData.speciality_id,
        "consultation_id":$scope.consultData.id 

        }, token);
        promise.then(function(res) {
            if (res.data.status == true) {
              loadingFactory.hide();
              $scope.appointmentData = {
                provider_type_id:'',
                speciality_id:''
              };
              hideModal();
              toastMsg.show("You have successfully recommended for followup");                
            } else {
              loadingFactory.hide();
            }
        }, function(err) {
          loadingFactory.hide();
        });
      }
    }

    /**
    * function to get speciality
    */

    $scope.getSpecialities = function(id){
      commonGetterService.getSpecialities($scope,id,token);
    }

    /*
    * function to request to extend meeting
    */

    function extendMeeting(){
      if(!$scope.alreadyEnded){
        var promiseExtend = serverRequestFactory.serverComm(globalConstants.serviceUrl.requestToextend,'POST',{"consultation_id":$scope.consultData.id,"minutes":$scope.extendTime},token);
        promiseExtend.then(function(res) {
          if (res.data.status == true) {
            loadingFactory.hide();
            hideModal();
            toastMsg.show("Meeting will be extended ,once it will be confirmed");
          } else if (res.data.status == false) {
            loadingFactory.hide();
          }
        }, function(err) {
          loadingFactory.hide();
        })
      }
    }

    /**
    * Accept or decline request to extend meeting (in case of multiprovider) 
    */

    function acceptedDeclined (status){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.provideracceptDecline+$scope.consultData.id+'/'+status, 'POST', {}, token,'','silent'); // get the consumer detail list  
    }

    $scope.saveDiagnosis = function(form) { 
        saveDiagnosis
    }

    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall = function(functionName,params){
      switch(functionName){
        case 'showDateTimePicker':
            showDateTimePicker(params);
            break;
        case 'ScheduleFollowUpoOrReschedule':
            submitScheduleFollowUp(params)
            break;
        case 'goBack':
            goBack();
            break;
        case 'hideModal':
          hideModal();
        break;
        case 'showModal':
          showModal(params);
        break;
        case 'endMeeting':
          endMeeting();
        break;
        case 'RecommandFollowuP':
          submitRecommandFollowUp(params);
          break;
        case 'extendMeeting':
          extendMeeting();
          break;
        case 'hideSchedule':
          hideSchedule();
          break;
        case 'saveDiagnosis':
          consultRoomService.saveDiagnosis(params.notes,$scope,params.onSave);
          break;
      }
    }

    $scope.$on('$ionicView.beforeEnter', function (e, data) {
      $ionicNavBarDelegate.showBackButton(true);
      data.enableBack = true;
      $rootScope.showMenu = false;
      Scopes.store('Inactivitycheck',true);
    });
    $scope.$on('$ionicView.beforeLeave',function(){
      cordova.plugins.backgroundMode.disable();
      if(interval){
        clearInterval(interval);
      }
      Scopes.delete('Inactivitycheck');
    })

              // Cleanup the modal when we're done with it!
    $scope.$on('$destroy', function() {
      cordova.plugins.backgroundMode.disable();
      if(interval){
        clearInterval(interval);
      }
    });

});
