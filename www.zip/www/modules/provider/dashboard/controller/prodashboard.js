face2face.controller('proDashboard',function($scope,loadingFactory,serverRequestFactory,globalConstants,$window,getAppointments,$state,toastMsg,$ionicNavBarDelegate,$rootScope,$ionicHistory,Scopes,calendarSync){
   
  /** To get the token from localstorage **/

  if(localStorage.userData){
      var userData = JSON.parse(localStorage.userData);
      token = userData.token;
  } 
  /** get upcoming appointments ***/

  $scope.changeAvailability = function(onOff){
      var promise;
      promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getAppointments+'/scheduled', 'POST',{"search": $scope.searchRecord},token,'',true);
      promise.then(function(res) {
        if(res.data.status == true) {
          
          loadingFactory.hide();
        } 
      }, function(err) {
      });
  }

  $scope.$on('$ionicView.beforeEnter', function (e, data) {
     $rootScope.menuSelected = " ";  
     $ionicNavBarDelegate.showBackButton(false);
     data.enableBack = false;
     $rootScope.showMenu = true;
   });

});

