/*
 * controller to list all patient related to provider
 * @ Author - sonam
 */

face2face.controller("providerPatientCtrl", function ($scope, globalConstants, serverRequestFactory, $rootScope, $state, $timeout, proAppointmentService, loadingFactory, commonGetterService) {

  $scope.askAnExpert = globalConstants.askAnExpertPopup.name;

  /** To get the token from localstorage **/
  if (localStorage.userData) {
    var userData = JSON.parse(localStorage.userData);
    var token = userData.token;
  }
  $scope.date = new Date();
  $scope.currentPage = 1;
  $scope.patientList = {
    list: [],
    Page: {
      next: 1
    }
  }
  $scope.appointmentType;
  $scope.activeTab = '';
  $scope.typeList = [];
  $scope.searchParams = {};
  $scope.genderList = ['Male', 'Female'];
  $scope.isLoadingMore = false;
  var init = function () {
    proAppointmentService.getPatientAppointments($scope, 1, token);
  }
  init();

  /*
   * get appointmentslist
   */
  $scope.getPatientAppointmentsByProvider = function (currentPage, appointmentType, searchParams) {
    if (this.isLoadingMore)
      return;
    $scope.loadMore = false;
    $scope.isLoadingMore = true;
    ($scope.activeTab == appointmentType) ? angular.noop() : $scope.patientList.list = [];
    currentPage = !currentPage ? 1 : currentPage;
    $scope.activeTab = appointmentType;
    if (angular.isUndefined(searchParams)) {
      $scope.searchParams = {
        'dob': '',
        'appDate': ''
      };
    }
    proAppointmentService.getPatientAppointments($scope, currentPage, token, appointmentType, searchParams);
  };
  $scope.clearAll = function () {
    $scope.searchParams = {};
    $scope.searchParams.appDate = '';
    $scope.searchParams.dob = '';
    proAppointmentService.getPatientAppointments($scope, 1, token, $scope.appointmentType);

  }

  $scope.medicalRecords = function (emr_url) {
    commonGetterService.openEmr(emr_url);
  }


});


face2face.service('proAppointmentService', function (serverRequestFactory, globalConstants, $timeout, loadingFactory) {
  this.getPatientAppointments = function (scope, currentPage, token, appointmentType, searchParams) {
    var data = {}
    scope.loadMore = false;
    if (angular.isDefined(appointmentType)) {
      data.status = appointmentType;
    }
    if (angular.isDefined(searchParams)) {
      if (angular.isDefined(searchParams.searchString)) {
        data.patient_name = searchParams.searchString;
      }
      if (angular.isDefined(searchParams.inquiryType) && searchParams.inquiryType) {
        data.inquiry_type = searchParams.inquiryType;
      }
      if (angular.isDefined(searchParams.gender)) {
        data.gender = searchParams.gender;
      }
      if (angular.isDefined(searchParams.dob)) {
        data.dob = searchParams.dob;
      }
      if (angular.isDefined(searchParams.appDate)) {
        data.appt_date = searchParams.appDate;
      }
    }
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getPatientAppointmentsByProvider + currentPage, 'POST', data, token);
    promise.then(function (res) {
      if (res.status && res.data.data.list != 'None') {
        scope.patientList.list = scope.patientList.list.concat(res.data.data.list);
      }
      scope.patientList.Page = res.data.data.Page;
      scope.patientList.Page.next = currentPage + 1;
      scope.isLoadingMore = false;
      scope.$broadcast('scroll.infiniteScrollComplete');
      loadingFactory.hide();
      scope.patientList.Page.nextPage ? scope.loadMore = true : scope.loadMore = false;

    }, function() {
      scope.loadMore = true
      scope.isLoadingMore = false;
      scope.$broadcast('scroll.infiniteScrollComplete');
    });
  }



});
