face2face.controller('proEditProfile',function($scope,loadingFactory,serverRequestFactory,globalConstants,$window,getAppointments,$state,showPopup,$timeout,commonGetterService,validateDate,requiredFactory,toastMsg,  $ionicSlideBoxDelegate){

 var pictureSource = (globalConstants.gApp) ? navigator.camera.PictureSourceType : ''; // initialization for camera plugin
 var destinationType = (globalConstants.gApp) ? navigator.camera.DestinationType : ''; // initialization for camera plugin
 $scope.titles = [{name:"Mr."},{name:"Miss"},{name:"Dr."},{name:"Mrs."}];
 var token = commonGetterService.getToken();
 $scope.data = {};
 $scope.prImg = {};
 $scope.dobErr = "";
 $scope.photoErr = "";
 $scope.dateerrmsg = '';
 $scope.organizationName = true;
 $scope.data.individual = 'individual';
 $scope.currentIndex = 0;
 $scope.options = {
  loop: false,
  effect: 'fade',
  speed: 500,
}
$scope.years = validateDate.getYears();
$scope.degreeNameData = [];

 /** get states **/

 commonGetterService.getStates($scope);

 /** upload image functions **/
 function dataURItoBlob(dataURI) {
     
  var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
  
  var binary = atob(dataURI.split(',')[1]), array = [];
  for(var i = 0; i < binary.length; i++) array.push(binary.charCodeAt(i));
  return new Blob([new Uint8Array(array)], {type:mimeString});
    
 }

 var uploadImage = function(imgURI,fileName){
  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.uploadProfileImage,'POST',{'photo_name':fileName,'photoObj':imgURI},token);
  promise.then(function(res) {
     
      if (res.data.status == true && res.data.data !== "None") {
        
          $scope.prImg.imageURI = res.data.data;
          loadingFactory.hide();
      } else {
          loadingFactory.hide();
      }
  }, function(err) {
      
      loadingFactory.hide();
  });
 }
 
 $scope.addImage = function() {
   navigator.notification.confirm('Select option', onConfirm, 'Add Picture', 'Gallery,Camera,Cancel');

  function onConfirm(select)
  {
    if (select == 1) {
      getPhoto(pictureSource.SAVEDPHOTOALBUM);
    }
    else if(select == 2) {
      capturePhotoEdit();
    }

  }
}

 function capturePhotoEdit()
 {
   // Take picture using device camera, allow edit, and retrieve image as base64-encoded string
  navigator.camera.getPicture(onSuccess, onFail, { quality: 20, allowEdit: true,saveToPhotoAlbum:true,destinationType: Camera.DestinationType.DATA_URL });
 }
  function getPhoto() {
  // Retrieve image file location from specified source
  navigator.camera.getPicture(onSuccess, onFail, { quality: 50, destinationType: Camera.DestinationType.DATA_URL,sourceType:Camera.PictureSourceType.SAVEDPHOTOALBUM });
 }
 function onSuccess(imageURI) {
    
    var head = 'data:image/jpeg;base64,';
    var imgFileSize = Math.round((imageURI.length - head.length)*3/4) ;
    //alert(imgFileSize)
    if(imgFileSize > 2*1024*1024)
    {
       
      return;
    }
  
    $timeout(function(){
       $scope.prImg.imageURI = imageURI;
        
       uploadImage($scope.prImg.imageURI,'mobile');
                 
       
     });

}

function onFail(message) {

    //alert('Failed because: ' + message);
}

/**
* get profile data
**/

$scope.getProfileData = function(){

var promise;
      var promise1
       promise1 = serverRequestFactory.serverComm(globalConstants.serviceUrl.getProviderProfile,'GET',{},token);  // the get dropdown list
        promise1.then(function(res){

           if(res.data.status== true && res.data.data != "None"){
             var providerData = res.data.data;
             $scope.provider_id                       = providerData.id;
             $scope.data.provider_type                = providerData.provider_profile.provider_type.title;
             $scope.data.fname                        = providerData.fname;
             $scope.data.lname                        = providerData.lname;
             $scope.data.title                        = providerData.title;
             $scope.data.gender                       = providerData.gender;
             $scope.data.dob                          = ("0" + (new Date(providerData.dob).getMonth() + 1)).slice(-2)+ "/" + ("0" + new Date(providerData.dob).getDate()).slice(-2) + "/" + new Date(providerData.dob).getFullYear();
             $scope.data.ssn_no                       = providerData.ssn_no;
             $scope.data.state_id                     = providerData.provider_profile.state_id.toString();
             $scope.data.city                         = providerData.provider_profile.city;
             $scope.data.address1                     = providerData.provider_profile.address1;
             $scope.data.address2                     = providerData.provider_profile.address2;
             $scope.data.zip                          = providerData.provider_profile.zip;
             $scope.data.home_phone                   = providerData.provider_profile.home_phone;
             $scope.data.home_fax                     = providerData.provider_profile.home_fax;
             $scope.data.office_phone                 = providerData.provider_profile.office_phone;
             $scope.data.office_fax                   = providerData.provider_profile.office_fax;
             $scope.data.bio                          = providerData.provider_profile.bio;
             $scope.data.speciality_name              = providerData.provider_profile.speciality.title;
             $scope.data.speciality_id                = providerData.provider_profile.speciality_id;
             $scope.data.speciality_experience        = providerData.provider_profile.speciality_experience;
             $scope.data.individual                   = providerData.provider_profile.individual;
             $scope.data.organization_name            = providerData.provider_profile.organization_name;
             $scope.data.provider_type_id             = providerData.provider_type_id;
             $scope.data.userName                     = providerData.username;
             $scope.prImg.imageURI                    = providerData.photo;
             $scope.data.provider_group                = providerData.provider_profile.provider_group;
             $scope.data.educationals                 = providerData.educationals;
             
             getDegreeType();
           }else{
            loadingFactory.hide();
          }
         },function(err){
            loadingFactory.hide();
        });

}

 $scope.organizationChange = function(){
   
    if($scope.data.individual == "individual"){
     $scope.organizationName = true;
    } else{
      $scope.organizationName = false;
    }
  }

  $scope.showDate = function(){
   var max =  ionic.Platform.isIOS() ? new Date() : (new Date()).valueOf();
   validateDate.showDatePicker($scope,'childDOB','',max);

  }
  
/**
**  update profile **
**/
 $scope.updateProfile = function(form){
  if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
    cordova.plugins.Keyboard.close();
  }
  if(validateDate.validateDt($scope.data.dob,'providerDOB').flag && requiredFactory.validateBeforeSubmit(form,$scope) && $scope.dobErr == "" && $scope.photoErr == ""){
  var objData = {};
  objData.provider_profile = {};
  objData.title = $scope.data.title;
  objData.fname = $scope.data.fname;
  objData.lname = $scope.data.lname;
  objData.ssn_no = $scope.data.ssn_no;
  objData.dob = $scope.data.dob;
  objData.gender = $scope.data.gender;
  objData.provider_profile.id = $scope.provider_id;
  objData.provider_profile.state_id = $scope.data.state_id;
  objData.provider_profile.address1 = $scope.data.address1;
  objData.provider_profile.address2 = $scope.data.address2;
  objData.provider_profile.city = $scope.data.city;
  objData.provider_profile.zip = $scope.data.zip;
  objData.provider_profile.home_phone = $scope.data.home_phone;
  objData.provider_profile.home_fax = $scope.data.home_fax;
  objData.provider_profile.office_phone = $scope.data.office_phone;
  objData.provider_profile.office_fax = $scope.data.office_fax;
  objData.provider_profile.bio = $scope.data.bio;
  objData.provider_profile.speciality_id = $scope.data.speciality_id;
  objData.provider_profile.speciality_experience = $scope.data.speciality_experience;
  objData.provider_profile.individual = $scope.data.individual;
  objData.provider_profile.organization_name = $scope.data.organization_name;
  objData.username =  $scope.data.userName;
  objData.educationals = $scope.data.educationals;
 
  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateProvidersProfile,'POST',objData,token);
  promise.then(function(res) {

      if (res.data.status == true) {
      
          toastMsg.show("Profile has been updated successfully");       
          loadingFactory.hide();

      } else {
          loadingFactory.hide();
      }
  }, function(err) {
      
      loadingFactory.hide();
  });
}
}

 $scope.getProfileData();

 $scope.getDegreeName = function(degreeTypeId, index, from){
  if(!!degreeTypeId){
    $scope.checkForOtherDegreeType(degreeTypeId, index);
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getDegreeName+degreeTypeId, 'GET', {},token,'',true);
      promise.then(function(res) {
          if (res.data.status == true && res.data.data != globalConstants.defaultValues.apiBlankData) {
              loadingFactory.hide();
              $scope.degreeNameData[index] = res.data.data;
              from ? angular.noop() : $scope.data.educationals[index].degree_id = '';
              if($scope.data.educationals[index].degree_id) {$scope.checkForOtherDegree($scope.data.educationals[index].degree_id,index)};
          } else {
              loadingFactory.hide();
          }
      }, function(err) {
          loadingFactory.hide();
      });
  }
}

function getDegreeType() {

  $scope.degreeTypes = [];
  var promiseRes = serverRequestFactory.serverComm(globalConstants.serviceUrl.getDegreeType, 'GET', {},token,'',true);
  promiseRes.then(function(response) {
    if (response.data.status && response.data.data != globalConstants.defaultValues.apiBlankData) {
      $scope.degreeTypes = response.data.data;
      angular.forEach($scope.data.educationals, function(value, key) {
        $scope.data.educationals[key].degree_type_id = $scope.data.educationals[key].degree_type_id.toString();
        $scope.data.educationals[key].degree_id = $scope.data.educationals[key].degree_id.toString();
        $scope.getDegreeName($scope.data.educationals[key].degree_type_id,key,true);
      });
    }
    loadingFactory.hide();
  })

}


$scope.addMore = function(type,index){
  switch(type){
    case 'add':
     $scope.data.educationals.push({
			"school": "",
			"degree_name": "",
			"year_of_degree_recieved": "",
			"other_degree_type": "",
			"other_degree_name": "",
			"degree_id": '',
			"short_name": "",
			"degree_type_id": '',
			"degree_type": ""
		});
    break;
    case 'remove':
      $scope.data.educationals.splice(index,1);
    break;
  }
}
$scope.checkForOtherDegree = function(degreeId, index) {
  if(degreeId == -1) {
    $scope.data.educationals[index].showDegName = true;
  }else{
    $scope.data.educationals[index].showDegName = false;
  }
}
$scope.checkForOtherDegreeType = function(degreeTypeId, index) {
  if(degreeTypeId == -1) {
    $scope.data.educationals[index].showDegType = true;
  }else{
    $scope.data.educationals[index].showDegType = false;
  }
}


});




