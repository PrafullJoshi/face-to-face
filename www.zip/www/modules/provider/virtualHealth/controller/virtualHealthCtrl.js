face2face.controller('virtualHealthCtrl',function($scope,loadingFactory,serverRequestFactory,globalConstants,$window,getAppointments,$state,showPopup,$timeout,toastMsg,$ionicNavBarDelegate,$rootScope,$ionicHistory,Scopes,calendarSync,showModalService,rescheduleAppointmentService,convertDate,validateDate,$filter,commonGetterService){
    if($window.localStorage['userData']){
      var userData = JSON.parse($window.localStorage['userData']);
      var token = userData.token;
      var userTypeId = userData.userTypeId;
    }
    $scope.consultation_end_date = {};
    $scope.consultation_start_date = {};
    $scope.scheduleTitle = 'Reschedule';
    var rescheduleData = {};
    var previousTab ;
    var previousView = $rootScope.previousScreen;
    /*
    * This function is made for prevent extra scope to be generated  
    */
    $scope.functionCall=function(functionName,params){
      switch(functionName){
        case 'cancelAppointment':
          cancelAppointment(params);
          break;
        case 'showModal':
          showModal();
        break;
        case 'hideModal':
          hideModal();
        break;
        case 'addTopicSubmit':
          addTopicSubmit(params);
        break;
        case 'goToConsultroom':
          goToConsultroom(params);
        break;
        case 'submitCheckList':
            submitCheckList(params);
            break;
        case 'gotoConsultPhone':
            finalSubChakList();
            break;
        case 'reschedule':
            reschedule(params);
            break;
        case 'ScheduleFollowUpoOrReschedule':
            ScheduleFollowUpoOrReschedule();
            break;   
        case 'showDateTimePicker':
             showDateTimePicker(params);
             break;
         case 'hideSchedule':
           hideSchedule();
         break;    
      }
    }

    if(userTypeId == 1){
      $scope.activeTab = $state.params.id?$state.params.id:'on-demand';
    }else{
      $scope.activeTab = $state.params.id?$state.params.id:'scheduled';
    }
    /** function to get Available Status ***/
    $scope.onOffStatus =true;
    function init(){
        if(userTypeId == 1){
          var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getAvailableStatus,'GET',{},token);
          promise.then(function(res){
            if(res.data.status == true){
              loadingFactory.hide();
              if(res.data.data.on_demand_appointment == "Y"){
                $scope.onOffStatus = true;
              }else{
                $scope.onOffStatus = false;
              }

            }else if(res.data.status == false){
              loadingFactory.hide();
            }
          },function(err){
            loadingFactory.hide();
          })
        }
        $timeout(function(){
          loadingFactory.show();
          $scope.changeTabs($scope.activeTab);
        },100);
        
    }

    /** get Available Status.  end***/


    /** change Available Status.  start***/
    $scope.changeAvailability = function(onOff){
        var promise;
        promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.providerAvailableStatus, 'POST', {"on_demand_appointment" : onOff},token,'',true);
        promise.then(function(res) {
          if(res.data.status == true) {
            $scope.onOffStatus = onOff;
            loadingFactory.hide();
          } 
        }, function(err) {
        });
      }

    /** onDemand starts here **/
    var getAppointmentList = function(type,ifRefresh,silent){
      
      getAppointments.getAppointments(type,token,silent).then(function(res){
        if (res.data.status == true && res.data.data!= "None") {
          $scope.appList = res.data.data;          
          loadingFactory.hide();
          if(ifRefresh){
            $scope.$broadcast('scroll.refreshComplete');
          }
        }else {
          $scope.appList =[];
          loadingFactory.hide();
          if(ifRefresh){
            $scope.$broadcast('scroll.refreshComplete');
          }
        }

      }, function(err) {
       
        loadingFactory.hide();
      });

    }

      /** change tabs  **/

    $scope.changeTabs = function(type){
        previousTab = $scope.activeTab;
        if(type == 'on-demand'){
          if(userTypeId == 1)
            $scope.virtualHealthTab = "modules/provider/virtualHealth/template/onDemand.html";
          else
            $scope.virtualHealthTab = "modules/consumer/virtualHealth/template/onDemand.html";
         // $state.go('mainView.proVirtualHealth.onDemand').then(function(){
         $scope.activeTab = 'on-demand';
         getAppointmentList(type);
         // });

        }
        else if(type == 'scheduled'){
          if(userTypeId == 1){
            $scope.virtualHealthTab = "modules/provider/virtualHealth/template/scheduled.html";
            // $state.go('mainView.proVirtualHealth.scheduled').then(function(){
              $scope.activeTab = 'scheduled';
              getAppointmentList(type);
            // });
          }else{
             $scope.virtualHealthTab = "modules/consumer/virtualHealth/template/conscheduled.html";
              // $state.go('mainView.conVirtualHealth.Conscheduled').then(function(){
              $scope.activeTab = 'scheduled';
              getAppointmentList(type);
            //});
          }

        }
        else if(type == 'requested'){
        $scope.activeTab = 'requested';
        if(userTypeId == 1){
          $scope.virtualHealthTab = "modules/provider/virtualHealth/template/requested.html";
          //$state.go('mainView.proVirtualHealth.requested').then(function(){
          getAppointmentList(type);
         //});
        }else{
          $scope.virtualHealthTab = "modules/consumer/virtualHealth/template/conrequested.html";
          //$state.go('mainView.conVirtualHealth.Conrequested').then(function(){
          getAppointmentList(type);
         //});
        }

        }

    }

    $scope.accept = function(record){
      $scope.isConcierge = record.concierge_service;
      $scope.consultMedium = record.consult_medium;
      if(record.consult_medium == "Concierge"){
        getConciergeAddress(record);
      }
      $scope.patientId = record.id;
      showPopup.show('Accept Appointment',"<p ng-if='conciergeAddress'>Patient Address - {{conciergeAddress.concierge_address1 +', '+conciergeAddress.concierge_zip_code +', ' +conciergeAddress.concierge_city + ', New York'}}<p>Accept this appointment?</p>",$scope,'Accept','Accept');
    }


    function getConciergeAddress(record){
      var promise;
      promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getConciergeAddress+record.id, 'GET', {},token);
      promise.then(function(res) {
        if(res.data.status == true) {
          $scope.conciergeAddress = res.data.data;
           loadingFactory.hide();
        }else{
           loadingFactory.hide();
        }
      }, function(err) {
          loadingFactory.hide();
      });
    }

    $scope.decline = function(record){
      $scope.patientId = record.id;
      showPopup.show('Decline Appointment',"<p ng-if='conciergeAddress'>Patient Address - {{conciergeAddress.concierge_address1 +', '+conciergeAddress.concierge_zip_code +', ' +conciergeAddress.concierge_city + ', New York'}}<p>Decline this appointment?</p>",$scope,'Decline','Decline');
    }

    /** confirm method for accept or decline appointments **/
    $scope.confirmStatus = function(status){
      if(userTypeId == 2){
        var url = globalConstants.serviceUrl.consumerAcceptDeclineAppointment; // for consumer
      }else{
        var url = globalConstants.serviceUrl.appointmentStatus;
      }

      var promise;
      promise = serverRequestFactory.serverComm(url+$scope.patientId+"/"+status, 'PUT', {},token);
      promise.then(function(res) {

        if(res.data.status == true) {
          if(status == 'Accept'){
            loadingFactory.hide();
            if($scope.activeTab == 'requested'){
              calendarSync.getCalendarEvents(token)
              $scope.changeTabs('scheduled');
            }else{
              $scope.request_status = 'Accept';
              getAppointmentList($scope.activeTab);
            }
          }else{
            if(status == 'Decline'){
              getAppointmentList($scope.activeTab);
            }
          }
        }else if(res.data.data =="Decline"){
          toastMsg.show(res.data.message);
          loadingFactory.hide();
        }else{
         loadingFactory.hide();
        }
      }, function(err) {
        loadingFactory.hide();
      });
    }

    /***
    ** function to pull to refresh
    */

    $scope.doRefresh = function(){
      getAppointmentList($scope.activeTab,'refresh','silent');
    }

    /****
    *  Cancel Appionment 
    */

    function cancelAppointment(consultId){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.cancelAppointment , 'POST', {consult_id:consultId},token);
      promise.then(function(res) {
        if (res.data.status == true ) {
            loadingFactory.hide(); 
            toastMsg.show('Appointment has been canceled successfully');
            getAppointmentList($scope.activeTab);
          } else {
            loadingFactory.hide();
            toastMsg.show('Oops! some error occured. Please try again later');
        }
      }, function(err) {
        loadingFactory.hide();
      });

    }

    init();

    function goToConsultroom(consultData){      
      if(userTypeId == 1){
        checkForPayment(consultData);
      }else{       
        if(consultData.payment_status == 'Y'){
          if(checkTime(consultData.start_time)){
            getproviderStartStatus(consultData);
          }else{
            toastMsg.show('Meeting can not be started before the scheduled time');
          }
        }else{
          toastMsg.show('Payment awaited , Please pull down to get latest update');
        }
      }
      
    }

    function checkForPayment(consultData){
      if(consultData.payment_status == 'Y'){
          $scope.check ={};
          if(checkTime(consultData.start_time)){
            if(consultData.patient.fname+' '+consultData.patient.lname!= globalConstants.askAnExpertPopup.name) {
              showPopup.showPopupCus('','templates/checklist.html',$scope,'Continue','submitChecklist',consultData);
            }else{
              if(consultData.consult_medium == 'Phone'){
                $scope.zoomPhoneNo = globalConstants.zoomPhoneNo;
                showModalService.show($scope,'templates/phoneConsultProvider.html','ondemandProv');
              }else{
                $scope.check ={
                  'view_issue_type' : 'No',
                  'view_patient_form' : 'No',
                  'view_patient_history' : 'No'
                }
                finalSubChakList(consultData)
              }

            }  
            
          }else{
            toastMsg.show('Meeting can not be started before the scheduled time');
          }
      }else{
          toastMsg.show('Payment awaited , Please pull down to get latest update');
      }
    }

    $scope.submitChecklist =function(consultData){
        if($scope.check && $scope.check.view_issue_type == 'Yes' && $scope.check.view_patient_form == 'Yes'&& $scope.check.view_patient_history == 'Yes'){
          $scope.onconsult = consultData;
          if($scope.onconsult.consult_medium == 'Phone'){
            $scope.zoomPhoneNo = globalConstants.zoomPhoneNo;
                 /*$('#phoneConsultModal').modal('show');*/
          // showPopup
           showModalService.show($scope,'templates/phoneConsultProvider.html','ondemandProv');
           
          }
          else{
            finalSubChakList(consultData);
          }

       
          
    }
  }
    function finalSubChakList(consultData){
        
        $scope.check.id=consultData.id;

        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.checkListProvider,'POST',$scope.check,token);
        promise.then(function(res) {
          if(res.data.status == true) {
            loadingFactory.hide();
            if(consultData.patient.fname+' '+consultData.patient.lname!= globalConstants.askAnExpertPopup.name) {
              if($scope.onconsult.url){
                 $timeout(function(){
                  // open webview for open emr // TO-do task
                  // meeting data for zoom
                  var meetingData ={}
                  if($scope.onconsult.zoom_meeting_data)
                    meetingData = {meeting_id:$scope.onconsult.zoom_meeting_data.id,user_id:$scope.onconsult.zoom_meeting_data.host_id,userName:$scope.onconsult.provider.fname,token:'sPzaGHX_ZYBgvSuCbqwN-2eOsznxGhqf7tRc635l_Uo.BgQga2FNU2NmNW5MWXZtZFV4Ujl6NjY0MDZ3bzNJTDMzb0YAAAwzQ0JBdW9pWVMzcz0A'}
                    commonGetterService.openEmr($scope.onconsult.url,meetingData,$scope.onconsult.id,{},token,1);
                 },1500)
                //window.open($scope.onconsult.start_url, '_system');
                Scopes.store('Inactivitycheck',true);
               }
             }else{
                Scopes.store('consultData',consultData);            
                $state.go('mainView.providerConsultRoom',{type:consultData.consult_medium});
             }
            // if($scope.onconsult.consult_type=="On-Demand"){

            // }else{
            //   Scopes.store('consultData',$scope.onconsult);            
            //   $state.go('mainView.providerConsultRoom',{type:$scope.onconsult.consult_medium});
            // }            
          }else{
            loadingFactory.hide();
          }
          if($scope.onconsult.consult_medium == 'Phone'){
            hideModal();
          }
        }, function(err) {
          loadingFactory.hide();
        });

      }      
    
    function getproviderStartStatus(consultData){       
          var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.checkProviderStartNow + consultData.id, 'GET', {}, token); // get the consumer detail list  
          promise.then(function(res) {            
              if (res.data.status == true) {
                loadingFactory.hide();
                Scopes.store('consultData',consultData);
                $state.go('mainView.consumerConsultRoom',{type:consultData.consult_medium});
              }else{
                loadingFactory.hide();
                toastMsg.show('Consultation has not been started by Provider');
              }

          }, function(err) {
            loadingFactory.hide();
          })
  
    }
    function checkTime(date){
      var diff = (new Date(date.replace(/-/g,"/")) - new Date())/(1000*60);
      if(diff <= 5){
        return true;
      }else{
        return false;
      }
    }

  // $scope.$on('backButtonEvent', function (event, args) {
      
  //     $scope.cusBackbttn(); 

  //     if($scope.activeTab == 'on-demand' || (userTypeId == 2 && $scope.activeTab == 'scheduled')){
  //       $ionicHistory.goBack(-2);
  //     }else{
  //       $scope.activeTab = previousTab;
  //       getAppointmentList($scope.activeTab);
  //     }

  // });

  // $scope.cusBackbttn = function(){
   
  //   if(($scope.activeTab == 'requested' || $scope.activeTab == 'scheduled') && (userTypeId == 2)){
  //     $state.go(previousView.name);
  //   }
  //   else if($scope.activeTab == 'requested' || $scope.activeTab == 'scheduled' || $scope.activeTab == 'on-demand' && (userTypeId == 1)){
  //     $state.go(previousView.name);
  //   }
  //   else{
  //     $scope.activeTab = previousTab;
  //     getAppointmentList($scope.activeTab);
  //   }
  
  // } 

  function hideModal(){
      $scope.oModal.hide();
      $scope.oModal.remove();
  }

/* reschedule  appointments */

function reschedule(data){
    $scope.consultation_end_date = {
      displayDate: convertDate.toMMddYYYYInString(new Date()),
      displayTime: convertDate.toAmPM(new Date()),
      date:new Date()
    };
    $scope.consultation_start_date = {
      displayDate: convertDate.toMMddYYYYInString(new Date()),
      displayTime: convertDate.toAmPM(new Date()),
      date:new Date()
    };
     
  rescheduleData.consultation_start_date = $scope.consultation_start_date.displayDate;
  rescheduleData.consultation_start_time = $scope.consultation_start_date.date;
  rescheduleData.consultation_end_time = $scope.consultation_end_date.date;
  rescheduleData.timezone =  timeZone();
  rescheduleData.id = data.id;

  showModalService.show($scope,'templates/scheduleAFollowUp.html'); 
}

function ScheduleFollowUpoOrReschedule(data){
  if(validateTime()){
    if(userTypeId == 2){
      rescheduleAppointmentService.reScheduleConsult(rescheduleData,token,'mainView.conDashboard',$scope,userTypeId);
    }
    else{
      rescheduleAppointmentService.reScheduleConsult(rescheduleData,token,'mainView.proDashboard',$scope,userTypeId);
    }
   
  }
 
}

function timeZone(){
    var currentTimeZoneOffsetInHours = new Date().getTimezoneOffset() / 60;
    return (currentTimeZoneOffsetInHours);
  }
  /**
  * function to show date time picker
  */
  function showDateTimePicker(type){
    validateDate.showDatePickerforCosult($scope,type);
  }

  function validateTime(){
    if($scope.consultation_start_date.date < $scope.consultation_end_date.date && $scope.consultation_start_date.date >= new Date()){
      return true;
    }else{
      if($scope.consultation_start_date.date <= new Date()){
        toastMsg.show('You can not choose time less than or equal to current time');
      }else{
        toastMsg.show('You can not choose start time greater than or equal to end time');
      }
      return false;
    }
  }
  /**
  *
  */
  function hideSchedule(){
  /*  if(autoGenerated){*/
      showModalService.hide(true);
      getAppointmentList($scope.activeTab);
      // $state.go('mainView.conDashboard').then(function(){
      //   $ionicHistory.removeBackView();
      // });
   /* }else{
      showModalService.hide(true);
    }*/
  }

  $scope.dateTimeformat = function(date){
    date = date.replace(/-/g,'/');
    return $filter('date')(new Date(date), 'MMM d, y h:mm:ss a');
    //|date:'MMM d, y h:mm:ss a'
  }

  $scope.$on('$ionicView.beforeEnter', function (e, data) {
    $rootScope.menuSelected = "virtualHealth";
    if($rootScope.previousScreen.name == 'mainView.conDashboard' || $rootScope.previousScreen.name == 'mainView.proDashboard'){
      enableBack = true;
    }else{
      enableBack = false;
    }
    $ionicNavBarDelegate.showBackButton(enableBack);
    data.enableBack = enableBack;
    $rootScope.showMenu = !enableBack;
   // $rootScope.cusBack = true;
   //$rootScope.
  });
});

/** change Available Status.  end***/
