face2face.controller("addCommunityTopicsCtrl",function($scope, globalConstants,serverRequestFactory, $state, requiredFactory,otherValidationCheck,$stateParams,$window) {
 /** To get the token from localstorage **/
  if(localStorage.userData){
    var userData = JSON.parse(localStorage.userData);
    var token  = userData.token;
    userType = userData.userTypeId;
    $('.navbar-nav a.active').removeClass('active');
    if(userData.userTypeId == 1){
	  $("#providerCommunity").addClass('active');
	}
    else{
	  $("#patientCommunity").addClass('active');
    }
  }

  $scope.init = function(){
    $scope.data = {};
    $window.scrollTo(0, 0);
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.providerType, 'GET', {});
        promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.providerTypeData = res.data.data;
    			$scope.data.provider_type_id = $stateParams.id;
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });

    var promise1 = serverRequestFactory.serverComm(globalConstants.serviceUrl.ageGroupDropDown, 'GET',{},token);
      promise1.then(function(res){
      if(res.data.status && res.data.data!="None"){
        $scope.ageGroupDropDown = res.data.data;
        $('#loader').hide();

      }else{
        $('#loader').hide();

      }
    }, function(err) {
        $('#loader').hide();
    });
  }


  	$scope.addTopics = function(form){
  		if (requiredFactory.validateBeforeSubmit(form, $scope)) {
	  		var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addForum, 'POST', $scope.data,token);
	        promise.then(function(res) {
	            if (res.data.status == true && res.data.data != "None") {
	                $('#loader').hide();
	                $('#success').modal('show');
	            } else {
	                $('#loader').hide();
	                $('#notJoin').modal('show');
	            }
	        }, function(err) {
	            $('#loader').hide();
	        });
	    }
  	}

	$scope.reset = function(){
		$scope.data = {};
    $scope.terms_of_use = false;
	}

	$scope.success = function(){
		if(token){
		  $window.localStorage['communityData'] = JSON.stringify({"provider_type_id":$scope.data.provider_type_id,"title":""});
          if(userType == 2){
            $state.go("patientMain.communitySilos"); // consumer 
          }else if(userType == 1){
            $state.go("providerMain.communitySilos"); // provider
          }
        }else{
          $window.localStorage['pNavigateState'] = $state.current.name;
          $state.go("main.login");
        }
	}


  // Call init method
  $scope.init();

});
