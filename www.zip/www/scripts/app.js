﻿/*Main module ------  sonakshi ---------- */

 var face2face = angular.module('face2face', ['ngSanitize','f2fPatient','f2fProvider','ui.router','angularPayments','moment-picker','ui.bootstrap','ui.calendar','720kb.socialshare','angularSelectbox','angular-rating-icons'], function() {
  

  })
.run(function ($rootScope,Scopes,$state,$window,mediaLinksService) {
   

   $rootScope.$on('$stateChangeSuccess', function (ev, to, toParams, from, fromParams){
    if(angular.isDefined($rootScope.startInterval)){
      clearInterval($rootScope.startInterval);
    }
      Scopes.delete('formInfo');
      $rootScope.previousState = from.name;
      $('#loader').hide();
      $('.popover').each(function() {
        $(this).popover('destroy');
      });
      angular.element(document.querySelector(".modal")).remove();
      angular.element(document.querySelector(".modal-backdrop")).remove();
      angular.element(document.querySelector("body")).removeClass( "modal-open" );  

      var now = moment();
      $rootScope.maxDate = now.format('L'); 
      $rootScope.mouseWheelTimePicker = false;

      if(angular.isDefined($rootScope.dashboardInterval)){
        clearInterval($rootScope.dashboardInterval);
        clearInterval($rootScope.startInterval);
        clearInterval($rootScope.interval);
        clearInterval($rootScope.newProReq);
      } 
      if(from.name === "patientMain.conOnDemandNewIssue" ||from.name === "patientMain.conScheduledNewAppointment" ){
        $window.localStorage.removeItem('RecommendFollowUp');
      }
      if(to.name === "main.patientSignUp" && localStorage.userData){
        $state.go("patientMain.dashboard");
      }
     /* else if(localStorage.userData && ){

      }*/
      if(to.name == "main.thankYou" && from.name != "main.subPlan" && localStorage.userData.userTypeId == 2){
        $state.go("main.subPlan");
      }
      else if(to.name == "main.thankYou" && from.name != "main.subPlan" && localStorage.userData.userTypeId == 1){

     }
     /* if(){

      }*/
   /*   if(localStorage.userData){

      }*/

       
   });


    $rootScope.$on("$stateChangeError", function (event, toState, toParams, fromState, fromParams, error) {
      authNavigation(toState,fromState);
    });

    // function to save sate in localstorage so that on back, we can navigate to that state
    $rootScope.saveState =function(type,state){
      var token;
      if(localStorage.userData){
        var userData = JSON.parse(localStorage.userData),
        token  = userData.token;
      };
      switch(type){
        case 'news':
          if(!state && angular.isDefined(userData)){
            if (userData.userTypeId == 2  ) { //consumer
              state = 'patientMain.news' ;
            } else if(userData.userTypeId == 1){
              state = 'providerMain.news';
            }else if($window.localStorage['pNavigateState']){
              state = $window.localStorage['pNavigateState'];
            }
            $window.localStorage['pNavigateState'] = state ;
          }else if(angular.isDefined(userData)){
            $window.localStorage['pNavigateState'] = state ;
          }
          
          break;
        default :
        $window.localStorage['pNavigateState'] = $state.current.name;
      }
    }
    // function to Auth the state if the particular url is for consumer or provider
    function authNavigation(to ,from){

      var token;
      if(localStorage.userData){
        var userData = JSON.parse(localStorage.userData),
        token  = userData.token;
      }
      /*else{
        $state.go("main.login");
        return;
      };*/

      if(token && userData.userTypeId == 2){
        $state.go("patientMain.dashboard");
        //return;
      }
      else if(token && userData.userTypeId == 1){
        $state.go("providerMain.providerDashboard");
        //return;
      }else{
        if(!(to.name == 'main.login')){
          $window.localStorage['pNavigateState'] = to.name;
        //  return;
        }
       $state.go("main.login");
      // return;
 
      }

    }
    // to get media links from backend
    mediaLinksService.getMediaLinks();

    $rootScope.redirectToPage = function(pageState){
      $state.go(pageState);
    }

})
.config(function($stateProvider, $urlRouterProvider) {
    // function to check the authentication // @sonam
    var Auth = ["$q", function ($q) {

        if (!localStorage.userData) {
            return $q.resolve();
        } else {
            return $q.reject();
        }
    }];

 $stateProvider
  .state('main', {
      url: '/main',
      abstract:true,
      views:{
        'header':{
          templateUrl:'modules/main/header/template/headerMain.html',
          controller:'mainHeaderCtrl'
        },
				'contents': {
					templateUrl: 'templates/mainContainer.html'
				},
				'footer':{
					templateUrl:'modules/main/footer/template/footerMain.html',
					controller:'footerCtrl'
        }                  
      }
              
	  })
   .state('main.error', {
        url: '/errPage',
          views:{
           'container': {
              templateUrl: 'templates/error.html',
              controller:''
            }                
        }
                
      })
	  .state('main.login', {
      url: '/login',
        views:{
         'container': {
            templateUrl: 'modules/main/login/template/patient-sign-in.html',
            controller:'loginCtrl'
          }                
      },
        resolve: {
          auth: Auth
      }
              
    })
   .state('main.forgotPassword', {
	  	url: '/forgotPassword',
	    views:{
	     'container': {
          templateUrl: 'modules/main/forgotPassword/templates/patient-forgot-password.html',
          controller:'loginCtrl'
        }                
	    }
    })
    .state('main.checkEmail', {
      url: '/checkEmail/:decodedEmail',
      views:{
       'container': {
          templateUrl: 'modules/main/forgotPassword/templates/patient-check-your-email.html',
          controller:'loginCtrl'
        }                
      }
    })
    .state('main.resetPass', {
      url: '/resetPass/:secretKey',
      views:{
       'container': {
          templateUrl: 'modules/main/forgotPassword/templates/patient-reset-password.html',
          controller:'loginCtrl'
        }                
      }
    })
   .state('main.pSignUp1', {
    	url: '/pSignUp1',
      views:{
       'container': {
          templateUrl: 'modules/main/providerSignup/templates/provider-signup-1.html',
          controller:'pSignUpCtrl'
        }                
     },
      resolve: {
          auth: Auth
      }
   })
   .state('main.pSignUp2', {
      url: '/pSignUp2',
      views:{
       'container': {
          templateUrl: 'modules/main/providerSignup/templates/provider-signup-2.html',
          controller:'pSignUpCtrl'
        }                
     }
   })
   .state('main.pSignUp3', {
      url: '/pSignUp3',
      views:{
       'container': {
          templateUrl: 'modules/main/providerSignup/templates/provider-signup-3.html',
          controller:'pSignUpCtrl'
        }                
     }
   })
   .state('main.pSignUp4', {
      url: '/pSignUp4',
      views:{
       'container': {
          templateUrl: 'modules/main/providerSignup/templates/provider-signup-4.html',
          controller:'pSignUpCtrl'
        }                
     }
   })
   .state('main.pSignUp5', {
      url: '/pSignUp5',
      views:{
       'container': {
          templateUrl: 'modules/main/providerSignup/templates/provider-signup-5.html',
          controller:'pSignUpCtrl'
        }                
     }
    })
    .state('main.pSignUp6', {
      url: '/pSignUp6',
      views:{
       'container': {
          templateUrl: 'modules/main/providerSignup/templates/provider-signup-6.html',
          controller:'pSignUpCtrl'
        }                
     }
   })
  .state('main.patientSignUp', {
		url: '/csignUp',
       views:{
     'container': {
        templateUrl: 'modules/main/consumerSignup/template/patient-sign-up.html',
        controller:'patientSignUp'
        }                
      }
    })
   .state('main.subPlan', {
    url: '/frPlan',
       views:{
     'container': {
        templateUrl: 'modules/main/plans/templates/patient-free-plan.html',
        controller:'subscriptionPlan'
        }                
      }
    })
   /*.state('main.paidPlan', {
    url: '/pdPlan',
       views:{
     'container': {
        templateUrl: 'modules/main/plans/templates/patient-paid-plan.html',
        controller:'subscriptionPlan'
        }                
      }
    })*/
    .state('main.thankYou', {
      url: '/thankYou',
         views:{
       'container': {
          templateUrl: 'modules/main/login/template/thankYou.html',
          controller:'thankYouCtrl'
          }                
        }
      })
      .state('main.conOnDemandNewUser', {
      url: '/conOnDemandNewUser',
         views:{
       'container': {
          templateUrl: 'modules/main/onDemandConsumerNewUser/templates/OnDemand-NewIssue_NewUser.html',
          controller:'conOnDemandnewUserCtrl'
          }                
        }
      })
       .state('main.community', {   // consumer patient/HOME state
              url: '/community',
               views:{
                'container': {
                     templateUrl: 'modules/provider/community/template/provider-community.html',
                     controller:'communityCtrl'

                                          
                   }         
              }
        
      })
      .state('main.communitySilos', {   // consumer patient/HOME state
              url: '/communitySilos',
               views:{
                'container': {
                     templateUrl: 'templates/community-silos.html',
                     controller:'communitySilosCtrl'

                                          
                   }         
              }
        
      })
      .state('main.communityJoinTerms', {   // consumer patient/HOME state
              url: '/communityJoinTerms',
               views:{
                'container': {
                     templateUrl: 'templates/join-community.html',
                     controller:'communityJoinCtrl'

                                          
                   }         
              }
        
      })
       .state('main.contactUs', {   // contact us page
              url: '/contactUs',
               views:{
                'container': {
                     templateUrl: 'templates/contactUs.html',
                     controller:'contactUs'
                 }         
              }
        
      })
      .state('main.faqs', {
        url: '/faqs',
          views:{
           'container': {
              templateUrl: 'modules/main/faqs/template/faqs.html',
              controller:'faqsCtrl'
            }                
        }
                
      })
      .state('main.aboutus', {
        url: '/aboutus',
          views:{
           'container': {
              templateUrl: 'modules/main/aboutus/template/about-us.html',
              controller:'aboutusCtrl'
            }                
        }
                
      })
      .state('main.privacyTerms', {
        url: '/privacyTerms',
          views:{
           'container': {
              templateUrl: 'modules/main/privacyTerms/template/privacy-terms.html',
              controller:'privacyTermsCtrl'
            }                
        }
                
      })

    .state('main.conScheduledNewUser', {
      url: '/conScheduledNewUser',
         views:{
       'container': {
          templateUrl: 'modules/main/conScheduledNewUser/template/scheduleappointment-NewUser_New_Issue.html',
          controller:'conScheduledNewUserCtrl'
          }                
        }
      })


    .state('main.landingPage', {
      url: '/landingPage',
       views:{
        'container': {
          templateUrl: 'modules/main/landingPages/templates/patient-landing.html',
          controller:'patientLandingCtrl'
        }                
      },
        resolve: {
          auth: Auth
      }
    })

    .state('main.landingPage.home', {   
      url: '/patienthome',
       views:{
        'patSilo': {
          templateUrl: 'modules/main/landingPages/templates/patient-home.html',
          controller:'patientHomeCtrl'
        }         
      }
    })

    .state('main.landingPage.siloPage', {  
      url: '/silopage',
       views:{
        'patSilo': {
          templateUrl: 'modules/main/landingPages/templates/siloPage.html',
          controller:'patientLandingCtrl'
        }         
      }
    })

    .state('main.businessHomePage', {   
      url: '/businessPage',
       views:{
        'container': {
          templateUrl: 'modules/main/landingPages/templates/business-homepage.html',
          controller:'businessHomeCtrl'
        }         
      }
    })

    .state('main.landingPage.providerhome', {   
      url: '/providerhome',
       views:{
        'patSilo': {
          templateUrl: 'modules/main/landingPages/templates/provider-home.html',
          controller:'providerHomeCtrl'
        }         
      }
    })
    .state('main.consent', {   
      url: '/consent',
       views:{
        'container': {
          templateUrl: 'templates/consent.html',
          controller:'consentCtrl'
        }         
      }
    })

    .state('main.news',{
        url:'/news',
        views:{
          'container':{
            templateUrl:'templates/news.html',
            controller:'newsCtrl'
          }
        }
    })
    .state('main.newsDetail',{
              url:'/newsDetail/:id',
              views:{
                'container':{
                  templateUrl:'templates/newsDetail.html',
                  controller:'newsDetailCtrl'
                }
              }
      })
    .state('main.blogsDetail', {   
      url: '/blogsDetail/:id',
       views:{
        'container': {
          templateUrl: 'templates/blogsDetail.html',
          controller:'blogsDetailCtrl'
        }         
      }
    })
    .state('main.mutiProviderAppointment', {   
      url: '/mutiProviderAppointment',
       views:{
        'container': {
          templateUrl: 'modules/main/mutiProviderNewUser/templates/scheduleAppointment-multiprovider.html',
          controller:'conScheduledNewUserCtrl'
        }         
      }
    })
    .state('main.modal', {   
      url: '/model',
       views:{
        'container': {
          templateUrl: 'templates/modal.html',
          controller:'modalCtrl'
        }         
      }
    })

  $urlRouterProvider.otherwise('main/landingPage/patienthome');

   
});





