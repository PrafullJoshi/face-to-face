/*Controller common to all modules 
*/


face2face.controller("commonController",function($scope, $window, $state,serverRequestFactory,globalConstants) {

    /******** Tabs Dropdown Starts Here ********/

    $.fn.responsiveTabs = function() {
      this.addClass('responsive-tabs');
      this.append($('<i class="fa fa-angle-down" aria-hidden="true"></i>'));

      this.on('click', 'li.active > a, i.fa', function() {
        this.toggleClass('open');
      }.bind(this));

      this.on('click', 'li:not(.active) > a', function() {
        this.removeClass('open');
      }.bind(this));
    };

    $('.nav.nav-tabs.responsive-tabs').responsiveTabs();

    /******** Tabs Dropdown Ends Here ********/

    /******** Table Responsive Starts Here ********/
  /*  $('.footable').footable();
    $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
      $(window).resize();
    });*/
    /******** Table Responsive Ends Here ********/
});