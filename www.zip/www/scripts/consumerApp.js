﻿
/*patient module*/

var f2fPatient = angular.module('f2fPatient',['ui.router'],function(){

})
.run(function($rootScope,$state){
 
})
.config(function($stateProvider){
      // function to check the authentication // @sonam
    var Auth = ["$q", function ($q) {
       //  get token from local storage 
        var token;
        if(localStorage.userData){
          var userData = JSON.parse(localStorage.userData),
          token  = userData.token;
        };
        if (token && userData.userTypeId == 2 ) {
            return $q.resolve();
        } else {
            return $q.reject();
        }
    }];
    var require = function(tokenType) {
      return ["$q", function ($q) {
        if(localStorage[tokenType]){
          return $q.resolve();
        }else {
          return $q.reject();
        }
    }];
  }
 
	 $stateProvider
	 .state('patientMain', {
	            url: '/patientmain',
	            abstract:true,
	            views:{
	              'header':{
	                 templateUrl:'modules/consumer/header/template/headerMain.html',
	                 controller:'consHeaderCtrl'
	               },
	               'contents': {
	                  templateUrl: 'templates/mainContainer.html'
	               },
	              'footer':{
	                templateUrl:'modules/main/footer/template/footerMain.html',
	                controller:'footerCtrl'
	              }                  
	            },
              resolve: {
                auth: Auth
            }
	            
	})
   .state('patientMain.changePass', {    //change password state
               url: '/changePass',
                views:{
                 'container': {
                      templateUrl: 'templates/changePassword.html',
                      controller:'changePass'
                                           
                    }                
               }
          
   })
  .state('patientMain.consumerProfile', {    // consumer profile state
              url: '/conProf',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/profile/templates/consumer-profile.html',
                     controller:'consumerProfile'
                                          
                   }                
              }
         
      })
    .state('patientMain.consumerAddPatient_2', {
              url: '/conAddPatient2',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/addPatient/templates/add-patient-detail-1.html',
                     controller:'conAddPatient'
                                          
                   }                
              }
         
      })
    .state('patientMain.consumerAddPatient_1', {
              url: '/conAddPatient1',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/addPatient/templates/add-patient-detail-2.html',
                     controller:'conAddPatient'
                                          
                   }                
              }
         
      })
    .state('patientMain.consumerAddPatient_3', {
              url: '/conAddPatient3',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/addPatient/templates/add-patient-detail-3.html',
                     controller:'conAddPatient'
                                          
                   }                
              }
         
      })
    .state('patientMain.consumerEditPatient_1', {
              url: '/conEditPatient_1/:patientId',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/addPatient/templates/add-patient-detail-1.html',
                     controller:'conEditPatient'
                                          
                   }                
              }
         
      })
    .state('patientMain.consumerEditPatient_2', {
              url: '/conEditPatient_2/:patientId',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/addPatient/templates/add-patient-detail-2.html',
                     controller:'conEditPatient'
                                          
                   }                
              }
         
      })
    .state('patientMain.consumerEditPatient_3', {
              url: '/conEditPatient_3/:patientId',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/addPatient/templates/add-patient-detail-3.html',
                     controller:'conEditPatient'
                                          
                   }                
              }
         
      })

	.state('patientMain.consumerPatient', {

              url: '/conpatient',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/patient/templates/patientMain.html',
                     controller:'patientMainCtrl'
                                          
                   }                
              }
         
      })
    
    .state('patientMain.consumerPatient.home', {   // consumer patient/HOME state
              url: '/home',
               views:{
                'consPat': {
                     templateUrl: 'modules/consumer/patient/templates/patient-home.html',
                     controller:'patientCtrl'

                                          
                   }         
              }
        
      })
    .state('patientMain.consumerPatient.notesDocs', {   // consumer patient/notes and documents state
              url: '/notesAndDocs',
               views:{
                'consPat': {
                     templateUrl: 'modules/consumer/patient/templates/notesDocuments.html',
                     controller:'patientNotesDocs'

                                          
                   }         
              }
        
      })
        .state('patientMain.consumerPatient.insurances', {   // consumer patient/insurance state
              url: '/insurances',
               views:{
                'consPat': {
                     templateUrl: 'modules/consumer/patient/templates/patient-insurances.html',
                     controller:'patientInsuranceCtrl'

                                          
                   }         
              }
        
      })

        .state('patientMain.consumerPatient.appointment', {   // consumer patient/appointment state
              url: '/appointment',
               views:{
                'consPat': {
                     templateUrl: 'modules/consumer/patient/templates/patient-appointment.html',
                     controller:'conPatientAppointmentCtrl'

                                          
                   }         
              }
        
      })
          .state('patientMain.consumerPatient.history', {   // consumer patient/history state
                url: '/mecialHistory',
                 views:{
                  'consPat': {
                       templateUrl:'modules/consumer/patient/templates/medicalHistory.html',
                       controller:'conPatientHisctrl'
                     
                     }         
                }
          
        })
       .state('patientMain.consumerPatient.remoteMonitor', {   // consumer patient/remote Monitoring
             url: '/remoteMonitoring',
              views:{
               'consPat': {
                    templateUrl:'modules/consumer/patient/templates/remoteMonitoring.html',
                    controller:'conPatientremoteMonitor'
                  
                  }         
             }
       
     })
      /*  .state('patientMain.consumerPatient.history.content', {   // consumer patient/historytype 
                  url: '/historyHome',
                   views:{
                    'medicalHisCon': {
                         templateUrl:'modules/consumer/patient/templates/medicalHistoryHome.html',
                         controller:'conPatientHisctrl'

                                            
                       }         
                  }
            
          })
        .state('patientMain.consumerPatient.history.medProblems', {   // consumer patient/historytype 
                  url: '/historyType',
                   views:{
                    'medicalHisCon': {
                         templateUrl:'modules/consumer/patient/templates/medicalHistoryType.html',
                         controller:'conPatientHisctrl'

                                            
                       }         
                  }
            
          })*/
       .state('patientMain.dashboard', {   // consumer patient/HOME state
              url: '/dashboard',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/dashboard/templates/patient-dashboard-ExistingUser.html',
                     controller:'conDashboardCtrl'

                                          
                   }         
              }
        
      })
      .state('patientMain.conOnDemandNewIssue', {   // consumer patient/HOME state
              url: '/conOnDemandNewIssue',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/onDemandConsumer/templates/OnDemand-NewIssue_existing-patient.html',
                     controller:'conOnDemandCtrl'

                                          
                   }         
              }
        
      })
 /*     .state('patientMain.conOnDemandExistIssue', {   // consumer patient/HOME state
              url: '/conOnDemandExistIssue',
               views:{
                'container': {
                     templateUrl: 'modules/consumer/onDemandConsumer/templates/OnDemand-ExistingIssue.html',
                     controller:'conOnDemandCtrl'

                                          
                   }         
              }
        
      })*/
      .state('patientMain.community', {   // consumer patient/HOME state
              url: '/community',
               views:{
                'container': {
                     templateUrl: 'modules/provider/community/template/provider-community.html',
                     controller:'communityCtrl'

                                          
                   }         
              }
        
      })
      .state('patientMain.communitySilos', {   // consumer patient/HOME state
              url: '/communitySilos',
               views:{
                'container': {
                     templateUrl: 'templates/community-silos.html',
                     controller:'communitySilosCtrl'

                                          
                   }         
              }
        
      })
      .state('patientMain.communityJoinTerms', {   // consumer patient/HOME state
              url: '/communityJoinTerms',
               views:{
                'container': {
                     templateUrl: 'templates/join-community.html',
                     controller:'communityJoinCtrl'

                                          
                   }         
              }
        
      })
  .state('patientMain.contactUs', {   // contact us page
              url: '/contactUs',
               views:{
                'container': {
                     templateUrl: 'templates/contactUs.html',
                     controller:'contactUs'
                 }         
              }
        
      })
      .state('patientMain.faqs', {
        url: '/faqs',
          views:{
           'container': {
              templateUrl: 'modules/main/faqs/template/faqs.html',
              controller:'faqsCtrl'
            }                
        }
                
      })

      .state('patientMain.aboutus', {
        url: '/aboutus',
          views:{
           'container': {
              templateUrl: 'modules/main/aboutus/template/about-us.html',
              controller:'aboutusCtrl'
            }                
        }
                
      })
      .state('patientMain.privacyTerms', {
        url: '/privacyTerms',
          views:{
           'container': {
              templateUrl: 'modules/main/privacyTerms/template/privacy-terms.html',
              controller:'privacyTermsCtrl'
            }                
        }
                
      })
      .state('patientMain.calendar',{
                url:'/calendar/:patientID?',
                views:{
                  'container':{
                    templateUrl:'modules/consumer/calendar/templates/calendar.html',
                    controller:'conCalendarCtrl'
                  }
                }
   })
  .state('patientMain.thankyou',{
                url:'/thankyou',
                views:{
                  'container':{
                    templateUrl:'templates/appontmentThankyou.html',
                    controller:''
                  }
                }
   })

    .state('patientMain.newsDetail',{
              url:'/newsDetail/:id',
              views:{
                'container':{
                  templateUrl:'templates/newsDetail.html',
                  controller:'newsDetailCtrl'
                }
              }
  })
  .state('patientMain.blogsDetail',{
          url:'/blogsDetail/:id',
          views:{
            'container':{
              templateUrl:'templates/blogsDetail.html',
              controller:'blogsDetailCtrl'
            }
          }
  })
  .state('patientMain.conScheduledNewAppointment', {   
    url: '/conScheduledNewAppointment',
     views:{
      'container': {
        templateUrl: 'modules/consumer/scheduledAppointment/templates/RequestToSchedule_ExistingPatient.html',
        controller:'conScheduledCtrl'
      }         
    }
  })
  .state('patientMain.consultationWaitingRoom', {   
    url: '/consultationWaitingRoom/:conFlag?',
     views:{
      'container': {
        templateUrl: 'modules/consumer/consultationWaitingRoom/template/consultationWaitingRoom.html',
        controller:'consultationWaitingRoomCtrl'
      }         
    },
      resolve: {
        auth: require('zoomAndProviderDetail')
      }
  })
  .state('patientMain.news',{
        url:'/news',
        views:{
          'container':{
            templateUrl:'templates/news.html',
            controller:'newsCtrl'
          }
        }
    })
  .state('patientMain.consent', {   
      url: '/consent',
       views:{
        'container': {
          templateUrl: 'templates/consent.html',
          controller:'consentCtrl'
        }         
      }
    })
  .state('patientMain.inbox', {
    url: '/inbox',
      views:{
       'container': {
          templateUrl: 'templates/inbox.html',
          controller:'inboxCtrl'
        }                
     }
  })
    .state('patientMain.mutiProviderAppointment', {   
      url: '/mutiProviderAppointment',
       views:{
        'container': {
          templateUrl: 'modules/consumer/mutiProviderConsumer/templates/mutiProviderlisting.html',
          controller:'conMultiProviderCtrl'
        }         
      },
      resolve: {
        auth: require('multiProviderData')
      }
    })

    .state('patientMain.landingPage', {
      url: '/landingPage',
       views:{
        'container': {
          templateUrl: 'modules/main/landingPages/templates/patient-landing.html',
          controller:'patientLandingCtrl'
        }                
      }
    })

    .state('patientMain.landingPage.siloPage', {  
      url: '/silopage',
       views:{
        'patSilo': {
          templateUrl: 'modules/main/landingPages/templates/siloPage.html',
          controller:'patientLandingCtrl'
        }         
      }
    })
  .state('patientMain.multiProviderCalendar', {
    url: '/multiProviderCalendar',
      views:{
       'container': {
          templateUrl: 'modules/consumer/calendar/templates/multiProviderCalendar.html',
          controller:'conMultiProviderCalendarCtrl'
        }                
     },
      resolve: {
        auth: require('multiproviderCalandarData')
      }
   })
    .state('patientMain.modal', {   
      url: '/model',
       views:{
        'container': {
          templateUrl: 'templates/modal.html',
          controller:'modalCtrl'
        }         
      }
    })
    .state('patientMain.addCommunityTopics', {   
      url: '/addCommunityTopics/:id',
       views:{
        'container': {
          templateUrl: 'templates/addCommunityTopics.html',
          controller:'addCommunityTopicsCtrl'
        }         
      }
    })
    .state('patientMain.viewCommunityTopic', {   
      url: '/viewCommunityTopic',
       views:{
        'container': {
          templateUrl: 'templates/viewCommunityTopic.html',
          controller:'viewCommunityTopicCtrl'
        }         
      }
    })


	//$urlRouterProvider.otherwise('patientMain/conpatient/home');


});


