face2face.controller("inboxCtrl",function($scope, globalConstants,serverRequestFactory, $rootScope, $state,initializePlugin, $timeout, requiredFactory,otherValidationCheck) {
 /** To get the token from localstorage **/
  if(localStorage.userData){
    var userData = JSON.parse(localStorage.userData);
    var token  = userData.token;
    if(userData.userTypeId == 1){
      $scope.providermail = true;
    }
    else{
      $scope.providermail = false;
    }
  }

  $scope.init = function(){
    $scope.data = {};
    $scope.value = '20';
    $scope.callfrom = '';
    $scope.currentPage = 1;
    $scope.readView = false;
    $scope.array = [20,50,100];
    $scope.getMails('',1);
  }

  $scope.getMails = function(from,pageno,type){
    if(type=="trashUndo"){
      var l = $scope.deletedMail.length;
    }
    $scope.deletedMail = [];
    $scope.callfrom = from;
    if(pageno)
      $scope.currentPage = pageno;
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.inboxDetail+$scope.currentPage, 'POST', 
      {
          "status": from,
          "limit":$scope.value

      }, token);
    promise.then(function(res) {
      $scope.inboxData = [];
      $scope.readView = false;
      if (res.data.status==true && res.data.data.inbox.length>0) {
        $('#loader').hide();
        $scope.inboxData = res.data.data.inbox;
        $scope.count = res.data.data.count;
        $scope.pageData = res.data.data.page;
        $scope.currentPage = $scope.pageData.page;  
        $scope.norecord = false;
        if($scope.pageData.page == 1){
          $scope.first = 1;
          $scope.last = $scope.pageData.current;
        }
        else if($scope.pageData.page > 1 && $scope.pageData.page != $scope.pageData.pageCount){
          $scope.first = ($scope.pageData.perPage * ($scope.pageData.page - 1))  + 1;
          $scope.last = $scope.pageData.perPage * $scope.pageData.page; 
        }
        else if($scope.pageData.page > 1 && $scope.pageData.page == $scope.pageData.pageCount){
          $scope.first = ($scope.pageData.perPage * ($scope.pageData.page - 1))  + 1;
          $scope.last = $scope.pageData.count;  
        }
      } else if(res.data.status==true && res.data.data.inbox.length == 0){
        $('#loader').hide();
        $scope.count = res.data.data.count;
        $scope.norecord = true;
      }else {
        $('#loader').hide();
      }
    }, function(err) {
      $('#loader').hide();
    });
  }

  $scope.checkMailType = function(mailType){
    if(mailType == 'Important'){
      return 'task-important';
    }
    else if(mailType == 'Social'){
      return 'task-social';
    }
    else if(mailType == 'Promotions'){
      return 'task-promotions';
    }
    else{
      return 'hidden-inbox-icon';
    }
  }

  $scope.checkAll = function() {
    $scope.deletedMail = [];
    angular.forEach($scope.inboxData, function(record) {
      record.select = $scope.selectAll;
      if($scope.selectAll){
        $scope.deletedMail.push(record.id);
      }else{
        $scope.deletedMail = [];
      }
    });
    // console.log($scope.deletedMail);
  };

   $scope.checkedPreValue = function(record){
    if(record.select){
      $scope.deletedMail.push(record.id);
      // console.log(plans);
    }else{
      for(var i=0; i<$scope.deletedMail.length; i++){
        if($scope.deletedMail[i] == record.id)
          $scope.deletedMail.splice(i,1)
      }
    }
    console.log("$scope.deletedMail",$scope.deletedMail);
  }

  $scope.deleteMail = function(){
    $scope.selectAll = false;
    if($scope.callfrom == 'Deleted' && $scope.deletedMail.length !=0){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.deleteTrashMail, 'PUT', 
        {
            "deleted_ids": $scope.deletedMail
        }, token);
      promise.then(function(res) {
        if (res.data.status==true && res.data.data == "None") {
          $('#loader').hide();
          if($scope.deletedMail.length == $scope.pageData.current && $scope.pageData.page == $scope.pageData.pageCount){
            $scope.currentPage = $scope.currentPage - 1;
          }
          $scope.getMails($scope.callfrom,$scope.currentPage);
          $scope.readView = false;

        } else {
          $('#loader').hide();
        }
      }, function(err) {
        $('#loader').hide();
      });
    } else{
      if($scope.deletedMail.length !=0){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.deleteMails, 'PUT', 
          {
              "deleted_ids": $scope.deletedMail
          }, token);
        promise.then(function(res) {
          if (res.data.status==true && res.data.data == "None") {
            $('#loader').hide();
            if($scope.deletedMail.length == $scope.pageData.current && $scope.pageData.page == $scope.pageData.pageCount){
              $scope.currentPage = $scope.currentPage - 1;
            }
            $scope.getMails($scope.callfrom,$scope.currentPage);
            $scope.readView = false;

          } else {
            $('#loader').hide();
          }
        }, function(err) {
          $('#loader').hide();
        });
      }
      
    }
  }


  $scope.mailPerPage = function(value){
    $scope.value = value;
    console.log(value);
    $scope.getMails($scope.callfrom,1);
  }


  $scope.inviteFriend = function(form){
    $scope.emailErr = '';
    var EMAIL_REGEXP = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if($scope.email){
      if(EMAIL_REGEXP.test($scope.email)){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.inviteProvider, 'POST', 
        {
            "email": $scope.email
        }, token);
        promise.then(function(res) {
          if (res.data.status==true) {
            $('#loader').hide();
            $scope.email = '';
          }else{
            $('#loader').hide();
            $scope.email = '';
          }
        }, function(err) {
          $('#loader').hide();
        });
       
      } else{
        $scope.emailErr = 'Please enter a valid email';
      }
    }
  }

  $scope.nextPage = function(){
    if($scope.pageData.nextPage == true){
      $scope.currentPage = $scope.currentPage + 1;  
      $scope.getMails($scope.callfrom,$scope.currentPage);
    }
  }

  $scope.prePage = function(){
   if($scope.pageData.prevPage == true){
      $scope.currentPage = $scope.currentPage - 1;  
      $scope.getMails($scope.callfrom,$scope.currentPage);
    } 
  }

  $scope.readMsg = function(id,index,isRead){
    $scope.currentIndex = index;
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.readMessage+id, 'GET', {}, token);
      promise.then(function(res) {
        if (res.data.status==true && res.data.data != "None") {
          if(isRead == 'N'){
            $scope.count = $scope.count - 1;
          }
          $scope.readMail = res.data.data[0];
          $scope.readView = true;
          $scope.inboxData[index].is_read = res.data.data[0].is_read;
          $('#loader').hide();
        } else {
          $('#loader').hide();
        }
      }, function(err) {
        $('#loader').hide();
      });
  }

  $scope.markStar = function(id,index){
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.markStar+id, 'GET', {}, token);
      promise.then(function(res) {
        if (res.data.status==true && res.data.data != "None") {
          $('#loader').hide();
          if(angular.isDefined(index)){
            // $scope.inboxData.splice(index,0);
            $scope.inboxData[index].star = res.data.data[0].star;
          }else{
            $scope.readMail.star = res.data.data[0].star;
            // $scope.inboxData.splice($scope.currentIndex,0);
            $scope.inboxData[$scope.currentIndex].star = res.data.data[0].star;
          }
        } else {
          $('#loader').hide();
        }
      }, function(err) {
        $('#loader').hide();
      });
  }

  

  $scope.back = function(){
    $scope.readView = false;
  }

  $scope.deleteReadMail = function(id,type){
    $scope.deletedMail = [];
    $scope.deletedMail.push(id);
    if(type=='delete'){
      $scope.deleteMail();
    }else if(type =='undo'){
      $scope.undoMailfromTrash();
    }
    
  }
  $scope.undoMailfromTrash = function(){
    if($scope.deletedMail.length !=0){
        $scope.selectAll = false;
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.undoTrash, 'PUT', 
          {
              "deleted_ids": $scope.deletedMail
          }, token);
        promise.then(function(res) {
          if (res.data.status==true && res.data.data == "None") {
            $('#loader').hide();
            if($scope.deletedMail.length == $scope.pageData.current && $scope.pageData.page == $scope.pageData.pageCount){
              $scope.currentPage = $scope.currentPage - 1;
            }
            if($scope.currentPage == 0){
              $scope.currentPage =1;
            }
            $scope.getMails($scope.callfrom,$scope.currentPage,"trashUndo");
            $scope.readView = false;

          } else {
            $('#loader').hide();
          }
        }, function(err) {
          $('#loader').hide();
        });
    }
  }

  // Call init method
  $scope.init();

});
