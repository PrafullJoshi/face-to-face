face2face.controller('modalCtrl',function(globalConstants,$scope,blogsAndNewsService,serverRequestFactory,$state){
	angular.element(document.querySelector(".navbar-nav a.active")).removeClass('active');
	var token ='';
	if(localStorage.userData){
	    var userData = JSON.parse(localStorage.userData),
	    token  = userData.token;
	};
	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getModal, 'GET');
      	promise.then(function(res) {
        	if (res.data.status == true && res.data.data != "None") {
        		$scope.ourModal = res.data.data.page;
          	$('#loader').hide();
          } else {
          		$scope.ourModal = 'Data is not added from admin.'
        		$('#loader').hide();
      	  }
      	}, function(err) {
        	$('#loader').hide();
      	});
	blogsAndNewsService.getBlogsAndNews($scope,{'type':'news','limit':3},'',token);
	blogsAndNewsService.getBlogsAndNews($scope,{'type':'blogs','limit':3},'',token);
	$scope.readMore = function(type,id){
		if(angular.isDefined(userData) && userData.userTypeId == 2){
			state = 'patientMain.';
		}else if(angular.isDefined(userData) && userData.userTypeId == 1){
			state = 'providerMain.';
		}else{
			state = 'main.';
		}
		$state.go(state+type,{id:id});

    }
    $scope.viewMore = function(){
    	if(angular.isDefined(userData) && userData.userTypeId == 2){
			state = 'patientMain.';
		}else if(angular.isDefined(userData) && userData.userTypeId == 1){
			state = 'providerMain.';
		}else{
			state = 'main.';
		}
		$state.go(state+'news');
    }
    $scope.toLocalDate = function(date,type){
        return moment(date).utc().format(type);
    }
})