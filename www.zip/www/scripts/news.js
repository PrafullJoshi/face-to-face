	/*
	* news controller 
	*/


	face2face.controller('newsCtrl',function($scope,serverRequestFactory,globalConstants,blogsAndNewsService,$stateParams,$window,$state){
		 /* get token from local storage */
		 angular.element(document.querySelector(".navbar-nav a.active")).removeClass('active');
    	var token;
	    if(localStorage.userData){
	        var userData = JSON.parse(localStorage.userData),
	        token  = userData.token;
	    };
	    $window.localStorage.removeItem('pNavigateState'); // remove previous state from local
	    $scope.news =[];
	    $scope.blogs =[];

		function init(){
			/* service call to get 5 latest blogs or news */
    		blogsAndNewsService.getBlogsAndNews($scope,{'type':'news','limit':3},'',token);
    		blogsAndNewsService.getBlogsAndNews($scope,{'type':'blogs','limit':6},'',token);

		}
		$scope.toLocalDate = function(date,type){
        	return moment(date).utc().format(type);
    	}
    	$scope.readMore = function(type,id){
    		if(angular.isDefined(userData) && userData.userTypeId == 2){
    			state = 'patientMain.';
    		}else if(angular.isDefined(userData) && userData.userTypeId == 1){
    			state = 'providerMain.';
    		}else{
    			state = 'main.';
    		}
    		$state.go(state+type,{id:id});

    	}
		init();

	});