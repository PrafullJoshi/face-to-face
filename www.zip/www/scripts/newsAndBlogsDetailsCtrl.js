face2face.controller('newsDetailCtrl',function($scope,serverRequestFactory,globalConstants,blogsAndNewsService,$stateParams,$window,$state,$location,Socialshare,$rootScope){
    angular.element(document.querySelector(".navbar-nav a.active")).removeClass('active');
    $scope.blogsAndNewsDetail =[];
    $scope.news =[];
    /* get token from local storage */
    var token;
    if(localStorage.userData){
        var userData = JSON.parse(localStorage.userData),
        token  = userData.token;
    };

    var id = $stateParams.id;
    blogsAndNewsService.getDetailsBlogsAndNews($scope,id,'',token);
    /* service call to get 5 latest blogs or news */
    blogsAndNewsService.getBlogsAndNews($scope,{'type':'news','limit':5},'',token);

    $scope.toLocalDate = function(date,type){
        return moment(date).utc().format(type);
    }
    $scope.goToBack = function(){
        $window.localStorage['position'] = 'news' ;
  /*      if($window.localStorage['pNavigateState']){
            $state.go($window.localStorage['pNavigateState']);
        }else{*/
            if(angular.isDefined(userData) && userData.userTypeId == 2){
                state = 'patientMain.news';
            }else if(angular.isDefined(userData) && userData.userTypeId == 1){
                state = 'providerMain.news';
            }else{
                state = 'main.news';
            }
            $state.go(state);
        //}
    }
    $scope.share =function(type,url){
        blogsAndNewsService.shareNewsOrblog(type,url,$scope)
    }
    $scope.readMore = function(type,id){
        if(angular.isDefined(userData) && userData.userTypeId == 2){
            state = 'patientMain.';
        }else if(angular.isDefined(userData) && userData.userTypeId == 1){
            state = 'providerMain.';
        }else{
            state = 'main.';
        }
        $state.go(state+type,{id:id},{reload:true});

    }

});

face2face.controller('blogsDetailCtrl',function($scope,serverRequestFactory,globalConstants,blogsAndNewsService,$stateParams,$window,$state){
    $scope.blogsAndNewsDetail =[];
    $scope.blogs =[];
    /* get token from local storage */
    var token;
    if(localStorage.userData){
        var userData = JSON.parse(localStorage.userData),
        token  = userData.token;
    };

    var id = $stateParams.id;
    blogsAndNewsService.getDetailsBlogsAndNews($scope,id,'',token);
    /* service call to get 5 latest blogs or news */
    blogsAndNewsService.getBlogsAndNews($scope,{'type':'blogs','limit':5},'',token);

    $scope.toLocalDate = function(date,type){
        return moment(date).utc().format(type);
    }
    $scope.goToBack = function(){
        $window.localStorage['position'] = 'news' ;
/*        if($window.localStorage['pNavigateState']){
            $state.go($window.localStorage['pNavigateState']);
        }else{*/
            if(angular.isDefined(userData) && userData.userTypeId == 2){
                state = 'patientMain.news';
            }else if(angular.isDefined(userData) &&  userData.userTypeId == 1){
                state = 'providerMain.news';
            }else{
                state = 'main.news';
            }
            $state.go(state);
       // }
    }
    $scope.share =function(type,url){
        blogsAndNewsService.shareNewsOrblog(type,url,$scope)
    }
    $scope.readMore = function(type,id){
        if(angular.isDefined(userData) && userData.userTypeId == 2){
            state = 'patientMain.';
        }else if(angular.isDefined(userData) && userData.userTypeId == 1){
            state = 'providerMain.';
        }else{
            state = 'main.';
        }
        $state.go(state+type,{id:id},{reload:true});

    }

});