﻿
/*provider module*/
var f2fProvider = angular.module('f2fProvider',['ui.router'],function(){

})
.run(function($rootScope,$state){
/*  $rootScope.$on("$stateChangeError", function (event, toState, toParams, fromState, fromParams, error) {
    $state.go("main.login");
  })*/;
})
.config(function($stateProvider,$httpProvider){
    // function to check the authentication // @sonam
    var Auth = ["$q", function ($q) {
       //  get token from local storage 
        var token;
        if(localStorage.userData){
          var userData = JSON.parse(localStorage.userData),
          token  = userData.token;
        };
        if (token && userData.userTypeId == 1 ) {
            return $q.resolve();
        } else {
            return $q.reject();
        }
    }];
      var require = function(tokenType) {
        return ["$q", function ($q) {
          if(localStorage[tokenType]){
            return $q.resolve();
          }else {
            return $q.reject();
          }
      }];
    }
$stateProvider
.state('providerMain', {
              url: '/providermain',
              abstract:true,
              views:{
                'header':{
                   templateUrl:'modules/provider/header/template/headerMain.html',
                   controller:'proHeaderCtrl'
                 },
                 'contents': {
                    templateUrl: 'templates/mainContainer.html'
                 },
                'footer':{
                  templateUrl:'modules/main/footer/template/footerMain.html',
                  controller:'footerCtrl'
                }                  
              },
            resolve: {
                auth: Auth
            }
              
  })
  .state('providerMain.providerDashboard', {
        url: '/proDashboard',
         views:{
          'container': {
               templateUrl: 'modules/provider/dashboard/template/provider-dashboard.html',
               controller:'providerDashboardCtrl'
                                    
             }                
        }
             
    })
    .state('providerMain.providerEditProfile', {
        url: '/proEditProf',
         views:{
          'container': {
               templateUrl: 'modules/provider/profile/templates/provider-edit-profile.html',
               controller:'providerProfilectrl'
                                    
             }                
        }
         
      })
    .state('providerMain.providerAccountSettings', { // Account Setting state @sonam
              url: '/AccountSettings',
               views:{
                'container': {
                     templateUrl: 'modules/provider/accountSettings/templates/providerAccountSettings.html',
                     controller:'accountSettingCtrl'
                                          
                   }                
              }
         
      })
      .state('providerMain.community', {   // consumer patient/HOME state
              url: '/community',
               views:{
                'container': {
                     templateUrl: 'modules/provider/community/template/provider-community.html',
                     controller:'communityCtrl'

                                          
                   }         
              }
        
      })
      .state('providerMain.communitySilos', {   // consumer patient/HOME state
              url: '/communitySilos',
               views:{
                'container': {
                     templateUrl: 'templates/community-silos.html',
                     controller:'communitySilosCtrl'

                                          
                   }         
              }
        
      })
      .state('providerMain.communityJoinTerms', {   // consumer patient/HOME state
              url: '/communityJoinTerms',
               views:{
                'container': {
                     templateUrl: 'templates/join-community.html',
                     controller:'communityJoinCtrl'

                                          
                   }         
              }
        
      })
   .state('providerMain.changePass', {    //change password state
               url: '/changePass',
                views:{
                 'container': {
                      templateUrl: 'templates/changePassword.html',
                      controller:'changePass'
                                           
                    }                
               }
          
   })

.state('providerMain.contactUs', {   // contact us page
           url: '/contactUs',
            views:{
             'container': {
                  templateUrl: 'templates/contactUs.html',
                  controller:'contactUs'
              }         
           }
     
   })

   .state('providerMain.calendar',{
                url:'/calendar/:conFlag?',
                views:{
                  'container':{
                    templateUrl:'modules/provider/calendar/templates/calendar.html',
                    controller:'proCalendarCtrl'
                  }
                }
   })
      .state('providerMain.calendarSetting',{
                url:'/calendarSetting',
                views:{
                  'container':{
                    templateUrl:'modules/provider/calendar/templates/calendarSetting.html',
                    controller:'proCalendarSettingCtrl'
                  }
                }
   })
     .state('providerMain.faqs', {
        url: '/faqs',
          views:{
           'container': {
              templateUrl: 'modules/main/faqs/template/faqs.html',
              controller:'faqsCtrl'
            }                
        }
                
      })
     .state('providerMain.aboutus', {
        url: '/aboutus',
          views:{
           'container': {
              templateUrl: 'modules/main/aboutus/template/about-us.html',
              controller:'aboutusCtrl'
            }                
        }
                
      })
      .state('providerMain.privacyTerms', {
        url: '/privacyTerms',
          views:{
           'container': {
              templateUrl: 'modules/main/privacyTerms/template/privacy-terms.html',
              controller:'privacyTermsCtrl'
            }                
        }
                
      })
      .state('providerMain.inbox', {
        url: '/inbox',
          views:{
           'container': {
              templateUrl: 'templates/inbox.html',
              controller:'inboxCtrl'
            }                
         }
        })
      .state('providerMain.news',{
                  url:'/news',
                  views:{
                    'container':{
                      templateUrl:'templates/news.html',
                      controller:'newsCtrl'
                    }
                  }
      })
        .state('providerMain.newsDetail',{
                  url:'/newsDetail/:id',
                  views:{
                    'container':{
                      templateUrl:'templates/newsDetail.html',
                      controller:'newsDetailCtrl'
                    }
                  }
        })

      .state('providerMain.blogsDetail',{
          url:'/blogsDetail/:id',
          views:{
            'container':{
              templateUrl:'templates/blogsDetail.html',
              controller:'blogsDetailCtrl'
            }
          }
      })
      .state('providerMain.patients',{
              url:'/patients',
              views:{
                'container':{
                  templateUrl:'modules/provider/patients/templates/patientlist.html',
                  controller:'providerPatientCtrl'
                }
              }
      })
      .state('providerMain.videoConsultingRoom',{
        url:'/videoConsultingRoom/:conFlg',
        views:{
          'container':{
            templateUrl:'modules/provider/videoConsultingRoom/template/videoConsultingRoom.html',
            controller:'videoConsultingRoomCtrl'
          }
        },
        resolve: {
        auth: require('onDemandConsultRecord')
      }
      })
    .state('providerMain.consent', {   
      url: '/consent',
       views:{
        'container': {
          templateUrl: 'templates/consent.html',
          controller:'consentCtrl'
        }         
      }
    })
    .state('providerMain.modal', {   
      url: '/model',
       views:{
        'container': {
          templateUrl: 'templates/modal.html',
          controller:'modalCtrl'
        }         
      }
    })
    .state('providerMain.addCommunityTopics', {   
      url: '/addCommunityTopics/:id',
       views:{
        'container': {
          templateUrl: 'templates/addCommunityTopics.html',
          controller:'addCommunityTopicsCtrl'
        }         
      }
    })
    .state('providerMain.viewCommunityTopic', {   
      url: '/viewCommunityTopic',
       views:{
        'container': {
          templateUrl: 'templates/viewCommunityTopic.html',
          controller:'viewCommunityTopicCtrl'
        }         
      }
    })
});