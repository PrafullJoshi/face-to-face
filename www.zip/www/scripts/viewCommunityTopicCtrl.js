face2face.controller("viewCommunityTopicCtrl",function($scope, globalConstants,serverRequestFactory, $state, requiredFactory,otherValidationCheck,$stateParams,$window) {
 /** To get the token from localstorage **/
  if(localStorage.userData){
    var userData = JSON.parse(localStorage.userData);
    var token  = userData.token;
    var userType = userData.userTypeId;
    $('.navbar-nav a.active').removeClass('active');
    if(userData.userTypeId == 1){
  	  $("#providerCommunity").addClass('active');
  	}
    else{
  	  $("#patientCommunity").addClass('active');
    }

    if(localStorage.communityTopicDetail) {
      var topicDetail = JSON.parse(localStorage.communityTopicDetail);
      $scope.topicid = topicDetail.id;
      $scope.title = topicDetail.title;
      $scope.titleid = topicDetail.titleid;
      $scope.joinedUser = topicDetail.topic.joined_user_count;
      console.log($scope.title)
    } 
  }

    $scope.init = function(){
        $scope.postDescription = '';
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.viewForum+$scope.topicid, 'GET', {},token);
        promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.topicData = res.data.data;
                if($scope.topicData.Comments){
                    if(Object.keys($scope.topicData.Comments).length <= 5){
                        $scope.seeMore = false;
                        $scope.topicData.topicComments = $scope.topicData.Comments;    
                    }else{
                        $scope.seeMore = true;
                        $scope.topicData.topicComments = {};
                        for(var i=1; i<=5; i++){
                            $scope.topicData.topicComments[i] = $scope.topicData.Comments[i];
                        }
                    }
                    
                } 

            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });

        var promise1 = serverRequestFactory.serverComm(globalConstants.serviceUrl.getLastcommentedBy+$scope.topicid, 'GET', {},token);
        promise1.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                $('#loader').hide();
                $scope.lastCommentData = res.data.data;
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        });

    }

    $scope.showMore = function(){
        $scope.seeMore = false;
        $scope.topicData.topicComments = $scope.topicData.Comments;
    }

    $scope.addPost = function(){
        if(!!$scope.postDescription){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addComment, 'POST', {
                "forum_id": $scope.topicid,
                "description":$scope.postDescription
            },token);
            promise.then(function(res) {
                if (res.data.status == true && res.data.data == "None") {
                    $('#loader').hide();
                   $scope.postDescription = "";
                    $scope.init();
                } else {
                    $('#loader').hide();
                }
            }, function(err) {
                $('#loader').hide();
            });    
        }
    }

    $scope.dateIncommunityFormat = function(data){
        if(data){
            var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            var days =["Sun","Mon","Tues","Wed","Thus","Fri","Sat"];
            var date = new Date(data);
          //console.log(date, date.getMonth(),monthNames[(date.getMonth())] + "," + date.getDate() +" "+  date.getFullYear())
            // return monthNames[date.getMonth()] + " " + date.getDate() +", "+  date.getFullYear();
            return moment(data).format('ll');
        }

    }

    $scope.reply = function(index,from,parentindex){
        if(from == 'parent'){
            $scope.replyIndex = index;
        }else{
            $scope.childreplyIndex = index;
            $scope.parentIndex = parentindex;
        }
    }


    $scope.postreply = function(commentvalue){
        if(!!commentvalue.replyDescription){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.commentReply, 'POST', {
                "forum_id": $scope.topicid,
                "parent": commentvalue.parent  == 0 ? commentvalue.id : commentvalue.parent,
                "description": commentvalue.replyDescription
            },token);
            promise.then(function(res) {
                if (res.data.status == true && res.data.data == "None") {
                    $('#loader').hide();
                    $scope.replyIndex = -1;
                    $scope.childreplyIndex = -1;
                    $scope.parentIndex = -1;
                    commentvalue.replyDescription = "";
                    $scope.init();
                } else {
                    $('#loader').hide();
                }
            }, function(err) {
                $('#loader').hide();
            });
        }
    } 

    $scope.deleteComment = function(commentid){
        $scope.commentid = commentid;
        $('#confirmationCommentDelete').modal('show');
    }

    $scope.confirmDeleteComment = function(){
       var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.deleteComment+$scope.commentid, 'PUT', {},token);
        promise.then(function(res) {
            if (res.data.status == true) {
                $('#loader').hide();
                $('#successDeleteComment').modal('show');
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        }); 
    }

    $scope.successDeleteComment = function(){
        $scope.init();
    }

    $scope.deleteForum = function(){
        $('#confirmation').modal('show');
    }

    $scope.confirmDelete = function(){
       var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.deleteForum+$scope.topicid, 'PUT', {},token);
        promise.then(function(res) {
            if (res.data.status == true) {
                $('#loader').hide();
                $('#success').modal('show');
            } else {
                $('#loader').hide();
            }
        }, function(err) {
            $('#loader').hide();
        }); 
    }

    $scope.successDelete = function(){
        if(token){
          $window.localStorage['communityData'] = JSON.stringify({"provider_type_id":$scope.titleid,"title":$scope.title});
          if(userType == 2){
            $state.go("patientMain.communitySilos"); // consumer 
          }else if(userType == 1){
            $state.go("providerMain.communitySilos"); // provider
          }
        }else{
          $window.localStorage['pNavigateState'] = $state.current.name;
          $state.go("main.login");
        }

    }

  // Call init method
  $scope.init();

});
