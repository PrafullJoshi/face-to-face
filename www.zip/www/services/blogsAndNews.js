/*
* @Service  for blogs and news for consumer and provider.
* @Author Sonam
*/
face2face.service('blogsAndNewsService',function(serverRequestFactory,globalConstants,$timeout,convertDate,$location,Socialshare){
    
  	/*
    * Function to get blogs and news for consumer & provider 
    @parameters #slientCall - to show loader or not #scope #token
    @put 
    */
    this.getBlogsAndNews= function(scope,data,slientCall,token){
    	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.blogsAndNews, 'POST',data,token,'',slientCall);
      	promise.then(function(res) {
        	if (res.data.status == true && res.data.data != "None") {
            if(data.type == 'news'){
              scope.news = res.data.data;
            }else if(data.type == 'blogs'){
              scope.blogs = res.data.data;
            }
          		$('#loader').hide();
            } else {
              if(data.type == 'news'){
            	  scope.news=[];
              }else{
                scope.blogs =[];
              }
          		$('#loader').hide();
        	}
      	}, function(err) {
        	$('#loader').hide();
      	});
      	

    };
    /*
    * Function to get details of blogs and news for consumer & provider 
    @parameters #slientCall - to show loader or not #scope #token
    @put 
    */
    this.getDetailsBlogsAndNews= function(scope,id,slientCall,token){
    	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.detailsblogsAndNews+id, 'GET', {},token,'',slientCall);
      	promise.then(function(res) {
        	if (res.data.status == true) {
          		scope.blogsAndNewsDetail = res.data.data;
          		$('#loader').hide();
            } else {
            	scope.blogsAndNewsDetail=[];
          		$('#loader').hide();
        	}
      	}, function(err) {
        	$('#loader').hide();
      	});
      	

    };
    this.shareNewsOrblog = function(type,url,scope){
      if(type=='email'){
        var attrs= {
          'socialshareSubject':scope.blogsAndNewsDetail.posts.title,
          //'socialshareBody':angular.element(scope.blogsAndNewsDetail.posts.description).text(),
        }

      }else if(type=='facebook'){
        var attrs = {
            'socialshareVia':'744272235723774',
            'socialshareUrl': globalConstants.gHost+'/#'+$location.url(),
            'socialshareType':'feed',
            'socialshareText':scope.blogsAndNewsDetail.posts.title,
            'socialshareMedia':scope.blogsAndNewsDetail.posts.image,
            //'socialshareDescription':angular.element(scope.blogsAndNewsDetail.posts.description).text().substring(0,130),
          }
      }else{
        var attrs =  {
            //'socialshareVia': 'f2f-qa.kiwireader.com/#'+$location.url(),
            'socialshareUrl': globalConstants.gHost+'/#'+$location.url(),
            'socialshareText':scope.blogsAndNewsDetail.posts.title ,
            //'socialshareMedia':$scope.blogsAndNewsDetail.posts.image,
            //'socialshareDescription':angular.element(scope.blogsAndNewsDetail.posts.description).text(),
          }
      }

    Socialshare.share({
      'provider': type,
      'attrs': attrs,
    })
  }

});