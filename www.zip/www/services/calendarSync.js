// generic method to validate password 
face2face.service('calendarSync',function(serverRequestFactory,globalConstants,loadingFactory,commonGetterService){
  this.calendarEvents = {};
  this.getCalendarEvents = function(token){

   console.log("in")
    hasReadWritePermission();
    function hasReadWritePermission() {
      window.plugins.calendar.hasReadWritePermission(
        function(result) {
          // if this is 'false' you probably want to call 'requestReadWritePermission' now
         // alert(result);
        }
      )
    }

    function requestReadWritePermission() {
      // no callbacks required as this opens a popup which returns async
      window.plugins.calendar.requestReadWritePermission();
    }
   var that = this;
   var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getAppointments+'scheduled','POST',{},token);
   promise.then(function(res) {
  
       if (res.data.status == true && res.data.data != "None") {
           loadingFactory.hide();
           that.calendarEvents = res.data.data;           
         //  if(!commonGetterService.getToken()){
            for(var i=0; i<that.calendarEvents.length;i++){
             var k = i; 
            
             var start = new Date((that.calendarEvents[k].start_time).replace(/-/g,"/"));
            // var start = new Date((that.calendarEvents[k].start_time))
             var end = new Date((that.calendarEvents[k].end_time).replace(/-/g,"/"));
             that.deleteEvent('scheduled appointments','','',start,end,k);

            }
            
          
       }else {
           loadingFactory.hide();
       }
   }, function(err) {
       loadingFactory.hide();
      
     });
  },
  this.createEvent = function(title,eventLocation,notes,startDate,endDate){
    //alert("in")
    var success = function(msg){
     // alert(msg +"  ***create**");
    };
    var error = function(msg){
    //  alert(msg);
    };

    window.plugins.calendar.createEvent(title,eventLocation,notes,startDate,endDate,success,error);
     
  },
  this.deleteEvent = function(newTitle,eventLocation,notes,startDate,endDate,i){
    var that = this;
    var success = function(msg){
     // alert(msg +"  ***del**");
      if(i>=(that.calendarEvents.length-1)){
        that.updateEvent('scheduled appointments','','',startDate,endDate);
      }
     
    };
    var error = function(msg){
      that.createEvent('scheduled appointments','','',startDate,endDate);
      //alert(msg);

    };
    window.plugins.calendar.deleteEvent(newTitle,eventLocation,notes,startDate,endDate,success,error);

  },
  this.updateEvent = function(newTitle,eventLocation,notes,startDate,endDate,i){

   var that = this;
   for(var i=0; i<that.calendarEvents.length;i++){
    var k = i; 
   // alert(JSON.stringify(that.calendarEvents[k]));
   // alert(startDate)
    var start = new Date((that.calendarEvents[k].start_time).replace(/-/g,"/"));
    var end = new Date((that.calendarEvents[k].end_time).replace(/-/g,"/"));
    that.createEvent('scheduled appointments','','',start,end,k);

   }
  }


});