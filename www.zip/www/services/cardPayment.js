// generic method for card payment
face2face.service('cardPayment',function(globalConstants,){
	
});