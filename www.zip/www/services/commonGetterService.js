face2face.service('commonGetterService',function(serverRequestFactory,globalConstants,$window,$timeout,loadingFactory,$state,Scopes,logOut,showModalService,consultRoomService,$ionicPopover){
    // To get the token from localstorage
    var inAppBrowserRef ;
    var self = this;
    this.getExistingInquiryForms = function(scope,patientId,inquiryId,token){
        var url = globalConstants.serviceUrl.getExistingInquiryForms+patientId + '/'+ inquiryId;
        var promiseinqType = serverRequestFactory.serverComm(url,'GET',{}, token);  
        promiseinqType.then(function(res){
           if(res.data.status == true && res.data.data !== "None"){ 
                scope.exitingInquiryForms = res.data.data;
                loadingFactory.hide();
           }else{
                scope.exitingInquiryForms =[];
                scope.onDemand.inquiry_type ="";
                scope.onDemand.inquiry ="";
                loadingFactory.hide();
           }

       },function(err){              
          loadingFactory.hide();
        });
    },

    this.getProviderType = function(scope,token) {
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.providerType, 'GET', {});
        promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                loadingFactory.hide();
                scope.providerTypeData = res.data.data;
                if (angular.isDefined(scope.appointmentData)) {
                    if($window.localStorage['RecommendFollowUp']){
                        var RecommendFollowUp = JSON.parse($window.localStorage['RecommendFollowUp']);
                        scope.appointmentData.provider_type_id = RecommendFollowUp.silo_id.toString();
                        scope.getSpecialities(scope.appointmentData.provider_type_id); // get specialities of selected provider type
                    }else{
                        scope.appointmentData.provider_type_id = "";
                    }
                    
                    //scope.getSpecialities(scope.onDemand.provider_type_id); // get specialities of selected provider type
                }
            } else {
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
        });
    },
    this.getSpecialities = function(scope,providerTypeId,token,index,type,notreset,age) {
        var promiseS = serverRequestFactory.serverComm(globalConstants.serviceUrl.getSpecialities + providerTypeId + '/' +age , 'GET', {});
        promiseS.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {                
                if(type == 'multi'){
                    scope.specialitiesMData[index]= res.data.data; 
                }else{
                    scope.specialitiesData = res.data.data;
                    if($window.localStorage['RecommendFollowUp']){
                        var RecommendFollowUp = JSON.parse($window.localStorage['RecommendFollowUp']);
                        //scope.onDemand.speciality_id = Object.keys(scope.specialitiesData)[RecommendFollowUp.speciality_id -1];
                        scope.appointmentData.speciality_id.push(RecommendFollowUp.speciality_id.toString());
                    }else{
                        !notreset ? scope.appointmentData.speciality_id = '' :angular.noop();
                    }
                    scope.appointmentData.speciality_id ? scope.showAgeWarning(scope.appointmentData.speciality_id) : angular.noop();
                }
                loadingFactory.hide();
            } else {
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
        });
    },
    this.getInq = function(scope, id,token) {
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getInqByType + id, 'GET', {}, token);
        promise.then(function(res) {
            if (res.data.status == true && res.data.data !== "None") {
                scope.inqList = res.data.data;
                scope.appointmentData.inquiry = "";
                loadingFactory.hide();
            } else {
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
        });
    },
    this.getpatientInsurances = function(scope, patientId,token) {
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getInsuranceDropdown + patientId, 'GET', {}, token);
        promise.then(function(res) {
            if (res.data.status == true && res.data.data !== "None") {
                scope.InsurancesList = res.data.data;
                loadingFactory.hide();
            } else {
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
        });

    },
    this.getInsurancesPlanByStateId = function(scope,state,token){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getPlanCategory+state, 'GET', {}, token);
        promise.then(function(result) {
            if (result.data.status == true && result.data.data != "None") {
                loadingFactory.hide();
                scope.InsurancesList = result.data.data;
            }else{
                loadingFactory.hide();
            }
        }, function(err) {
          loadingFactory.hide();
        });
    }

    this.getAgeGroupDropDown = function(scope,token){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.ageGroupDropDown, 'GET',{},token);
        promise.then(function(res){
            if(res.data.status && res.data.data!="None"){
                scope.ageGroupDropDown = res.data.data;
                loadingFactory.hide();

           }else{
                loadingFactory.hide();
           }
        }, function(err) {
            loadingFactory.hide();
        });
    }

    this.getStates = function(scope){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getStates, 'GET', {});
        promise.then(function(result) {
            if (result.data.status == true && result.data.data != "None") {
                loadingFactory.hide();
                scope.statesData = result.data.data;
            }else{
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
    
        });
    }

    this.getToken = function(){
        if(localStorage.userData){
            return JSON.parse(localStorage.userData).token;
        }
    }

    this.getUsertype = function(){
        if(localStorage.userData){
            return JSON.parse(localStorage.userData).userTypeId;
        }
    }

    this.notificationReceivedCallBack = function(notification){
        var goToState = function(status){
             if(notification.category){
                if(status == 1){
                    if(localStorage.userData){
                        var category = JSON.parse(notification.category);
                        $state.go(category.name,{id:category.id},{reload:true});
                    }else{
                        $state.go('signin');
                    }
                }
            }

        }
       
        if(notification.tap){
            goToState(1);
        }else{
            if(JSON.parse(notification.category).name == 'logout'){
                if(ionic.Platform.isIOS()){
                    inAppBrowserRef.close();
                }else{
                    PGMultiView.dismissView();      
                }
                
                logOut.logOut();
            }else{
                navigator.notification.confirm(notification.text, goToState, notification.title, ['OK','Cancel']);
            }
            
        }



    }

    this.updateNotificationToken = function(token){
        if(this.getToken()){
            serverRequestFactory.serverComm(globalConstants.serviceUrl.notificationTokenUpdate,'POST',{'device_id':token,'os_type':ionic.Platform.isIOS()?'iOS':'Android'},this.getToken(),'',true); //call to update token
        }
    }

    this.getProviderInquiry = function(scope,id,newExist,consultTyepe) {
        scope.typeList = [];
        scope.appointmentData.inquiry_type = "";
        if(consultTyepe == 'on-demand'){
            if(newExist == 'exist'){
                var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getExistingInquiriesFromProviderGroup+id+'/'+scope.appointmentData.patient_id, 'GET', {},this.getToken());
            }else{
                var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getInquiryFromProviderGroup+id, 'GET', {},this.getToken());
            }
           }
        else{
            if(newExist == 'exist'){
             var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getExistingInquiriesFromSpeciality+id+'/'+scope.appointmentData.patient_id, 'GET', {},this.getToken());
            }else{
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getInquiryFromSpeciality+id, 'GET', {},this.getToken());
           }
         }
         promise.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                loadingFactory.hide();
                scope.typeList = res.data.data;
            } else {
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
        });
    }
    this.getProviderGroup = function(scope,id) {
        var age = scope.age.split(' ');
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getProviderGroupFromType+id+'/' + age, 'GET', {},this.getToken());
        promise.then(function(res) {
          if (res.data.status == true && res.data.data != "None") {
              loadingFactory.hide();
              scope.providerGrpData = res.data.data;
              scope.appointmentData.provider_group_id ? scope.showAgeWarning(scope.appointmentData.provider_group_id) : angular.noop();
          } else {
              loadingFactory.hide();
          }
      }, function(err) {
          loadingFactory.hide();
      });
    }

    this.openEmr = function(link,meetingData,id,scope,token,type){
        if(link){
                PGMultiView.loadView(link,'3', success, function(){console.log("error")});
                if(meetingData != {}){
                  consultRoomService.zoomInit('',meetingData,id,scope,token,type);
                }
                  function success(e){
                    goToState(e);
                  }
                  //$timeout(function(){

                           //zoom.startMeeting('sonam',meeting_id,success,fail);},40000)

            //}
            
        }else{
            var promise1 = serverRequestFactory.serverComm(globalConstants.serviceUrl.getOpenEmrLink,'GET',{},this.getToken());
            promise1.then(function(res){
                if(res.data.status == true){
                    loadingFactory.hide();
//                    if(ionic.Platform.isIOS()){
//                        inAppBrowserRef = window.open(res.data.data.emr_url,'_blank');
//                    }else{
                        PGMultiView.loadView(res.data.data.emr_url, "3", success, function(){console.log("error")});
                   // }
                  
                  //inAppBrowserRef = window.open(res.data.data.emr_url,'_blank');
                }else{
                  loadingFactory.hide();
                }
            },function(err){
                loadingFactory.hide();
            });
        }
        function success(){
            var currentTime = new Date();
            var duration = currentTime - (new Date(localStorage.activityTime)) ;
            duration = Math.round(((duration % 86400000) % 3600000) / 60000);
            localStorage.activityTime = currentTime;
            Scopes.store('Inactivitycheck',true);
        };
    }
    this.checkOndemandAvailability = function($scope,callback,params){
        var timezone = new Date().getTimezoneOffset() / 60;
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.checkOndemandAvailability+'timezone='+timezone, 'GET', {});
        promise.then(function(result) {
        if (result.data.status == true && result.data.data == "None") {
            loadingFactory.hide()
            if(callback){
                callback(params);
            }else{
                $state.go('mainView.onDemand');
            }
            
        }else{
            loadingFactory.hide()
            if(callback){
                $scope.oModal.hide();
                $scope.showCancelButton = true;
            }
            $scope.startTime = result.data.data.start_time;
            $scope.endTime = result.data.data.end_time; 
            showModalService.show($scope,'modules/consumer/scheduleAppointment/template/onDemandTimeCheckModal.html');
        }
        }, function(err) {
            loadingFactory.hide()
        });

        
    }

    this.openElearning = function(link){
        if(link){
            PGMultiView.loadView(link, "4", success, function(){console.log("error")}); 
        }
        function success(e){
            goToState(e);
            var currentTime = new Date();
            var duration = currentTime - (new Date(localStorage.activityTime)) ;
            duration = Math.round(((duration % 86400000) % 3600000) / 60000);
            localStorage.activityTime = currentTime;
            Scopes.store('Inactivitycheck',true);
        };
    }

    function goToState (e){
        if(e){
            switch(e){
                case 'Inbox':
                    $state.go('mainView.inbox');
                break;
                case 'Community':
                    $state.go('mainView.communityListing');
                break;
                case 'Virtual Health':
                    if(self.getUsertype() == 2){
                        $state.go('mainView.conVirtualHealth');
                    }else{
                        $state.go('mainView.proVirtualHealth');
                    }
                break;
            }
        }
    }


    this.getMedicalRecordCategory = function(data,token,scope){
        
        var promiseS = serverRequestFactory.serverComm(globalConstants.serviceUrl.getMedicalRecordCategory, 'POST',data,token);
        promiseS.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                loadingFactory.hide();
                scope.medicalRecordCategory = res.data.data;
                var flag = true;
                angular.forEach(res.data.data,function(value,key){
                    if(value.access == 'No'){
                        flag = false;
                    }
                })
                scope.selectAll = flag;
                showModalService.show(scope,'modules/consumer/scheduleAppointment/template/shareMedicalRecord.html');
            } else {
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
        });        
    }


    this.shareMedicalRecord = function(data,token,scope){
        data.emr_history_category_id =  Scopes.get('emr_history_category_id');
        var promiseS = serverRequestFactory.serverComm(globalConstants.serviceUrl.shareMedicalRecord, 'POST',data,token);
        promiseS.then(function(res) {
            if (res.data.status == true && res.data.data != "None") {
                loadingFactory.hide();
                Scopes.delete('emr_history_category_id');
            } else {
                loadingFactory.hide();
            }
        }, function(err) {
            loadingFactory.hide();
        }); 
    }

    this.saveMedicalRecords = function(data,selectAll){
        var emr_history_category_id = {}
        angular.forEach(data,function(value,key){
            if(selectAll || value.share == 'Yes' || value.access == 'Yes'){
                emr_history_category_id[value.emr_history_category_id] = value.access
            }
        })
        Scopes.store('emr_history_category_id',emr_history_category_id);
        //$window.localStorage['emr_history_category_id'] = JSON.stringify(emr_history_category_id);
        showModalService.hide(true);
        //console.log(emr_history_category_id)
            
    }

    this.showSpecialityDescription = function(description,title,$scope,$event) {
        var template = '<ion-popover-view><ion-header-bar> <h1 class="title">'+title+'</h1> </ion-header-bar> <ion-content><p class="padding-left-right">'+ description + '</p></ion-content></ion-popover-view>';

        $scope.popover = $ionicPopover.fromTemplate(template, {
            scope: $scope
        });
        $scope.popover.show($event);
    }

})
