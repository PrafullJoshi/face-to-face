/*
* @Service  to fetch consent .
* @Author Sonam
*/
face2face.service('consentService',function(serverRequestFactory ,loadingFactory){
	/*
    * Function to get consent 
    @parameters #slientCall - to show loader or not #scope #token
    @put 
    */
    this.getConsent= function(scope,url){
    	var promise = serverRequestFactory.serverComm(url, 'GET');
      	promise.then(function(res) {
        	if (res.data.status == true && res.data.data != "None") {
        		scope.consent = res.data.data.page;
           
          	loadingFactory.hide();
          } else {
          	scope.consent = 'Data is not added from admin.'
        		loadingFactory.hide();
      	  }
      	}, function(err) {
        	loadingFactory.hide();
      	});
      	

    };
})

/*
* @Controller  for consent .
* @Author Sonam
*/
face2face.controller('consentCtrl',function(consentService,globalConstants,$scope){
	angular.element(document.querySelector(".navbar-nav a.active")).removeClass('active');
	consentService.getConsent($scope,globalConstants.serviceUrl.consentPage);
})
