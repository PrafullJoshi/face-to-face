/*
* @Service  to fetch consent .
* @Author Sonam
*/
face2face.service('consultRoomService',function(serverRequestFactory ,loadingFactory,showModalService,globalConstants,toastMsg){
  /*
    * Function to schedule a follow up
    @parameters #slientCall - to show loader or not #scope #token
    @Post request - data has key -  {consult_id,consultation_start_date,consultation_start_time,consultation_end_time}
    */
    var self = this;
    this.scheduleFollowUp= function(data,token,scope){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.scheduleFollowUp, 'POST',data, token);
      promise.then(function(res) {
        if (res.data.status == true) {
          toastMsg.show("You have successfully scheduled the followup");
          scope.functionCall('hideSchedule');
          loadingFactory.hide();
        } else {
          toastMsg.show(res.data.message);          
          loadingFactory.hide();
        }
      }, function(err) {
        loadingFactory.hide();
      });
    };

    this.endConference = function(manual,scope,id,token,from,slientCall){
        var promiseExtend = serverRequestFactory.serverComm(globalConstants.serviceUrl.endMeeting + id+'/'+manual,'POST',{},token,'',slientCall);
        promiseExtend.then(function(res) {
          if (res.data.status == true) {
            scope.alreadyEnded = true;
            toastMsg.show("Meeting has been ended");
            if(from == 'consumer'){
              scope.functionCall('showModal','rateProviders');
            } 
            loadingFactory.hide();
          } else if (res.data.status == false) {
            //toastMsg.show(res.data.message);
            loadingFactory.hide();
          }
        }, function(err) {

        })
    }
    this.getDiagnosis =function($scope){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getDiagnosis, 'POST', {
        "type":"Personal Note",
        "consultation_id": $scope.consultData.consult_id
        }, token,'','silent');
        promise.then(function(res) {
          if (res.data.status == true) {
              $scope.notes = res.data.data.notes;
              $scope.saveDiagnosisData = res.data.data;
              loadingFactory.hide();
          }
      }, function(err) {
          loadingFactory.hide();
      });
    }
    this.saveDiagnosis = function(form,$scope,onSave) { 
      form.trim();
      if (form) {
          var id = 0;
          if($scope.saveDiagnosisData) {
            id = $scope.saveDiagnosisData.id;
          }
          $scope.successmsg = '';
          // if(form.length==1 || $scope.saveDiagnosisData) {
              var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.saveDiagnosis, 'POST', {
                  "patient_id":$scope.consultData.patient_id?$scope.consultData.patient_id:$scope.consultData.patient.id,
                  "id":id,
                  "type":"Personal Note",
                  "issues": "Consultation",
                  "consultation_id": $scope.consultData.id,
                  "notes": form,
                  "consult_type":$scope.consultData.consult_type,
                  "inquiry":$scope.consultData.inquiry_name,
                  "provider_name":$scope.consultData.provider.title+' '+$scope.consultData.provider.fname+' '+$scope.consultData.provider.lname
              }, token,'','silent');
              promise.then(function(res) {
                  if (res.data.status == true) {
                      $scope.saveDiagnosisData = res.data.data;
                      if(onSave)
                        toastMsg.show("Save successfully");
                      loadingFactory.hide();
                  } else {
                      loadingFactory.hide();
                  }
              }, function(err) {
                  loadingFactory.hide();
              });
          //}
      }
    }
  this.zoomInit = function(callback,meetingData,id,scope,token,type){
    zoom.initService("bMCNzPvn3a5dMd1fSmuPQen5jNZOLno2pac4","GKjrSooa2EzLcC851ud724Glp0zwbnUeRcVe",'zoom.us',success1,error);
    function success1(e){
      switch(e){
        case 'startOrJoin':
          if(type == 1){
            zoom.startMeeting('abcd',meetingData,function(){},function(){});
          }else{
            zoom.joinMeeting('abcd',meetingData,function(){},function(){});
          }          
        break;
        case 'end':
          var from = "consumer";
          if(type == 1){
            from = 'provider';
          }
          self.endConference('manual',scope,id,token,from,true);
        break;
      }
    }
    function error(e){
      console.log(e);
    }
  }
})