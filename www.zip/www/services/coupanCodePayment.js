/*
* @Service  to get appointments list for consumer and providers
* @Author
*/
face2face.service('coupanCodePaymentService',function(serverRequestFactory,globalConstants,loadingFactory,toastMsg,otherValidationCheck,showModalService,requiredFactory,Scopes,commonGetterService){
    
  /*
    * Function to get appointments for consumers/providers

    */
    var that = this;
    this.checkCoupanCode = function(data,scope,token,errId){

      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.verifyCouponCode,'POST',data,token);  // get the consumer detail list  

      promise.then(function(res){
      var res = res.data;
      if(res.status == true && res.data != "None"){
          loadingFactory.hide();          
          toastMsg.show("Coupon code applied successfully");
          scope.providersDetails.consultation_total_charge = res.data.amount;
          scope.coupanCodeError = false;
       }
       else if(res.status == false){
           scope.appointmentData.coupon_code = '';
           document.getElementById(errId).innerHTML= "Invalid coupon code";
           scope.coupanCodeError = true;
           loadingFactory.hide();
       }


      },function(err){ 
        loadingFactory.hide();
      })

    },

      this.getCards = function(scope,token){
          scope.list = {};
          scope.noCards = '';
          scope.listofcards = [];
          var promiseforCards = serverRequestFactory.serverComm(globalConstants.serviceUrl.stripCardList,'POST',{},token);  // get the consumer detail list
          promiseforCards.then(function(res){
          console.log(JSON.stringify(res));
          var res = res.data;
          if(res.status == true && res.data != "None"){
              var result = res.data;
              if(result.length ==0){
                scope.noCards = "No card added. Please add a card to continue";
              }
              for(var i = 0;i<result.length;i++){
                  scope.listofcards.push({cardNo : 'XXXXXXXXXXXX'+result[i].last4,name : result[i].name,stripID : result[i].id , selectedid : res.stripe_card_id,date:'Expires : '+result[i].exp_month+'/'+result[i].exp_year});
              if(res.stripe_card_id == result[i].id){
                scope.list.selectedCard = scope.listofcards[i];
                if(scope.appointmentData)
                scope.appointmentData.stripe_card_id = result[i].id; // only for on demand
                
              }
          }
          loadingFactory.hide();

         }
         else if(res.data == "None"){
          scope.noCards ="No card added. Please add a card to continue";
          loadingFactory.hide();
         }

        },function(err){
          scope.noCards ="No card added. Please add a card to continue";
          scope.noSamePlans = 'Oops! some error occured. Please try again later'; 
          loadingFactory.hide();
        })
      },
      this.checkCouponCode = function(scope,token){
         var data = {
          "coupon_code"  : scope.appointmentData.coupon_code,
          "consult_type" : scope.appointmentData.consult_medium == 'on-demand',
          "speciality"   : [scope.appointmentData.speciality_id] ,
          "amount"       : scope.providersDetails.total_amount
        }

        that.checkCoupanCode(data,scope,token,'coupon_codeError');
      },
      this.updateCardIdOnchange = function(id,scope,token){
        if(id){
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateDefaultCard + id ,'GET',{},token,'',true);  // get the consumer detail list  
            promise.then(function(res){
                var res = res.data;
                if(res.status == true){
                    loadingFactory.hide();              
                }
                else if(res.status == false){
                    loadingFactory.hide();
                }
            },function(err){ 
                loadingFactory.hide();
           })
        }
      },
      this.submitSchedule = function(scope,token,form,type){
        document.getElementById('policyErr').innerHTML ='';
        if(requiredFactory.validateBeforeSubmit(form,scope) && scope.noCards == '' && scope.appointmentData.terms_of_use ){
            delete scope.appointmentData.inquiry_type;
            delete scope.appointmentData.inquiry;
            delete scope.appointmentData.stateName;
            delete scope.appointmentData.patientName
            scope.appointmentData.consult_type = "onDemand";
            scope.appointmentData.speciality_unit_charge = scope.providersDetails.total_amount;
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.scheduledAppointment,'POST',scope.appointmentData,token);  // get the consumer detail list  
            promise.then(function(res){
              //  
                if(res.data.status == true){
                    Scopes.delete('appointmentData');
                    Scopes.delete('addressOnCon');
                    if(type == 'onDemand'){
                      scope.templateUrl = 'modules/consumer/scheduleAppointment/template/connectingtoConsult.html';
                      //scope.templateUrl = '';
                    }
                    else{
                     scope.functionCall('hideModal');
                     // if(Scopes.get('emr_history_category_id')){
                     //    commonGetterService.shareMedicalRecord({consultation_id:[res.data.data.consultation_id],patient_id:scope.appointmentData.patient_id,provider_id:[scope.providersDetails.id]},token);
                     //  }
                     $state.go("mainView.thankYou").then(function(){
                         $ionicHistory.clearHistory();
                         $ionicHistory.clearCache();

                     }); 
                    }
                    loadingFactory.hide();
                }else if(res.status == false){
                    toastMsg.show(res.data.message);
                    loadingFactory.hide();
                }
            },function(err){ 
                loadingFactory.hide();
            })
        }else{
            if(scope.noCards != ''){
                toastMsg.show('Please select any card for payment');
            }else if(!scope.appointmentData.terms_of_use){
                document.getElementById('policyErr').innerHTML = 'Please accept Terms & conditions'
            }

        }
      },
      this.continueOndemand = function(scope,token,form){
        scope.termsnConditions = '';
        if (requiredFactory.validateBeforeSubmit(form, scope) && scope.noCards == '') {
            if(scope.appointmentData.terms_of_use == 'Y'){
              var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.updateonDemandAppointment, 'POST', {
                  "id": scope.onDemandAppointmentId,
                  //"consultation_name": $scope.scheduledObj.consultation_name,
                 // "consultation_lname": $scope.scheduledObj.consultation_lname,
                 // "consultation_dob": $scope.scheduledObj.consultation_dob,
                  "coupon_code": scope.appointmentData.coupon_code,
                  "consultation_total_charge": scope.appointmentData.consultation_total_charge,
                  "speciality_unit_charge": scope.providersDetails.total_amount,
                  "stripe_card_id": scope.appointmentData.stripe_card_id,
                  "patient_id": scope.appointmentData.patient_id,
                  "speciality_id": scope.appointmentData.speciality_id

              }, token);

              promise.then(function(res) {
                  if (res.data.status == true && res.data.data != "None") {
                     loadingFactory.hide();
                      scope.meeting_id = res.data.data.meeting_id;
                      scope.zoomPhoneNo = globalConstants.zoomPhoneNo;
                      if(scope.appointmentData.consult_medium == 'Video'){
                        scope.templateUrl='modules/consumer/scheduleAppointment/template/connectingtoConsult.html';
                       }else{
                        scope.templateUrl='modules/consumer/scheduleAppointment/template/phoneConsult.html';                      
                      }
                      if(Scopes.get('emr_history_category_id')){
                        commonGetterService.shareMedicalRecord({consultation_id:[scope.onDemandAppointmentId],patient_id:scope.appointmentData.patient_id,provider_id:[scope.providersDetails.id]},token);
                      }
                       scope.getproviderStartStatus();
                       scope.appointmentData.terms_of_use = '';
                       scope.termsnConditions = '';
                       

                      // }
                  } else {
                      loadingFactory.hide();
                      scope.appointmentData.terms_of_use = '';
                      scope.termsnConditions = '';
                  }
          

              }, function(err) {
                loadingFactory.hide();
              })
            }
            else{
               scope.termsnConditions = "Please accept the terms and conditions";
            }         
        }
      },
      this.submitStrip = function(code,result,scope,token){
        //scope.wrongCardInfo = "";
        //scope.message = "";
        if (result.error) {

            if(result.error.hasOwnProperty('message')){

               toastMsg.show(result.error.message);
               scope.showMsg = true;
            }
            else{
             var obj = {
                       name:scope.cardInfo.name,
                       address_city:scope.cardInfo.city,
                       address_line1:scope.cardInfo.address1 ,
                       address_line2:(scope.cardInfo.address2) ? scope.cardInfo.address2 : ' ',
                       address_state:scope.cardInfo.state ,
                       address_zip:scope.cardInfo.zip_code ,
                       cvc:scope.cardInfo.cvc ,
                       exp_month:scope.cardInfo.exp_month ,
                       exp_year:scope.cardInfo.exp_year ,
                       number:scope.cardInfo.number

              }


              if(code == 408){
                var othervF1 = otherValidationCheck.validateBeforeSubmit();
                  var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',obj,token);  // get the consumer detail list
                  promise.then(function(res){
                  var res = res.data;
                  if(res.status == true){
                       scope.cardInfo.cvc = '';
                       toastMsg.show("Card has been added successfully");
                       loadingFactory.hide();
                       showModalService.hide(true);
                       if(scope.webinarType){  // only for webinar
                        showModalService.show(scope,'modules/main/community/template/registarWebinarConsumer.html');
                       }
                       that.getCards(scope,token);
                       scope.cardInfo = {};
                       Scopes.delete('formInfo');
                       scope.typeofAction = 'Add';
                   }
                  else if(res.status == "error"){
                     toastMsg.show(res.message);
                     loadingFactory.hide();
                   }

                  },function(err){
                    loadingFactory.hide();
                  })


                }
            }

        } else {
            //scope.consData.stripe = result;
            var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.addCard,'POST',result,token);  // get the consumer detail list
            promise.then(function(res){
                var res = res.data;
                if(res.status == true){
                    scope.cardInfo.cvc = '';
                    toastMsg.show("Card has been added successfully");
                    loadingFactory.hide();
                    showModalService.hide(true);
                    if(scope.webinarType){  // only for webinar
                     showModalService.show(scope,'modules/main/community/template/registarWebinarConsumer.html');
                    }
                    that.getCards(scope,token);
                    scope.cardInfo = {};
                    Scopes.delete('formInfo');
                    scope.typeofAction = 'Add';
                    loadingFactory.hide();
                }else if(res.status == "error"){
                    toastMsg.show(res.message);
                    loadingFactory.hide();
               }
            },function(err){
                loadingFactory.hide();
            })

        }

      },
      this.providerDeatilsOnInsurance = function(scope,token){
        var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getOnDemandProviderDetail, 'POST', {
             "provider_id": scope.providerDetail.id,
             "insurance_plan_id": scope.appointmentData.insurance_plan_id,
             "patient_id": scope.appointmentData.patient_id
         }, token); // get the consumer detail list  

         promise.then(function(res) {
           // alert(JSON.stringify(res.data.data));
             if (res.data.status == true) {
                
                 loadingFactory.hide();
                 scope.providersDetails = res.data.data;
                 //alert(JSON.stringify(res.data.data));
                 scope.appointmentData.consultation_total_charge = res.data.data.total_amount;
                 that.getCards(scope,token);
             } else if (res.data.status == false) {
                 loadingFactory.hide();
             }
         }, function(err) {
            loadingFactory.hide();
         })
      }


});