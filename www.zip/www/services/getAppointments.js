/*
* @Service  to get appointments list for consumer and providers
* @Author
*/
face2face.service('getAppointments',function(serverRequestFactory,globalConstants){
    
  /*
    * Function to get appointments for consumers/providers

    */
    this.getAppointments = function(appointmentType,token){
    	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getAppointments+appointmentType, 'POST', {},token);
      	return promise;

    };

});