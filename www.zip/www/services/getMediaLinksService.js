/*
* @Service  to get Media links
* @Author
*/
face2face.service('mediaLinksService',function(serverRequestFactory,globalConstants,$rootScope){
    
  	/*
    * Function to get Media links
    @parameters #slientCall - to show loader or not 
    @put medialist in $scope in calling ctrl
    */
    this.getMediaLinks = function(slientCall){
    	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getMediaLinks, 'GET', {});
      	promise.then(function(res) {
        	if (res.data.status == true && res.data.data != "None") {
          		$rootScope.medialist = res.data.data;
          		$('#loader').hide();
          		//return patientsList;
            } else {
          		$('#loader').hide();
        	}
      	}, function(err) {
        	$('#loader').hide();
      	});
      	

    };
   });