/*
* @Service  to get Patients list for consumer and providers
* @Author
*/
face2face.service('getPatientsService',function(serverRequestFactory,globalConstants,$timeout,convertDate,loadingFactory,showPopup,$stateParams){
    
  /*
    * Function to get Patients for consumers 
    @parameters #slientCall - to show loader or not 
    @put patientList in controller scope to get data
    */
    this.getPatientsforConsumer = function(scope,slientCall,token){
      var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getPatients, 'GET', {},token,'',slientCall);
        promise.then(function(res) {
          if (res.data.status == true && res.data.data != "None") {
              scope.patientList = res.data.data;
              if($stateParams.type == 'C' || $stateParams.type == 'M') {
                for(var i = 0 ;i < scope.patientList.length;i++) {
                  var name = scope.patientList[i].fname+' '+scope.patientList[i].lname; 
                  name == globalConstants.askAnExpertPopup.name ? scope.patientList.splice(i,1): angular.noop();
                }
              }
              loadingFactory.hide();
            } else {
              loadingFactory.hide();
          }
        }, function(err) {
          loadingFactory.hide();
        });
    };
    this.getPatientDetails = function(scope,patientId,slientCall,token,providerGroup){
       var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.patientDetail+patientId, 'GET', {},token,'',slientCall);
          promise.then(function(res) {
          if (res.data.status == true && res.data.data != "None") {
              scope.patientDetails = res.data.data;
              var name = scope.patientDetails.fname+' '+scope.patientDetails.lname;
              name == globalConstants.askAnExpertPopup.name ? scope.askAnExpert = true : scope.askAnExpert = false;
              scope.askAnExpert ? scope.patientName = scope.patientDetails.user.fname+' '+scope.patientDetails.user.lname : scope.patientName = name;
              if(angular.isDefined(scope.age)){
                scope.askAnExpert ? scope.age = convertDate.toAge(scope.patientDetails.user.dob) : scope.age = convertDate.toAge(scope.patientDetails.dob);
              }
              if(angular.isDefined(scope.gender)){
                scope.askAnExpert ? scope.gender = scope.patientDetails.user.gender :scope.gender = scope.patientDetails.gender;
              }

              if(scope.appointmentData){
                if(scope.appointmentData.provider_type_id) {
                  providerGroup ? scope.getProviderGroup(scope.appointmentData.provider_type_id,true) :scope.getSpecialities(scope.appointmentData.provider_type_id,true);
                }
                else if(scope.providerTypes && scope.providerTypes[0].provider_type_id) { // for multi provider
                  var length = scope.providerTypes.length;
                  for(var i = 0; i<length; i++) {
                    var id =scope.providerTypes[i].provider_type_id
                    id ? scope.getSpecialities(id,i,'multi','',true): angular.noop();
                  }
                }
              }
              loadingFactory.hide();
              //return patientsList;
            } else {
              loadingFactory.hide();
          }
        }, function(err) {
          loadingFactory.hide();
        });
    }

    this.showAskAnExpertPopup = function(scope,patientId,token,providerGroup) {
      var askAnExpert= false;
      scope.patientList.filter(function(value){
        if(value.id == patientId) {
          var name = value.fname+' '+value.lname;
          name == globalConstants.askAnExpertPopup.name ? askAnExpert = true : askAnExpert = false;
        }
      })
      if(askAnExpert){
        showPopup.show(globalConstants.askAnExpertPopup.title,globalConstants.askAnExpertPopup.desc,scope,patientId,globalConstants.askAnExpertPopup.buttonTitle);
      }else{
        this.getPatientDetails(scope,scope.appointmentData.patient_id,'',token,providerGroup);
      }
    }

    this.showAgeWarning = function(scope, groupOrSpecilityId,inquiry,ageGroupStatus,index) {
      if(!scope.askAnExpert) {
        var desc = scope.titleSpeciality + globalConstants.ageGroupPopup.desc;
        ageGroupStatus ? 
          showPopup.show(globalConstants.ageGroupPopup.title,desc,scope,groupOrSpecilityId,globalConstants.ageGroupPopup.buttonTitle,index)
        : (index == 0 || index )? scope.takeSpecialityName({index:index,id:groupOrSpecilityId}) : scope.getProviderInquiry(groupOrSpecilityId,inquiry);
      }
    }
})