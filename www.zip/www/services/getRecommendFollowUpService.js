/*
* @Service  to get RecommendFollowUp for consumers 
* @Author
*/
face2face.service('getRecommendFollowUpService',function(serverRequestFactory,globalConstants,$timeout,convertDate){
    
  /*
    * Function to get RecommendFollowUp for consumers 
    @parameters #slientCall - to show loader or not 
    @put RecommendFollowUp & RecommendMsg in controller scope to get data
    */
 
    this.getRecommendFollowUp = function(scope,slientCall,token){
    	var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getRecommendFollowUp, 'GET', {},token,'',slientCall);
      	promise.then(function(res) {
        	if (res.data.status == true && res.data.data != "None") {
          		scope.RecommendFollowUp = res.data.data;
              scope.RecommendMsg = false;
          		$('#loader').hide();
          		//return patientsList;
            }else{
              $('#loader').hide();
              scope.RecommendFollowUp = res.data.message;
              scope.RecommendMsg = res.data.message;
            }
      	}, function(err) {
        	$('#loader').hide();
      	});
      	

    };
})