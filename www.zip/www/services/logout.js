face2face.service('logOut',function(serverRequestFactory,globalConstants,$state,$window,$rootScope,extractDomain,loadingFactory,$ionicHistory){
    
  this.logOut = function(token){
    var that = this;
    var userData = JSON.parse(localStorage.userData);
    var token = userData.token;
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.logout,'GET','',token);  
    promise.then(function(res){
         if(res.data.status == true){
         /* var host = extractDomain.extractRootDomain(window.location.hostname)
          document.cookie = "emr_token=; domain="+host+"; path=/";
          document.cookie = "moodle_token=;domain="+host+"; path=/";
          document.cookie = "status=logout;domain="+host+";path=/"; 
          document.cookie = "activityTime = ; expires=Thu, 01-Jan-1970 00:00:01 GMT; domain="+host+"; path=/";
  */      $window.localStorage.clear();
          $ionicHistory.clearCache()
          loadingFactory.hide();
          $state.go('signin');
          //clearInterval($rootScope.checkIfLogout);
          loadingFactory.hide();
         }else if(res.status == false){
        loadingFactory.hide();
       }
      },function(err){
        loadingFactory.hide();
    });

  };

  /*this.checkIfLoggedOut = function(){
    var userData = JSON.parse(localStorage.userData);
    var token = userData.token;
    var that = this;
    var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.checkLoginstatus,'GET','',token,'','silent');  
    promise.then(function(res){
         if(res.data.status == true){
             
         }else if(res.status == false){
          clearInterval($rootScope.checkIfLogout);
          that.logOut(token);
       }
      },function(err){
        
    });
  }*/

})