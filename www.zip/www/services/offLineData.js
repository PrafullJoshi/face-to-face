face2face.service("Scopes", function(){//method to share data between multiple controllers.....
           var mem = {};//to store data throughout the controllers...
           return{
           store:function(key, value){
           mem[key] = value;
           },
           get:function(key){
           return mem[key];
           },
           delete:function(key){
            delete mem[key];//clear memory...
           }  
          
           };

                      
})
face2face.factory("requiredFactory", function(Scopes,$compile){
          
     var requiredFactory = {};
     requiredFactory.validateBeforeSubmit = function(form,scope,eve){
         var temObj = {};var messageElem; var count = 0;

         temObj = (Scopes.get('formInfo'))?Scopes.get('formInfo'):"";

         for(var i = 0;i<temObj.length;i++){
             
              messageElem = angular.element(document.querySelector('#' + (temObj[i].msgId)))

              count = requiredFactory.showMsg(scope,form[temObj[i].formName],messageElem,count,eve);
         }
         if(count>0){
          return false;
         }
         else{
        //  console.log("in")
          return true;
         }

     };
     requiredFactory.showMsg = function(scope,formObj,messageElem,count,eve){
      //console.log(JSON.stringify(scope));

      if(eve){
        messageElem.html('');
            
        $compile(messageElem.contents())(scope);
         return count;
      }
        else if(formObj){

          if(!formObj.$viewValue || (typeof formObj.$viewValue === 'string' && (formObj.$viewValue).indexOf('select') >= 0)){
            messageElem.html('This field is required');
            //messageElem.contents()[0].innerText=='This field is required'
            $compile(messageElem.contents())(scope);

            // messageElem.css('display', 'block');
            count++;
           //console.log(temObj[i]);
          }

         else if(angular.isDefined(messageElem.contents()[0]) && messageElem.contents()[0].innerText=='This field is required'){ 
            //messageElem.css('display', 'none');
            messageElem.html('');
            
            $compile(messageElem.contents())(scope);

          }
        }

        return count;
     }
     requiredFactory.errAlert = function(){
      
     }

     return requiredFactory;                
});

face2face.factory("otherValidationCheck", function(Scopes,$compile){
          
     var otherValidationCheck = {};
     otherValidationCheck.validateBeforeSubmit = function(){
         var temObj = {};var messageElem; var count = 0;
       //  console.log(JSON.stringify(Scopes.get('formInfoValidation')));
         temObj = (Scopes.get('formInfoValidation'))?Scopes.get('formInfoValidation'):"";

         for(var i = 0;i<temObj.length;i++){
             
              messageElem = angular.element(document.querySelector('#' + (temObj[i].msgId)))
              if(messageElem.contents()[0]){
                count++;
              }
         }
         if(count>0){
          return false;
         }
         else{
          //console.log("in")
          return true;
         }

     };
     return otherValidationCheck;                
});
 face2face.service("convertDate",function(){
  var convertDate = {};
  convertDate.toYYYYmmdd = function(cusDate){
    if(cusDate){
    // var formateddate =  ("0" + (new Date(cusDate).getMonth() + 1)).slice(-2)+ "/" + ("0" + new Date(cusDate).getDate()).slice(-2) + "/" + new Date(cusDate).getFullYear();
     var formateddate =  new Date(cusDate).getFullYear()+"-"+("0" + (new Date(cusDate).getMonth() + 1)).slice(-2)+"-"+("0" + new Date(cusDate).getDate()).slice(-2);}

     else{
       formateddate = '';
     return formateddate;
    }
    
    return formateddate;
  },
  convertDate.toMMddYYYY = function(cusDate){
     if(cusDate){
      var formateddate =  ("0" + (new Date(cusDate).getMonth() + 1)).slice(-2)+ "/" + ("0" + new Date(cusDate).getDate()).slice(-2) + "/" + new Date(cusDate).getFullYear();
      
     }
      else{
        formateddate = '';
      return formateddate;
     }
     
     return formateddate;
  },
  convertDate.toAmPM = function(cusDate){
    var date = new Date(cusDate);
    var hours = date.getHours() > 12 ? date.getHours() - 12 : date.getHours();
    var am_pm = date.getHours() >= 12 ? "PM" : "AM";
    hours = hours < 10 ? "0" + hours : hours;
    var minutes = date.getMinutes() < 10 ? "0" + date.getMinutes() : date.getMinutes();
    //var seconds = date.getSeconds() < 10 ? "0" + date.getSeconds() : date.getSeconds();
    time = hours + ":" + minutes + " " + am_pm;
    return time;
  },
  convertDate.toAge = function(cusDate){
    var birthdate = new Date(cusDate).getTime();
    var now = new Date().getTime();
    // now find the difference between now and the birthdate
    var n = (now - birthdate)/1000;

  if (n < 604800) { // less than a week
    var day_n = Math.floor(n/86400);
    return day_n + ' Day' + (day_n > 1 ? 's' : '');
  } else if (n < 2629743) {  // less than a month
    var week_n = Math.floor(n/604800);
    return week_n + ' Week' + (week_n > 1 ? 's' : '');
  } else if (n < 63113852) { // less than 24 months
    var month_n = Math.floor(n/2629743);
    return month_n + ' Month' + (month_n > 1 ? 's' : '');
  } else { 
    var year_n = Math.floor(n/31556926);
    return year_n + ' Year' + (year_n > 1 ? 's' : '');
  }
}

  convertDate.toMMddYYYYInString = function(date){
      var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      var days =["Sun","Mon","Tues","Wed","Thus","Fri","Sat"];
      date = new Date(date);
      return monthNames[date.getMonth()] + " " + date.getDate() +", "+  date.getFullYear();
  }

 convertDate.passYr = function(){
   return new Date().getFullYear();
 }

 return convertDate;
});


face2face.factory('loadingFactory', ['$ionicLoading', '$rootScope', function($ionicLoading){
	
	return {
	    show: function (backdropNeed) {
	        var backdrop = false;
	        if (backdropNeed) {
	            backdrop = true;
	        }
		//$rootScope.myCustomLoader = 1;
		$ionicLoading.show({
	            
	            template: "<ion-spinner icon='spiral' ></ion-spinner>",
	            animation: 'fade-in',
	            showBackdrop: backdrop,
	            maxWidth: 200,
	            delay: 200
	        });
		}, 
		hide: function() {
			
		$ionicLoading.hide();
		/*setTimeout(function() {
					$rootScope.myCustomLoader = 0;

           }, 100);*/
			
		}
	}
}]);

face2face.factory('showPopup',function($ionicPopup,globalConstants){
  var showPopup = {};
  var popUpshown = false;
   showPopup.show=function(title,tem,scope,status,buttonText,index){
      // A confirm dialog
      if(!popUpshown){
        popUpshown =true;
        var confirmPopup  = $ionicPopup.confirm({
          title:title,
          template: tem,
          buttons: [
            { text: 'Cancel' },
            {
              text: buttonText,
              type: 'button-energized',
              onTap: function(e) {
                return e;
              }
          }]
        });

        confirmPopup.then(function(res) {
          if(res) {
            showPopup.accepted(status,scope);
          } else {
           showPopup.canceled(scope,buttonText,title,index);
          }
        });
      }

    },
   showPopup.accepted=function(status,scope){
     popUpshown = false;
     scope.confirmStatus(status);
     
   },
   showPopup.canceled = function(scope,buttonText,title,index){
    popUpshown = false;
    if(buttonText == 'Extend' || title == globalConstants.askAnExpertPopup.title || title == globalConstants.ageGroupPopup.title){
      scope.confirmStatus(status,'cancel',index);
    }
    
   }
/*  show popup  */
   showPopup.showPopupCus = function(title,tem,scope,buttonText,funcName,funcParam){
      popup = $ionicPopup.show({
      templateUrl: tem,
      scope: scope,
      buttons: [
        {
          text: '<b>Cancel</b>',
          type: 'button-grey',
        },
        {
          text: buttonText,
          type: 'button-yellow',
          onTap: function(e) {
            if(scope.check && scope.check.view_issue_type == 'Yes' && scope.check.view_patient_form == 'Yes'&& scope.check.view_patient_history == 'Yes'){
                return e;
            }else{
              toastMsg.show('Please check all the boxes');            
              e.preventDefault();
            }            
          }
        }
      ]
    });
    popup.then(function(res) {
      if(res) {
          scope[funcName](funcParam);
      } else {
          showPopup.closePopupCus();
      }
    });
   }
   showPopup.closePopupCus = function(){
    popup.close();
   }


  return showPopup;
});

face2face.service('extractDomain',function(){

  this.extractRootDomain= function(url) {
                  var domain = url;
                  splitArr = domain.split('.');
                  arrLen = splitArr.length;

                  //extracting the root domain here
                  if (arrLen > 2) {
                      domain = '.' + splitArr[arrLen - 2] + '.' + splitArr[arrLen - 1];
                  }
                  return domain;
    }
})



