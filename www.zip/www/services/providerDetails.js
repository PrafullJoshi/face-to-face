/*
* @Service  to get Patients list for consumer and providers
* @Author
*/
face2face.service('getProvidersDetailService',function(serverRequestFactory,globalConstants,loadingFactory){

    this.getDetails = function(scope,providerIds,slientCall,token){
    	 var promise = serverRequestFactory.serverComm(globalConstants.serviceUrl.getProviderDetailsMulti, 'POST',providerIds,token,'',slientCall);
    	    promise.then(function(res) {
        	if (res.data.status == true && res.data.data != "None") {
          		scope.providersDetails = res.data.data;
              // if(angular.isDefined(scope.total_amount)){
              //   scope.total_amount = scope.providersDetails.total_amount;
              // }
          		loadingFactory.hide();
          		//return patientsList;
            } else {
          		loadingFactory.hide();
        	}
      	}, function(err) {
        	loadingFactory.hide();
      	});
    }
})