/*
* @Service  to submit Rescheduled appointments  
* @Author
*/
face2face.service('rescheduleAppointmentService',function(serverRequestFactory,globalConstants,$timeout,convertDate,loadingFactory,toastMsg,showModalService,$filter){
  
  /* function to reScheduleConsult */
    this.reScheduleConsult = function(rescheduleData,token,loc,scope,type){ 
          if(type == 2){
            var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.reScheduleConsultByConsumer, 'POST',{
              "consult_id":rescheduleData.id,
              "consultation_start_date":$filter('date')(new Date(scope.consultation_start_date.displayDate),'MM/dd/yyyy'),
              "consultation_start_time": $filter('date')(scope.consultation_start_date.date, 'HH:mm'),
              "consultation_end_time": $filter('date')(scope.consultation_end_date.date, 'HH:mm'),
              "timezone" : rescheduleData.timezone
            },token);

          }else{

            var promise= serverRequestFactory.serverComm(globalConstants.serviceUrl.reScheduleAppointment, 'POST',{
              "consult_id":rescheduleData.id,
              "re_schedule_date":$filter('date')(new Date(scope.consultation_start_date.displayDate),'MM/dd/yyyy'),
              "re_schedule_start_time": $filter('date')(scope.consultation_start_date.date, 'HH:mm'),
              "re_schedule_end_time": $filter('date')(scope.consultation_end_date.date, 'HH:mm'),
              "timezone" : rescheduleData.timezone
            },token);
          }
         
          promise.then(function(res) {
              if (res.data.status == true) {
                   showModalService.hide();
                   loadingFactory.hide();
                   scope.changeTabs('scheduled');
              } else {

                 loadingFactory.hide();
                 toastMsg.show(res.data.message);

              }
          }, function(err) {
               loadingFactory.hide();
               showModalService.hide();
          
          });
      
  }
   
})