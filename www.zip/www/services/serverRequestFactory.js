   // factroy that makes ajax request to the service
face2face.factory('serverRequestFactory',function(globalConstants,$http,$q,$state,$window,$rootScope,loadingFactory,toastMsg){
	var serverRequestFactory = {};
    serverRequestFactory.serverComm=function(url, type, dataToPost,token,loadMore,silentCall){
      
      if(!silentCall){
       loadingFactory.show(true);
      }

      if(!token)token= '';
      var df = $q.defer();
     
      var promise =$http({
      	method: type,
      	data: dataToPost,
        timeout: globalConstants.timeOut,

         url: globalConstants.gHost + '/api'+ url,
         //url:"http://172.16.145.243/f2f-api" +url,
        headers:{
        
          'token': token
        }
      }).then(function successCallback(response){
        //if(response)
          df.resolve(response);
      
     }, function errorCallback(response) {
       if(response.status == '401'){
          $window.localStorage.clear();
        $state.go('signin');
        }else{
          toastMsg.show('Oops! some error occured. Please check your internet connection or try again later');
        }
        loadingFactory.hide();
        df.reject(response);
      
    })
    .catch(function(e){
      df.reject(e);
      loadingFactory.hide();
    });

     return df.promise;

    }

    return serverRequestFactory;
});

// face2face.factory('requestRecoverer', ['$q','$injector','$timeout',function($q,$injector,$timeout) {  
//    var retries = 0,
//       waitBetweenErrors = 100,
//       maxRetries = 3;

//     function onResponseError(httpConfig) {
//         var $http = $injector.get('$http');
//         $timeout(function () {
//             return $http(httpConfig);
//         }, waitBetweenErrors);
//     }

//     return {
//         responseError: function (response) {
//             if (response.status == -1 && retries < maxRetries) {
//                 retries++;
//                 return onResponseError(response.config);
//             }else{
//               retries = 0;
//               return $q.reject(response);
//             }
            
//         }
//     };
// }]);

