face2face.service('showModalService',function($ionicModal,Scopes){
  var modalObject ={};
  this.show = function(scope,tempUrl,name){
    
    $ionicModal.fromTemplateUrl(tempUrl, {    
        scope: scope,
        animation: 'slide-in-up'
      }).then(function(modal) {
        if(name){
          scope.oModal = modal;
          scope.oModal.show();
          if(name == 'appointment')
            Scopes.store('oModal',scope.oModal);
        }else{
          modalObject = modal;
          modalObject.show();
        }

      });
    };

    this.hide = function(destroy){
      if(!(angular.equals({}, modalObject))){
        modalObject.hide();
        if(destroy){
          modalObject.remove();
        }
      }
    };

    this.destroy  = function(){
      if(!(angular.equals({}, modalObject))){
        modalObject.remove();
      }
    };

});