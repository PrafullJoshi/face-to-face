// show and hide toast messages
face2face.factory('toastMsg',function(globalConstants){
  return{
    show:function(msg){
    window.plugins.toast.showWithOptions(
    {
      message: msg,
      duration: "long", // which is 2000 ms. "long" is 4000. Or specify the nr of ms yourself.
      position: "center",
      addPixelsY: -40  // added a negative value to move it up a bit (default 0)
    }
   // onSuccess, // optional
  //  onError    // optional
  );
   },
   hide:function(){
      window.plugins.toast.hide();
   }
}
});
