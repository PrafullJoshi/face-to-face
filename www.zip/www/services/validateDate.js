// generic method to validate date
face2face.factory('validateDate',function(globalConstants,convertDate,$timeout){
  var validateDate = {};
  var temObj = {
    flag : true,
    msg : ""
                       
  };
  var flag =true;
   validateDate.validateDt = function(date,type){
            //var pattern = /^([0-9]{2})-([0-9]{2})-([0-9]{4})$/;
           // var pattern = /^\d{2}\/\d{2}\/\d{4}$/ ;
          
            var pattern = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(16|17|18|19|20)\d{2}$/ ;
            //var pattern = /^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\d{4}$/ ;
            var customDate, isValid;
             if(date){
             //moment(date, ["MM-DD-YYYY"], true).isValid()
                // date=moment(date).format('MM/DD/YYYY');
                 date = convertDate.toMMddYYYY(date);
                 if(pattern.test(date)){  
                     customDate = new Date(date);
                     isValid = !isNaN(customDate);

                    // if(isValid){                     
                      var oneDay = 24*60*60*1000;
                      var today = new Date();
                      var dd = today.getDate();
                      var mm = today.getMonth()+1; //January is 0!
                      var yyyy = today.getFullYear();
                      var dd = mm+'/'+dd+'/'+yyyy;
                      var currentDate = new Date(dd);
                      var diffDays = Math.round(((currentDate.getTime() - customDate.getTime())/(oneDay)));
                
                      if(type == 'motherDOB'){   // to check parent's dob
                        
                           if(diffDays < 6570){
                           temObj.flag = false;
                           temObj.msg = " Invalid DOB! Age should be more than 18";
                           return temObj; 
                          
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                        
                      }
                      else if(type == 'fatherDOB'){
                           if(diffDays < 6570 ){
                           temObj.flag = false;
                           temObj.msg = " Invalid DOB! Age should be more than 18";
                           return temObj; 
                          
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                      }
                      else if(type == 'providerDOB'){
                           if(diffDays < 6570 ){
                           temObj.flag = false;
                           temObj.msg = "Provider's age can not be less than 18 years";
                           return temObj; 
                          
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                      }
                      else if(type == 'consultDOB'){
                           if(diffDays < 6570 ){
                           temObj.flag = false;
                           temObj.msg = "Consumer's age can not be less than 18 years";
                           return temObj; 
                          
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                      }
                      else if(type == 'childDOB'){
                        if(diffDays > 6570 || diffDays < 0){
                         temObj.flag = false;
                         temObj.msg = "Child's age can not be more than 18 years";
                         return temObj; 
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                           
                      }
                      else if(type == 'deaExpDOB'){
                           if(diffDays > 0 ){
                           temObj.flag = false;
                           temObj.msg = "DEA expiration date can not be less than today's date";
                           return temObj; 
                          
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                      }
                        else if(type == 'npiExpDOB'){
                          if(diffDays > 0 ){
                           temObj.flag = false;
                           temObj.msg = "NPI expiration date can not be less than today's date";
                           return temObj; 
                          
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                      }
                      else if(type == 'appointmentDOB'){
                        if(diffDays > 0 ){
                          temObj.flag = false;
                          temObj.msg = "Appointment date can not be less than today's date";
                          return temObj; 
                        }
                        else{
                          temObj.flag = true;
                          temObj.msg = "";
                          return temObj;
                        }
                      }
                      else{
                        temObj.flag = true;
                        temObj.msg = "";
                        return temObj;
                      }
                    
                    // }
                    // else{
                    //   temObj.flag = false;
                    //   temObj.msg = "Invalid Date !";
                    //   return temObj; 
                    // }

               
                     
               } else{ // invalid date 

                temObj.flag = false;
                temObj.msg = "The date should be in MM/DD/YYYY format";
                return temObj; 
                  
               } 
             }
             else{

               
                temObj.flag = true;
                temObj.msg = "";
                return temObj;


                 // empty date field
             }

            
           }
   validateDate.showDatePicker = function(scope,type,min,max){
  
    var options = {
        date: angular.isDefined(scope.data)? new Date(scope.data.dob): new Date(),
        mode: 'date',
        minDate : (min)?min:'',
        maxDate : (max)?max:''
    };

    function onSuccess(date) {
       $timeout(function() { scope.$apply();});//added to improve rendering delay
        if(type == 'childDOB'){
          scope.data.dob = convertDate.toMMddYYYY(date);
        }else if(type == 'consent'){
          scope.appointmentData.consultation_dob = convertDate.toMMddYYYY(date);
        }
       
         
    }

    function onError(error) { // Android only
        console.log('Error: ' + error);
    }

    datePicker.show(options, onSuccess, onError);
   }

  validateDate.showDatePickerforCosult = function(scope,type,min,max){

    var min = (type == 'start' ?  (ionic.Platform.isIOS() ? new Date() :(new Date()).valueOf()) : (ionic.Platform.isIOS() ?scope.consultation_start_date.date:scope.consultation_start_date.date.valueOf()));
    var max = (type == 'end' ? (ionic.Platform.isIOS() ? new Date(scope.consultation_start_date.displayDate + ' 23:59'):new Date(scope.consultation_start_date.displayDate + ' 23:59').valueOf()):'');
    var selectedDate = (type == 'start'? scope.consultation_start_date.date : scope.consultation_end_date.date);
    if(ionic.Platform.isIOS()){
      var options = {
          date: selectedDate ,
          mode: 'datetime',
          minDate : min,
          maxDate : max,
          minuteInterval:5
      };
      datePicker.show(options, onSuccess, onError);
    }else{
      var options = { 
        mode: "datetime",
        date: (type == 'start'? scope.consultation_start_date.date : scope.consultation_end_date.date) ,
        allowOldDates: false,
        allowFutureDates: true,
        minuteInterval: 1,
        locale: "EN",
        okText: "Done",
        cancelText: "Cancel"
    };

    cordova.plugins.DateTimePicker.show(options, onSuccess, onError);
    }

 
    function onSuccess(date) {
      if(angular.isDefined(date)){
         $timeout(function() { scope.$apply();});//added to improve rendering delay
          if(type == 'start'){
            scope.consultation_start_date = {
              displayDate: convertDate.toMMddYYYYInString(date),
              displayTime: convertDate.toAmPM(date),
              date:date

            }; 
            scope.consultation_end_date.displayDate = convertDate.toMMddYYYYInString(date);
          }else if(type == 'end'){
            scope.consultation_end_date.displayTime = convertDate.toAmPM(date);
            scope.consultation_end_date.date = date;
          }
      }        
    }

    function onError(error) { // Android only
        console.log('Error: ' + error);
    }
   }

  validateDate.showDatePicker_ = function(scope,type,min,max,date,index){
    //alert(date);
    var options = {
        date: new Date(date)?new Date(date):new Date(),
        mode: 'date',
        minDate : (min)?min:'',
        maxDate : (max)?max:''
    };

    function onSuccess(date) {
       $timeout(function() { scope.$apply();});//added to improve rendering delay
       if(type=='childDOB'){
        scope.addPat.dob = convertDate.toMMddYYYY(date);
       }
       else if(type=='motherDOB'){
        scope.addPat.patient_parent.primary_dob = convertDate.toMMddYYYY(date);
       }
       else if(type=='fatherDOB'){
        scope.addPat.patient_parent.secondary_dob = convertDate.toMMddYYYY(date);
       }else if(type == 'careTeamStart'){
        scope.patient_careteams[index].start_date = convertDate.toMMddYYYY(date);
       }else if(type == 'careTeamEnd'){
        scope.patient_careteams[index].end_date = convertDate.toMMddYYYY(date);
       }
        
    }

    function onError(error) { // Android only
        scope.addPat.dob = '';
    }

    datePicker.show(options, onSuccess, onError);
    //cordova.plugins.Keyboard.close();
   }

   validateDate.getYears =  function(){

      var dd = new Date();
      dd = dd.getFullYear();
      var oldYr = dd;
      var yr = [];
      /*for(o = 30;o > 1 ;o--){
          yr.push(--oldYr);
      } */
      yr.push(dd);
      for(o = 1;o <30 ;o++){
          yr.push(--dd);
      }

    return yr.sort();
 }

  return validateDate;
});