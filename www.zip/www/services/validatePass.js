// generic method to validate password 
face2face.factory('validatePass',function(globalConstants){
	var validatePass = {};
   validatePass.validate = function(password,confirmPass,email,username){
    console.log(password,confirmPass,email,username)
      var obj = {};
      obj.confirm = false;
      obj.mssg = '';
      if(!email)email='';
      if(!username)username='';
      if(!password)password='';
     // check if password and confirm password fields match
      if(confirmPass && password != confirmPass){

      obj.mssg = globalConstants.errorMessages.confirmPassword; 
      obj.flag = false;
      obj.confirm = true;
      
        return obj;  
    
      }
   // check if the password is not a combination of username or email
      if((password.toLowerCase() != username.toLowerCase()|| username == '') && (password.toLowerCase() != email.toLowerCase() || email == '') ){
        // check if password is atleast 8 characters long
          if(!(password.length < 8)){   
         // check if password is a combination of uppercase,lowercase letters, numbers and special symbols ....
            if(!(password).match(/^(?=.{8,})(?=.*[a-z])(?=.*[A-Z]).*$/)){  
            obj.msg = globalConstants.errorMessages.invalidPassChar;  
            obj.flag = false;  
            return obj;

          }

        }
        else{

          obj.msg = globalConstants.errorMessages.invalidPassLen;  
          obj.flag = false;  
          return obj;

        }
      }
      else{

        obj.msg = globalConstants.errorMessages.invalidPass;  
        obj.flag = false;  
        return obj;

      }
     obj.msg = ''; 
     obj.flag = true;
     // console.log("object : ",obj);
     return obj;
   }
    // console.log("validate pass : ",validatePass)
    return validatePass;
});